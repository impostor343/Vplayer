package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.view.SurfaceView
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.AspectRatio
import androidx.compose.material.icons.outlined.Audiotrack
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.Brightness6
import androidx.compose.material.icons.outlined.ClosedCaption
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.ScreenRotation
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Subtitles
import androidx.compose.material.icons.automirrored.outlined.VolumeUp
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.AspectRatioPreset
import com.example.domain.HdrFormat
import com.example.media.Formatters
import com.example.player.MpvEngineController
import com.example.ui.components.AspectRatioBadge
import com.example.ui.components.HdrFormatBadge
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaBorderSubtle
import com.example.ui.theme.CinemaCharcoal
import com.example.ui.theme.CinemaCrimson
import com.example.ui.theme.CinemaEmerald
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.CinemaIce
import com.example.ui.theme.CinemaObsidian
import com.example.ui.theme.CinemaSurfaceHigh
import com.example.ui.theme.CinemaTextMuted
import com.example.ui.theme.CinemaTextPrimary
import com.example.ui.theme.CinemaTextSecondary
import com.example.viewmodel.PlayerViewModel
import kotlinx.coroutines.delay
import java.util.Locale

private enum class PlayerControlSheet {
    SUBTITLES,
    AUDIO,
    CHAPTERS,
    ASPECT,
    SPEED,
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    videoId: String,
    startPositionMs: Long?,
    playerViewModel: PlayerViewModel,
    onNavigateBack: () -> Unit,
    onOpenMpvConfig: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current

    val uiState by playerViewModel.uiState.collectAsStateWithLifecycle()
    val live by playerViewModel.playbackState.collectAsStateWithLifecycle()

    var controlsVisible by remember { mutableStateOf(true) }
    var isFullscreen by remember { mutableStateOf(true) }
    var activeSheet by remember { mutableStateOf<PlayerControlSheet?>(null) }
    var showBookmarkDialog by remember { mutableStateOf(false) }

    // Brightness & Volume gesture HUD state
    var gestureHudLabel by remember { mutableStateOf<String?>(null) }
    var gestureIsBrightness by remember { mutableStateOf(true) }
    var currentBrightness by remember {
        mutableFloatStateOf(
            activity?.window?.attributes?.screenBrightness?.takeIf { it in 0f..1f } ?: 0.6f
        )
    }

    val externalSubLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri: Uri? ->
        if (uri != null) playerViewModel.loadExternalSubtitle(uri)
    }

    // Load video on entry
    LaunchedEffect(videoId, startPositionMs) {
        playerViewModel.openVideo(videoId, startPositionMs)
    }

    // Auto-hide controls while playing
    LaunchedEffect(controlsVisible, live.isPaused, activeSheet, showBookmarkDialog) {
        if (controlsVisible && !live.isPaused && activeSheet == null && !showBookmarkDialog) {
            delay(4_000L)
            controlsVisible = false
        }
    }

    // Auto-clear gesture HUD pill
    LaunchedEffect(gestureHudLabel) {
        if (gestureHudLabel != null) {
            delay(1_100L)
            gestureHudLabel = null
        }
    }

    // Auto-clear brief status toast
    LaunchedEffect(uiState.statusNotice) {
        if (uiState.statusNotice != null) {
            delay(2_200L)
            playerViewModel.clearNotice()
        }
    }

    // Keep screen on & control immersive system bars
    DisposableEffect(activity, isFullscreen) {
        val window = activity?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        if (isFullscreen) {
            controller?.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            controller?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Save checkpoint & pause on app background
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                playerViewModel.onAppBackgrounded()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    BackHandler {
        playerViewModel.onLeavePlayer(interrupted = false)
        onNavigateBack()
    }

    val currentVideo = uiState.currentVideo
    val hdrFormat = HdrFormat.fromStored(currentVideo?.hdrFormat)
    val effectiveDuration = live.durationMs.takeIf { it > 0L } ?: (currentVideo?.durationMs ?: 0L)

    // Request Android HDR / Wide Color Gamut window compositing mode on API 26+
    DisposableEffect(activity, hdrFormat, uiState.displayCaps) {
        val window = activity?.window
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && window != null) {
            val caps = uiState.displayCaps
            val targetColorMode = when {
                hdrFormat.isHdr && caps?.isDisplayHdrCapable == true -> ActivityInfo.COLOR_MODE_HDR
                caps?.wideColorGamutSupported == true -> ActivityInfo.COLOR_MODE_WIDE_COLOR_GAMUT
                else -> ActivityInfo.COLOR_MODE_DEFAULT
            }
            runCatching { window.colorMode = targetColorMode }
        }
        onDispose {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && window != null) {
                runCatching { window.colorMode = ActivityInfo.COLOR_MODE_DEFAULT }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black),
    ) {
        // 1. Native libmpv SurfaceView
        AndroidView(
            factory = { ctx ->
                SurfaceView(ctx).apply {
                    holder.addCallback(playerViewModel.engineController)
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .testTag("mpv_surface_view"),
        )

        // 2. Gesture Layer (Tap to toggle controls, Double-tap to seek, Left/Right vertical drag for brightness/volume)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { controlsVisible = !controlsVisible },
                        onDoubleTap = { offset ->
                            if (offset.x < size.width / 2f) {
                                playerViewModel.engineController.seekBySeconds(-10)
                            } else {
                                playerViewModel.engineController.seekBySeconds(10)
                            }
                        },
                    )
                }
                .pointerInput(Unit) {
                    detectVerticalDragGestures { change, dragAmount ->
                        change.consume()
                        val isLeftSide = change.position.x < size.width / 2f
                        val deltaRatio = (-dragAmount / (size.height.coerceAtLeast(1) * 0.7f))
                        if (isLeftSide) {
                            currentBrightness = (currentBrightness + deltaRatio).coerceIn(0.05f, 1.0f)
                            activity?.window?.let { win ->
                                val lp = win.attributes
                                lp.screenBrightness = currentBrightness
                                win.attributes = lp
                            }
                            gestureIsBrightness = true
                            gestureHudLabel = "Brightness ${(currentBrightness * 100).toInt()}%"
                        } else {
                            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                            if (audioManager != null) {
                                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                val step = if (deltaRatio > 0.03f) 1 else if (deltaRatio < -0.03f) -1 else 0
                                if (step != 0) {
                                    val nextVol = (curVol + step).coerceIn(0, maxVol)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                                    gestureIsBrightness = false
                                    gestureHudLabel = "Volume ${(nextVol * 100) / maxVol}%"
                                }
                            }
                        }
                    }
                },
        )

        // 3. Engine Status Banner if native libmpv reports an error
        val status = live.status
        if (status is MpvEngineController.EngineStatus.Error) {
            Surface(
                color = CinemaCharcoal.copy(alpha = 0.92f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, CinemaCrimson.copy(alpha = 0.6f)),
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp),
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Playback Engine Notice", style = MaterialTheme.typography.titleMedium, color = CinemaCrimson)
                    Text(status.message, style = MaterialTheme.typography.bodySmall, color = CinemaTextPrimary)
                }
            }
        }

        // 4. Compact Non-Obstructive HDR & Aspect Indicator (visible even when HUD is minimized if desired, or top-right)
        if (!controlsVisible && !uiState.showTechOverlay) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .safeDrawingPadding()
                    .padding(12.dp)
                    .clickable { playerViewModel.toggleTechOverlay() },
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                HdrFormatBadge(format = hdrFormat, compact = true)
                AspectRatioBadge(darLabel = uiState.liveDarLabel, compact = true)
            }
        }

        // 5. Brightness / Volume Gesture Feedback Pill
        AnimatedVisibility(
            visible = gestureHudLabel != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center),
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.78f),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, CinemaBorder),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = if (gestureIsBrightness) {
                            Icons.Outlined.Brightness6
                        } else {
                            Icons.AutoMirrored.Outlined.VolumeUp
                        },
                        contentDescription = null,
                        tint = CinemaGold,
                    )
                    Text(
                        text = gestureHudLabel.orEmpty(),
                        style = MaterialTheme.typography.labelLarge,
                        color = CinemaTextPrimary,
                    )
                }
            }
        }

        // 6. Status Notice Toast
        AnimatedVisibility(
            visible = uiState.statusNotice != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(top = 56.dp),
        ) {
            Surface(
                color = CinemaCharcoal.copy(alpha = 0.92f),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, CinemaGold.copy(alpha = 0.6f)),
            ) {
                Text(
                    text = uiState.statusNotice.orEmpty(),
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelLarge,
                    color = CinemaTextPrimary,
                )
            }
        }

        // 7. Cinematic Player Controls Overlay
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize(),
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Top Bar Scrim + Title + Compact HDR/DAR + Tech Overlay + Config
                Row(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Black.copy(alpha = 0.85f), Color.Transparent)
                            )
                        )
                        .safeDrawingPadding()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(
                        onClick = {
                            playerViewModel.onLeavePlayer(interrupted = false)
                            onNavigateBack()
                        },
                        modifier = Modifier.testTag("player_back_button"),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back),
                            tint = CinemaTextPrimary,
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentVideo?.filename?.substringBeforeLast('.') ?: "Local Video",
                            style = MaterialTheme.typography.titleMedium,
                            color = CinemaTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            HdrFormatBadge(format = hdrFormat, compact = true)
                            AspectRatioBadge(darLabel = uiState.liveDarLabel, compact = true)
                            if (live.decoderStats.hwDecCurrent != "—") {
                                Text(
                                    text = live.decoderStats.hwDecCurrent,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CinemaEmerald,
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = { showBookmarkDialog = true },
                        modifier = Modifier.testTag("player_bookmark_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.BookmarkAdd,
                            contentDescription = stringResource(R.string.player_bookmark),
                            tint = CinemaGold,
                        )
                    }
                    IconButton(
                        onClick = { playerViewModel.toggleTechOverlay() },
                        modifier = Modifier.testTag("player_tech_overlay_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Info,
                            contentDescription = stringResource(R.string.player_tech_overlay),
                            tint = if (uiState.showTechOverlay) CinemaGold else CinemaTextPrimary,
                        )
                    }
                    IconButton(
                        onClick = {
                            playerViewModel.onAppBackgrounded()
                            onOpenMpvConfig()
                        },
                        modifier = Modifier.testTag("player_config_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Settings,
                            contentDescription = stringResource(R.string.player_mpv_config),
                            tint = CinemaTextPrimary,
                        )
                    }
                }

                // Center Transport Controls
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    IconButton(
                        onClick = { playerViewModel.playPreviousInPlaylist() },
                        enabled = uiState.hasPrevious,
                        modifier = Modifier.size(48.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SkipPrevious,
                            contentDescription = stringResource(R.string.player_prev),
                            tint = if (uiState.hasPrevious) CinemaTextPrimary else CinemaTextMuted,
                            modifier = Modifier.size(30.dp),
                        )
                    }
                    IconButton(
                        onClick = { playerViewModel.engineController.seekBySeconds(-10) },
                        modifier = Modifier.size(52.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Replay10,
                            contentDescription = stringResource(R.string.player_seek_back),
                            tint = CinemaTextPrimary,
                            modifier = Modifier.size(34.dp),
                        )
                    }
                    Surface(
                        color = CinemaGold,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(64.dp)
                            .testTag("player_play_pause_button")
                            .clickable { playerViewModel.engineController.togglePause() },
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (live.isPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                                contentDescription = if (live.isPaused) {
                                    stringResource(R.string.player_play)
                                } else {
                                    stringResource(R.string.player_pause)
                                },
                                tint = CinemaObsidian,
                                modifier = Modifier.size(36.dp),
                            )
                        }
                    }
                    IconButton(
                        onClick = { playerViewModel.engineController.seekBySeconds(10) },
                        modifier = Modifier.size(52.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Forward10,
                            contentDescription = stringResource(R.string.player_seek_forward),
                            tint = CinemaTextPrimary,
                            modifier = Modifier.size(34.dp),
                        )
                    }
                    IconButton(
                        onClick = { playerViewModel.playNextInPlaylist() },
                        enabled = uiState.hasNext,
                        modifier = Modifier.size(48.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SkipNext,
                            contentDescription = stringResource(R.string.player_next),
                            tint = if (uiState.hasNext) CinemaTextPrimary else CinemaTextMuted,
                            modifier = Modifier.size(30.dp),
                        )
                    }
                }

                // Bottom Bar: Seekbar + Action Strip
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.88f))
                            )
                        )
                        .safeDrawingPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                ) {
                    var scrubbing by remember { mutableStateOf(false) }
                    var scrubPos by remember { mutableFloatStateOf(0f) }
                    val sliderVal = if (scrubbing) scrubPos else live.positionMs.toFloat()
                    val sliderMax = effectiveDuration.coerceAtLeast(1_000L).toFloat()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = Formatters.formatDurationMs(sliderVal.toLong()),
                            style = MaterialTheme.typography.labelMedium,
                            color = CinemaTextPrimary,
                        )
                        Text(
                            text = Formatters.formatDurationMs(effectiveDuration),
                            style = MaterialTheme.typography.labelMedium,
                            color = CinemaTextSecondary,
                        )
                    }

                    Slider(
                        value = sliderVal.coerceIn(0f, sliderMax),
                        onValueChange = {
                            scrubbing = true
                            scrubPos = it
                        },
                        onValueChangeFinished = {
                            scrubbing = false
                            playerViewModel.engineController.seekToMs(scrubPos.toLong())
                        },
                        valueRange = 0f..sliderMax,
                        colors = SliderDefaults.colors(
                            thumbColor = CinemaGold,
                            activeTrackColor = CinemaGold,
                            inactiveTrackColor = CinemaBorder,
                        ),
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(onClick = { activeSheet = PlayerControlSheet.AUDIO }) {
                                Icon(Icons.Outlined.Audiotrack, contentDescription = stringResource(R.string.player_audio), tint = CinemaTextPrimary)
                            }
                            IconButton(onClick = { activeSheet = PlayerControlSheet.SUBTITLES }) {
                                Icon(Icons.Outlined.ClosedCaption, contentDescription = stringResource(R.string.player_subtitles), tint = CinemaTextPrimary)
                            }
                            if (live.chapters.isNotEmpty() || uiState.bookmarksForCurrentVideo.isNotEmpty()) {
                                IconButton(onClick = { activeSheet = PlayerControlSheet.CHAPTERS }) {
                                    Icon(Icons.Outlined.Bookmarks, contentDescription = stringResource(R.string.player_chapters), tint = CinemaTextPrimary)
                                }
                            }
                            IconButton(onClick = { activeSheet = PlayerControlSheet.SPEED }) {
                                Icon(Icons.Outlined.Speed, contentDescription = stringResource(R.string.player_speed), tint = CinemaTextPrimary)
                            }
                            IconButton(onClick = { activeSheet = PlayerControlSheet.ASPECT }) {
                                Icon(Icons.Outlined.AspectRatio, contentDescription = stringResource(R.string.player_aspect), tint = CinemaTextPrimary)
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(
                                onClick = {
                                    activity?.let { act ->
                                        val isLandscape =
                                            act.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
                                        act.requestedOrientation = if (isLandscape) {
                                            ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                                        } else {
                                            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                        }
                                    }
                                },
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.ScreenRotation,
                                    contentDescription = stringResource(R.string.player_orientation),
                                    tint = CinemaTextPrimary,
                                )
                            }
                            IconButton(onClick = { isFullscreen = !isFullscreen }) {
                                Icon(
                                    imageVector = if (isFullscreen) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                                    contentDescription = stringResource(R.string.player_fullscreen),
                                    tint = CinemaTextPrimary,
                                )
                            }
                        }
                    }
                }
            }
        }

        // 8. Live Non-Interrupting Technical & 4-Layer HDR Overlay Drawer
        AnimatedVisibility(
            visible = uiState.showTechOverlay,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .safeDrawingPadding()
                .padding(12.dp),
        ) {
            TechnicalInfoOverlayPanel(
                uiState = uiState,
                live = live,
                onRefresh = { playerViewModel.engineController.refreshLiveTelemetry() },
                onClose = { playerViewModel.toggleTechOverlay() },
            )
        }
    }

    // Control Sheets (Audio, Subtitles, Chapters/Bookmarks, Aspect Ratio, Speed)
    activeSheet?.let { sheet ->
        ModalBottomSheet(
            onDismissRequest = { activeSheet = null },
            containerColor = CinemaCharcoal,
            contentColor = CinemaTextPrimary,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                when (sheet) {
                    PlayerControlSheet.AUDIO -> {
                        Text("Audio Tracks", style = MaterialTheme.typography.titleLarge)
                        SelectableOptionRow("Disable Audio", live.currentAudioId <= 0) {
                            playerViewModel.engineController.selectAudioTrack(0)
                            activeSheet = null
                        }
                        live.audioTracks.forEach { tr ->
                            val label = buildString {
                                append("#${tr.id} ")
                                append(tr.title.ifBlank { tr.language.uppercase(Locale.US) })
                                append(" · ${tr.codec}")
                                tr.channels?.let { append(" (${it}ch)") }
                            }
                            SelectableOptionRow(label, tr.isSelected || tr.id == live.currentAudioId) {
                                playerViewModel.engineController.selectAudioTrack(tr.id)
                                activeSheet = null
                            }
                        }
                    }

                    PlayerControlSheet.SUBTITLES -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("Subtitles", style = MaterialTheme.typography.titleLarge)
                            OutlinedButton(
                                onClick = {
                                    externalSubLauncher.launch(arrayOf("*/*"))
                                    activeSheet = null
                                },
                            ) {
                                Icon(Icons.Outlined.Subtitles, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.player_load_external_sub))
                            }
                        }
                        SelectableOptionRow("Subtitles Off", live.currentSubId <= 0) {
                            playerViewModel.engineController.selectSubtitleTrack(0)
                            activeSheet = null
                        }
                        live.subtitleTracks.forEach { tr ->
                            val ext = if (tr.isExternal) " [External]" else ""
                            val label = "#${tr.id} ${tr.title.ifBlank { tr.language.uppercase(Locale.US) }} · ${tr.codec}$ext"
                            SelectableOptionRow(label, tr.isSelected || tr.id == live.currentSubId) {
                                playerViewModel.engineController.selectSubtitleTrack(tr.id)
                                activeSheet = null
                            }
                        }
                    }

                    PlayerControlSheet.CHAPTERS -> {
                        if (live.chapters.isNotEmpty()) {
                            Text("Embedded Chapters", style = MaterialTheme.typography.titleLarge)
                            live.chapters.forEach { ch ->
                                SelectableOptionRow(
                                    label = "${Formatters.formatDurationMs(ch.startTimeMs)} · ${ch.title}",
                                    selected = ch.index == live.currentChapterIndex,
                                ) {
                                    playerViewModel.engineController.selectChapter(ch.index)
                                    activeSheet = null
                                }
                            }
                        }
                        if (uiState.bookmarksForCurrentVideo.isNotEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            Text("Your Timestamp Bookmarks", style = MaterialTheme.typography.titleLarge)
                            uiState.bookmarksForCurrentVideo.forEach { bm ->
                                SelectableOptionRow(
                                    label = "${Formatters.formatDurationMs(bm.timestampMs)} · ${bm.title.ifBlank { "Saved Scene" }}",
                                    selected = false,
                                ) {
                                    playerViewModel.engineController.seekToMs(bm.timestampMs)
                                    activeSheet = null
                                }
                            }
                        }
                    }

                    PlayerControlSheet.ASPECT -> {
                        Text("Aspect Ratio Control", style = MaterialTheme.typography.titleLarge)
                        AspectRatioPreset.entries.forEach { preset ->
                            SelectableOptionRow(preset.label, uiState.activeAspectPreset == preset) {
                                playerViewModel.setAspectRatioPreset(preset)
                                activeSheet = null
                            }
                        }
                    }

                    PlayerControlSheet.SPEED -> {
                        Text("Playback Speed", style = MaterialTheme.typography.titleLarge)
                        listOf(0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5).forEach { spd ->
                            SelectableOptionRow("${spd}×", kotlin.math.abs(live.speed - spd) < 0.02) {
                                playerViewModel.engineController.setSpeed(spd)
                                activeSheet = null
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // Bookmark Current Timestamp Dialog
    if (showBookmarkDialog) {
        var title by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        var isFav by remember { mutableStateOf(true) }
        val capturedPos = live.positionMs

        AlertDialog(
            onDismissRequest = { showBookmarkDialog = false },
            containerColor = CinemaCharcoal,
            title = { Text("Bookmark ${Formatters.formatDurationMs(capturedPos)}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Scene Title (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Personal Note (optional)") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Favourite Scene")
                        Switch(checked = isFav, onCheckedChange = { isFav = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        playerViewModel.bookmarkCurrentTimestamp(title, note, isFav)
                        showBookmarkDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBookmarkDialog = false }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun SelectableOptionRow(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Surface(
        color = if (selected) CinemaGold.copy(alpha = 0.16f) else CinemaSurfaceHigh,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (selected) CinemaGold else CinemaBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = if (selected) CinemaGold else CinemaTextPrimary,
        )
    }
}

@Composable
private fun TechnicalInfoOverlayPanel(
    uiState: com.example.viewmodel.PlayerUiState,
    live: MpvEngineController.LivePlaybackState,
    onRefresh: () -> Unit,
    onClose: () -> Unit,
) {
    val stats = live.decoderStats
    val report = uiState.hdrReport

    Surface(
        color = CinemaObsidian.copy(alpha = 0.90f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CinemaBorder),
        modifier = Modifier
            .widthIn(max = 360.dp)
            .fillMaxHeight(0.82f)
            .testTag("player_tech_overlay_panel"),
    ) {
        Column(
            modifier = Modifier
                .padding(14.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Live Technical Diagnostics", style = MaterialTheme.typography.titleMedium, color = CinemaGold)
                Row {
                    TextButton(onClick = onRefresh) { Text("Refresh", color = CinemaIce) }
                    IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.cd_close), tint = CinemaTextPrimary)
                    }
                }
            }

            HorizontalDivider(color = CinemaBorderSubtle)

            if (report != null) {
                OverlayLine("1. Source Format", "${report.sourceFormat.displayName} (${report.sourceEvidence})")
                OverlayLine("2. Decoder Params", report.decoderMetadataSummary)
                OverlayLine("3. Renderer (VO)", report.rendererCapabilitySummary)
                OverlayLine("4. Display Hardware", report.displayHardwareSummary)
                Text(
                    text = report.honestyNote,
                    style = MaterialTheme.typography.bodySmall,
                    color = CinemaIce,
                )
                HorizontalDivider(color = CinemaBorderSubtle)
            }

            OverlayLine(
                "Video Geometry",
                "${stats.width}×${stats.height} → ${uiState.liveDarLabel} (PAR ${String.format(Locale.US, "%.3f", stats.par)})",
            )
            OverlayLine("Frame Rate", Formatters.formatFrameRate(stats.fps.toFloat()))
            OverlayLine("Pixel Format", "${stats.pixelFormat} (hw: ${stats.hwPixelFormat})")
            OverlayLine("Color Matrix", "${stats.primaries} / ${stats.gamma} / ${stats.colorMatrix}")
            OverlayLine(
                "Audio Stream",
                "${stats.audioCodec} · ${stats.audioChannels}ch · ${stats.audioSampleRate} Hz",
            )
        }
    }
}

@Composable
private fun OverlayLine(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = CinemaTextMuted)
        Text(text = value, style = MaterialTheme.typography.labelMedium, color = CinemaTextPrimary)
    }
}
