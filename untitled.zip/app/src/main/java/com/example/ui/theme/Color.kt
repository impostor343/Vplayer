package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark-First Cinematic Obsidian & Charcoal Palette
val CinemaObsidian = Color(0xFF090B0F)
val CinemaCharcoal = Color(0xFF11151D)
val CinemaSurface = Color(0xFF161B25)
val CinemaSurfaceHigh = Color(0xFF1E2533)
val CinemaSurfaceHighest = Color(0xFF273042)
val CinemaBorder = Color(0xFF2B3446)
val CinemaBorderSubtle = Color(0xFF1E2431)

// Accent & Typography Colors
val CinemaGold = Color(0xFFE8A838)
val CinemaGoldBright = Color(0xFFF6C25E)
val CinemaGoldContainer = Color(0xFF332610)
val CinemaIce = Color(0xFF7CB7F5)
val CinemaIceContainer = Color(0xFF15263B)
val CinemaEmerald = Color(0xFF4CC38A)
val CinemaCrimson = Color(0xFFE5646B)
val CinemaCrimsonContainer = Color(0xFF3A181B)

val CinemaTextPrimary = Color(0xFFF2F4F8)
val CinemaTextSecondary = Color(0xFF9AA5B8)
val CinemaTextMuted = Color(0xFF6B768B)

// Distinctive Video Format Indicator Accents
val FormatHdr10PlusGold = Color(0xFFF5B82E)
val FormatHdr10PlusBg = Color(0xFF241B07)
val FormatDolbyVisionViolet = Color(0xFFC4B5FD)
val FormatDolbyVisionBg = Color(0xFF171329)
val FormatHdr10Amber = Color(0xFFEB8A3E)
val FormatHdr10Bg = Color(0xFF26170A)
val FormatHlgCyan = Color(0xFF38BDF8)
val FormatHlgBg = Color(0xFF0B2230)
val FormatSdrSlate = Color(0xFF94A3B8)
val FormatSdrBg = Color(0xFF181E29)

// Syntax Highlighting Colors (mpv.conf / input.conf)
val SyntaxComment = Color(0xFF6B768B)
val SyntaxProfile = Color(0xFFF5B82E)
val SyntaxKey = Color(0xFF7CB7F5)
val SyntaxEquals = Color(0xFFE8A838)
val SyntaxValue = Color(0xFF4CC38A)
val SyntaxError = Color(0xFFE5646B)
