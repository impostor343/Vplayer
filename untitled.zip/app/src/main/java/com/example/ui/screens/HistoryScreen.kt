package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.db.PlaybackSessionEntity
import com.example.domain.HdrFormat
import com.example.domain.SessionTerminationState
import com.example.media.Formatters
import com.example.ui.components.HdrFormatBadge
import com.example.ui.theme.CinemaBorderSubtle
import com.example.ui.theme.CinemaCharcoal
import com.example.ui.theme.CinemaCrimson
import com.example.ui.theme.CinemaEmerald
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.CinemaObsidian
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceHigh
import com.example.ui.theme.CinemaTextMuted
import com.example.ui.theme.CinemaTextPrimary
import com.example.ui.theme.CinemaTextSecondary
import com.example.viewmodel.CinemaAppViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: CinemaAppViewModel,
    onPlayAtTimestamp: (String, Long?) -> Unit,
    onOpenVideoDetail: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val sessions by viewModel.allSessions.collectAsStateWithLifecycle()
    var inspectedSession by remember { mutableStateOf<PlaybackSessionEntity?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CinemaObsidian)
            .padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.history_title),
            style = MaterialTheme.typography.headlineMedium,
            color = CinemaTextPrimary,
        )
        Text(
            text = "${sessions.size} recorded session${if (sessions.size == 1) "" else "s"} · Crash-safe local log",
            style = MaterialTheme.typography.bodySmall,
            color = CinemaTextSecondary,
        )
        Spacer(Modifier.height(14.dp))

        if (sessions.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Surface(
                    color = CinemaSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CinemaBorderSubtle),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.History,
                            contentDescription = null,
                            tint = CinemaGold,
                            modifier = Modifier.size(40.dp),
                        )
                        Text(stringResource(R.string.history_empty_title), style = MaterialTheme.typography.titleLarge)
                        Text(
                            stringResource(R.string.history_empty_body),
                            style = MaterialTheme.typography.bodyMedium,
                            color = CinemaTextSecondary,
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("history_sessions_list"),
            ) {
                items(sessions, key = { it.sessionId }) { session ->
                    SessionTimelineCard(
                        session = session,
                        onInspect = { inspectedSession = session },
                        onResume = { onPlayAtTimestamp(session.videoId, session.endPositionMs) },
                    )
                }
            }
        }
    }

    inspectedSession?.let { session ->
        ModalBottomSheet(
            onDismissRequest = { inspectedSession = null },
            containerColor = CinemaCharcoal,
            contentColor = CinemaTextPrimary,
        ) {
            SessionInspectorSheet(
                session = session,
                onResume = {
                    inspectedSession = null
                    onPlayAtTimestamp(session.videoId, session.endPositionMs)
                },
                onOpenDetail = {
                    inspectedSession = null
                    onOpenVideoDetail(session.videoId)
                },
                onDelete = {
                    viewModel.deleteSession(session.sessionId)
                    inspectedSession = null
                },
            )
        }
    }
}

@Composable
private fun SessionTimelineCard(
    session: PlaybackSessionEntity,
    onInspect: () -> Unit,
    onResume: () -> Unit,
) {
    val term = SessionTerminationState.fromStored(session.terminationState)
    val hdr = HdrFormat.fromStored(session.hdrFormatSnapshot)

    Surface(
        color = CinemaSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CinemaBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onInspect),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = session.videoFilename.substringBeforeLast('.'),
                        style = MaterialTheme.typography.titleMedium,
                        color = CinemaTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = Formatters.formatDateTime(session.openedAtMillis),
                        style = MaterialTheme.typography.bodySmall,
                        color = CinemaTextSecondary,
                    )
                }
                HdrFormatBadge(format = hdr, compact = true)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "${Formatters.formatDurationMs(session.startPositionMs)} → ${Formatters.formatDurationMs(session.endPositionMs)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = CinemaTextPrimary,
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (session.isCompleted) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = "Completed",
                            tint = CinemaEmerald,
                            modifier = Modifier.size(15.dp),
                        )
                    } else if (term == SessionTerminationState.CRASH_RECOVERED || term == SessionTerminationState.INTERRUPTED) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = term.label,
                            tint = CinemaCrimson,
                            modifier = Modifier.size(15.dp),
                        )
                    }
                    Text(
                        text = "${Formatters.formatHumanDuration(session.watchedDurationMs)} · ${term.label}",
                        style = MaterialTheme.typography.labelSmall,
                        color = CinemaTextSecondary,
                    )
                }
            }

            LinearProgressIndicator(
                progress = { (session.completionPercent / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp),
                color = if (session.isCompleted) CinemaEmerald else CinemaGold,
                trackColor = CinemaSurfaceHigh,
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = String.format(Locale.US, "%.0f%% complete", session.completionPercent),
                    style = MaterialTheme.typography.labelSmall,
                    color = CinemaTextMuted,
                )
                IconButton(onClick = onResume, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = "Resume from session end", tint = CinemaGold)
                }
            }
        }
    }
}

@Composable
private fun SessionInspectorSheet(
    session: PlaybackSessionEntity,
    onResume: () -> Unit,
    onOpenDetail: () -> Unit,
    onDelete: () -> Unit,
) {
    val term = SessionTerminationState.fromStored(session.terminationState)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Session Record #${session.sessionId}", style = MaterialTheme.typography.titleLarge, color = CinemaGold)
        Text(session.videoFilename, style = MaterialTheme.typography.titleMedium, color = CinemaTextPrimary)
        HorizontalDivider(color = CinemaBorderSubtle)

        InspectorRow("Path", session.videoPath)
        InspectorRow("Session Date", Formatters.formatDateOnly(session.openedAtMillis))
        InspectorRow("Opening Time", Formatters.formatTimeOnly(session.openedAtMillis))
        InspectorRow("Closing Time", Formatters.formatTimeOnly(session.closedAtMillis))
        InspectorRow("Start Timestamp", Formatters.formatDurationMs(session.startPositionMs))
        InspectorRow("End Timestamp", Formatters.formatDurationMs(session.endPositionMs))
        InspectorRow("Total Watched", Formatters.formatHumanDuration(session.watchedDurationMs))
        InspectorRow(
            "Completion",
            "${String.format(Locale.US, "%.1f%%", session.completionPercent)} (${if (session.isCompleted) "Completed" else "In Progress"})",
        )
        InspectorRow("Termination Status", term.label)

        Spacer(Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onResume,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Resume at ${Formatters.formatDurationMs(session.endPositionMs)}")
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Outlined.Delete, contentDescription = stringResource(R.string.cd_delete), tint = CinemaCrimson)
            }
        }
        Surface(
            color = CinemaSurfaceHigh,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenDetail),
        ) {
            Box(modifier = Modifier.padding(12.dp), contentAlignment = Alignment.Center) {
                Text("Inspect Film Metadata & Review", style = MaterialTheme.typography.labelLarge, color = CinemaTextPrimary)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun InspectorRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = CinemaTextSecondary)
        Text(value, style = MaterialTheme.typography.labelMedium, color = CinemaTextPrimary)
    }
}
