package com.example.player

import android.content.Context
import android.net.Uri
import android.view.Surface
import android.view.SurfaceHolder
import com.example.domain.AspectRatioPreset
import com.example.domain.ChapterInfo
import com.example.domain.DecoderLiveStats
import com.example.domain.TrackInfo
import com.example.media.MpvConfigManager
import `is`.xyz.mpv.MPVLib
import `is`.xyz.mpv.MPVNode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File

/**
 * Wraps the real libmpv JNI engine (is.xyz.mpv.MPVLib from mpvEx's mpv-android artifact)
 * preserving hardware decoding, HDR signaling (gpu-next / libplacebo + target-colorspace-hint),
 * user mpv.conf precedence, local subtitle & audio track selection, embedded chapters,
 * aspect ratio overrides, and live video-params telemetry.
 */
class MpvEngineController(
    private val context: Context,
    private val configManager: MpvConfigManager,
) : SurfaceHolder.Callback, MPVLib.EventObserver {

    sealed interface EngineStatus {
        data object Idle : EngineStatus
        data object Ready : EngineStatus
        data class Error(val message: String) : EngineStatus
    }

    data class LivePlaybackState(
        val status: EngineStatus = EngineStatus.Idle,
        val isPaused: Boolean = false,
        val isEof: Boolean = false,
        val positionMs: Long = 0L,
        val durationMs: Long = 0L,
        val speed: Double = 1.0,
        val currentAudioId: Int = -1,
        val currentSubId: Int = -1,
        val currentChapterIndex: Int = -1,
        val audioTracks: List<TrackInfo> = emptyList(),
        val subtitleTracks: List<TrackInfo> = emptyList(),
        val chapters: List<ChapterInfo> = emptyList(),
        val decoderStats: DecoderLiveStats = DecoderLiveStats(),
    )

    private val _state = MutableStateFlow(LivePlaybackState())
    val state: StateFlow<LivePlaybackState> = _state.asStateFlow()

    private val engineLock = Any()

    @Volatile
    private var isInitialized = false
    private var attachedSurface: Surface? = null
    private var surfaceWidth: Int = 0
    private var surfaceHeight: Int = 0
    private var preferredVo: String = "gpu-next"
    private var pendingUri: Uri? = null
    private var pendingStartPositionMs: Long = 0L
    private var pendingFileLoadSeekMs: Long = 0L

    fun initialize(): Boolean = synchronized(engineLock) {
        if (isInitialized) return true
        try {
            configManager.ensureInitialized()
            preferredVo = MpvConfigManager.extractConfiguredVo(configManager.readMpvConf())

            MPVLib.create(context.applicationContext)

            // CRITICAL libmpv precedence rule:
            // Options passed via setOptionString() before init() override mpv.conf.
            // Only enforce config loading, offline hardening, and temporary vo=null until
            // Android's SurfaceHolder attaches — let mpv.conf govern vo, hwdec, HDR, and audio!
            MPVLib.setOptionString("config", "yes")
            MPVLib.setOptionString("config-dir", configManager.configDir.absolutePath)
            MPVLib.setOptionString("ytdl", "no")
            MPVLib.setOptionString("load-scripts", "no")
            MPVLib.setOptionString("force-window", "no")
            MPVLib.setOptionString("vo", "null")

            MPVLib.init()
            MPVLib.addObserver(this)
            observeCoreProperties()

            isInitialized = true
            _state.update { it.copy(status = EngineStatus.Ready) }

            val surf = attachedSurface
            if (surf != null && surf.isValid) {
                attachSurfaceAndEnableVoLocked(surf, surfaceWidth, surfaceHeight)
                flushPendingMediaLocked()
            }
            true
        } catch (t: Throwable) {
            _state.update {
                it.copy(
                    status = EngineStatus.Error(
                        "Native libmpv engine could not initialize on this runtime: ${t.message ?: t::class.simpleName}"
                    )
                )
            }
            false
        }
    }

    private fun attachSurfaceAndEnableVoLocked(surface: Surface, width: Int, height: Int) {
        preferredVo = MpvConfigManager.extractConfiguredVo(configManager.readMpvConf())
        MPVLib.attachSurface(surface)
        if (width > 0 && height > 0) {
            runCatching { MPVLib.setPropertyString("android-surface-size", "${width}x${height}") }
        }
        runCatching { MPVLib.setPropertyString("force-window", "yes") }

        val appliedPrimary = runCatching {
            MPVLib.setPropertyString("vo", preferredVo)
            true
        }.getOrDefault(false)

        // Automatic fallback from gpu-next -> gpu if an older GPU/driver rejects libplacebo
        if (!appliedPrimary && preferredVo != "gpu") {
            runCatching { MPVLib.setPropertyString("vo", "gpu") }
        }
    }

    private fun observeCoreProperties() {
        MPVLib.observeProperty("time-pos", MPV_FORMAT_DOUBLE)
        MPVLib.observeProperty("duration", MPV_FORMAT_DOUBLE)
        MPVLib.observeProperty("pause", MPV_FORMAT_FLAG)
        MPVLib.observeProperty("eof-reached", MPV_FORMAT_FLAG)
        MPVLib.observeProperty("speed", MPV_FORMAT_DOUBLE)
        MPVLib.observeProperty("aid", MPV_FORMAT_INT64)
        MPVLib.observeProperty("sid", MPV_FORMAT_INT64)
        MPVLib.observeProperty("chapter", MPV_FORMAT_INT64)
        MPVLib.observeProperty("track-list/count", MPV_FORMAT_INT64)
        MPVLib.observeProperty("chapter-list/count", MPV_FORMAT_INT64)
        MPVLib.observeProperty("video-params/primaries", MPV_FORMAT_STRING)
        MPVLib.observeProperty("video-params/gamma", MPV_FORMAT_STRING)
        MPVLib.observeProperty("video-params/pixelformat", MPV_FORMAT_STRING)
        MPVLib.observeProperty("hwdec-current", MPV_FORMAT_STRING)
        MPVLib.observeProperty("current-vo", MPV_FORMAT_STRING)
    }

    fun loadMedia(uri: Uri, startPositionMs: Long = 0L) = synchronized(engineLock) {
        if (!isInitialized) {
            pendingUri = uri
            pendingStartPositionMs = startPositionMs
            if (!initialize()) return
            if (pendingUri == null) return // Already flushed during initialize()
        }
        if (attachedSurface == null || attachedSurface?.isValid != true) {
            // Defer loadfile until Android SurfaceView delivers a valid Surface
            pendingUri = uri
            pendingStartPositionMs = startPositionMs
            return
        }
        loadMediaLocked(uri, startPositionMs)
    }

    private fun flushPendingMediaLocked() {
        val uri = pendingUri ?: return
        val start = pendingStartPositionMs
        pendingUri = null
        pendingStartPositionMs = 0L
        loadMediaLocked(uri, start)
    }

    private fun loadMediaLocked(uri: Uri, startPositionMs: Long) {
        try {
            val mpvTarget = resolveMpvPlayableTarget(uri)
            if (mpvTarget == null) {
                _state.update { it.copy(status = EngineStatus.Error("Unable to open local file descriptor for $uri")) }
                return
            }
            if (startPositionMs > 1_000L) {
                val startSec = startPositionMs / 1000.0
                pendingFileLoadSeekMs = startPositionMs
                runCatching { MPVLib.setPropertyString("start", "+$startSec") }
            } else {
                pendingFileLoadSeekMs = 0L
                runCatching { MPVLib.setPropertyString("start", "none") }
            }
            MPVLib.command("loadfile", mpvTarget, "replace")
            MPVLib.setPropertyBoolean("pause", false)
            _state.update { it.copy(status = EngineStatus.Ready, isEof = false) }
        } catch (t: Throwable) {
            _state.update {
                it.copy(status = EngineStatus.Error("Playback start failed: ${t.message ?: "unknown error"}"))
            }
        }
    }

    private fun resolveMpvPlayableTarget(uri: Uri): String? {
        return when (uri.scheme) {
            "file" -> uri.path?.takeIf { File(it).exists() }
            "content" -> {
                val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return null
                // fdclose:// transfers fd ownership cleanly to libmpv so it closes when done
                "fdclose://${pfd.detachFd()}"
            }
            else -> uri.toString()
        }
    }

    fun togglePause() {
        synchronized(engineLock) {
            if (!isInitialized) return
            val next = !(_state.value.isPaused)
            runCatching { MPVLib.setPropertyBoolean("pause", next) }
        }
    }

    fun setPaused(paused: Boolean) {
        synchronized(engineLock) {
            if (!isInitialized) return
            runCatching { MPVLib.setPropertyBoolean("pause", paused) }
        }
    }

    fun seekToMs(positionMs: Long) {
        synchronized(engineLock) {
            if (!isInitialized) return
            val sec = (positionMs.coerceAtLeast(0L) / 1000.0).toString()
            runCatching { MPVLib.command("seek", sec, "absolute", "exact") }
        }
    }

    fun seekBySeconds(deltaSeconds: Int) {
        synchronized(engineLock) {
            if (!isInitialized) return
            runCatching { MPVLib.command("seek", deltaSeconds.toString(), "relative") }
        }
    }

    fun setSpeed(speed: Double) {
        synchronized(engineLock) {
            if (!isInitialized) return
            val clamped = speed.coerceIn(0.25, 4.0)
            runCatching { MPVLib.setPropertyDouble("speed", clamped) }
        }
    }

    fun selectAudioTrack(trackId: Int) {
        synchronized(engineLock) {
            if (!isInitialized) return
            runCatching {
                if (trackId <= 0) MPVLib.setPropertyString("aid", "no")
                else MPVLib.setPropertyInt("aid", trackId)
                refreshTracksAndChaptersLocked()
            }
        }
    }

    fun selectSubtitleTrack(trackId: Int) {
        synchronized(engineLock) {
            if (!isInitialized) return
            runCatching {
                if (trackId <= 0) MPVLib.setPropertyString("sid", "no")
                else MPVLib.setPropertyInt("sid", trackId)
                refreshTracksAndChaptersLocked()
            }
        }
    }

    fun addExternalSubtitle(uri: Uri): Boolean = synchronized(engineLock) {
        if (!isInitialized) return false
        runCatching {
            val target = resolveMpvPlayableTarget(uri) ?: return false
            MPVLib.command("sub-add", target, "select")
            refreshTracksAndChaptersLocked()
            true
        }.getOrDefault(false)
    }

    fun selectChapter(index: Int) {
        synchronized(engineLock) {
            if (!isInitialized) return
            runCatching { MPVLib.setPropertyInt("chapter", index) }
        }
    }

    fun applyAspectRatioPreset(preset: AspectRatioPreset) {
        synchronized(engineLock) {
            if (!isInitialized) return
            runCatching {
                when (preset) {
                    AspectRatioPreset.FILL_CROP -> {
                        MPVLib.setPropertyString("video-aspect-override", "-1")
                        MPVLib.setPropertyDouble("panscan", 1.0)
                    }
                    else -> {
                        MPVLib.setPropertyDouble("panscan", 0.0)
                        MPVLib.setPropertyString("video-aspect-override", preset.mpvValue)
                    }
                }
            }
        }
    }

    fun refreshLiveTelemetry() = synchronized(engineLock) {
        if (!isInitialized) return
        refreshLiveTelemetryLocked()
    }

    private fun refreshLiveTelemetryLocked() {
        runCatching {
            val stats = DecoderLiveStats(
                videoCodec = MPVLib.getPropertyString("video-codec") ?: "—",
                hwDecCurrent = MPVLib.getPropertyString("hwdec-current") ?: "software",
                currentVo = MPVLib.getPropertyString("current-vo") ?: "—",
                width = MPVLib.getPropertyInt("video-params/w") ?: 0,
                height = MPVLib.getPropertyInt("video-params/h") ?: 0,
                displayWidth = MPVLib.getPropertyInt("video-params/dw") ?: 0,
                displayHeight = MPVLib.getPropertyInt("video-params/dh") ?: 0,
                par = MPVLib.getPropertyDouble("video-params/par") ?: 1.0,
                aspect = MPVLib.getPropertyDouble("video-params/aspect") ?: 0.0,
                fps = MPVLib.getPropertyDouble("container-fps")
                    ?: MPVLib.getPropertyDouble("estimated-vf-fps")
                    ?: 0.0,
                pixelFormat = MPVLib.getPropertyString("video-params/pixelformat") ?: "—",
                hwPixelFormat = MPVLib.getPropertyString("video-params/hw-pixelformat") ?: "—",
                primaries = MPVLib.getPropertyString("video-params/primaries") ?: "—",
                gamma = MPVLib.getPropertyString("video-params/gamma") ?: "—",
                colorMatrix = MPVLib.getPropertyString("video-params/colormatrix") ?: "—",
                sigPeak = MPVLib.getPropertyDouble("video-params/sig-peak"),
                maxLuma = MPVLib.getPropertyDouble("video-params/max-luma"),
                targetColorspaceHint = MPVLib.getPropertyBoolean("target-colorspace-hint") ?: false,
                toneMappingMode = MPVLib.getPropertyString("tone-mapping") ?: "auto",
                audioCodec = MPVLib.getPropertyString("audio-codec-name")
                    ?: MPVLib.getPropertyString("audio-codec")
                    ?: "—",
                audioChannels = MPVLib.getPropertyInt("audio-params/channel-count") ?: 0,
                audioSampleRate = MPVLib.getPropertyInt("audio-params/samplerate") ?: 0,
            )
            _state.update { it.copy(decoderStats = stats) }
        }
    }

    fun refreshTracksAndChapters() = synchronized(engineLock) {
        if (!isInitialized) return
        refreshTracksAndChaptersLocked()
    }

    private fun refreshTracksAndChaptersLocked() {
        runCatching {
            val trackCount = MPVLib.getPropertyInt("track-list/count") ?: 0
            val audio = mutableListOf<TrackInfo>()
            val subs = mutableListOf<TrackInfo>()
            for (i in 0 until trackCount) {
                val type = MPVLib.getPropertyString("track-list/$i/type") ?: continue
                val id = MPVLib.getPropertyInt("track-list/$i/id") ?: continue
                val title = MPVLib.getPropertyString("track-list/$i/title") ?: ""
                val lang = MPVLib.getPropertyString("track-list/$i/lang") ?: "und"
                val codec = MPVLib.getPropertyString("track-list/$i/codec") ?: "unknown"
                val selected = MPVLib.getPropertyBoolean("track-list/$i/selected") ?: false
                val isDefault = MPVLib.getPropertyBoolean("track-list/$i/default") ?: false
                val isExternal = MPVLib.getPropertyBoolean("track-list/$i/external") ?: false
                val channels = MPVLib.getPropertyInt("track-list/$i/demux-channel-count")
                val info = TrackInfo(
                    id = id,
                    type = type,
                    title = title,
                    language = lang,
                    codec = codec,
                    channels = channels,
                    isDefault = isDefault,
                    isSelected = selected,
                    isExternal = isExternal,
                )
                when (type) {
                    "audio" -> audio += info
                    "sub" -> subs += info
                }
            }

            val chapterCount = MPVLib.getPropertyInt("chapter-list/count") ?: 0
            val chapters = (0 until chapterCount).mapNotNull { i ->
                val title = MPVLib.getPropertyString("chapter-list/$i/title") ?: "Chapter ${i + 1}"
                val timeSec = MPVLib.getPropertyDouble("chapter-list/$i/time") ?: return@mapNotNull null
                ChapterInfo(index = i, title = title, startTimeMs = (timeSec * 1000.0).toLong())
            }

            _state.update {
                it.copy(
                    audioTracks = audio,
                    subtitleTracks = subs,
                    chapters = chapters,
                )
            }
        }
    }

    fun release() = synchronized(engineLock) {
        pendingUri = null
        pendingStartPositionMs = 0L
        pendingFileLoadSeekMs = 0L
        if (!isInitialized) return
        isInitialized = false
        runCatching {
            MPVLib.removeObserver(this)
            MPVLib.setPropertyString("vo", "null")
            MPVLib.detachSurface()
            MPVLib.destroy()
        }
        attachedSurface = null
    }

    // ---- SurfaceHolder.Callback ----

    override fun surfaceCreated(holder: SurfaceHolder) = synchronized(engineLock) {
        attachedSurface = holder.surface
        val frame = holder.surfaceFrame
        if (frame != null && frame.width() > 0 && frame.height() > 0) {
            surfaceWidth = frame.width()
            surfaceHeight = frame.height()
        }
        if (isInitialized && holder.surface.isValid) {
            runCatching {
                attachSurfaceAndEnableVoLocked(holder.surface, surfaceWidth, surfaceHeight)
                flushPendingMediaLocked()
            }
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = synchronized(engineLock) {
        surfaceWidth = width
        surfaceHeight = height
        if (isInitialized && width > 0 && height > 0) {
            runCatching { MPVLib.setPropertyString("android-surface-size", "${width}x${height}") }
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) = synchronized(engineLock) {
        attachedSurface = null
        if (isInitialized) {
            runCatching {
                MPVLib.setPropertyBoolean("pause", true)
                MPVLib.setPropertyString("vo", "null")
                MPVLib.setPropertyString("force-window", "no")
                MPVLib.detachSurface()
            }
        }
    }

    // ---- MPVLib.EventObserver ----

    override fun eventProperty(property: String) {
        // Untyped notification
    }

    override fun eventProperty(property: String, value: Long) {
        when (property) {
            "aid" -> _state.update { it.copy(currentAudioId = value.toInt()) }
            "sid" -> _state.update { it.copy(currentSubId = value.toInt()) }
            "chapter" -> _state.update { it.copy(currentChapterIndex = value.toInt()) }
            "track-list/count", "chapter-list/count" -> refreshTracksAndChapters()
        }
    }

    override fun eventProperty(property: String, value: Boolean) {
        when (property) {
            "pause" -> _state.update { it.copy(isPaused = value) }
            "eof-reached" -> _state.update { it.copy(isEof = value) }
        }
    }

    override fun eventProperty(property: String, value: String) {
        when (property) {
            "video-params/primaries",
            "video-params/gamma",
            "video-params/pixelformat",
            "hwdec-current",
            "current-vo",
            -> refreshLiveTelemetry()
        }
    }

    override fun eventProperty(property: String, value: Double) {
        when (property) {
            "time-pos" -> _state.update { it.copy(positionMs = (value * 1000.0).toLong().coerceAtLeast(0L)) }
            "duration" -> _state.update { it.copy(durationMs = (value * 1000.0).toLong().coerceAtLeast(0L)) }
            "speed" -> _state.update { it.copy(speed = value) }
        }
    }

    override fun eventProperty(property: String, value: MPVNode) {
        // Structured node notifications handled via targeted property reads
    }

    override fun event(eventId: Int, data: MPVNode) {
        if (eventId == MPV_EVENT_FILE_LOADED) {
            synchronized(engineLock) {
                if (!isInitialized) return
                // Fallback from gpu-next -> gpu if current-vo failed to initialize on this GPU
                val activeVo = runCatching { MPVLib.getPropertyString("current-vo") }.getOrNull()
                if ((activeVo.isNullOrBlank() || activeVo == "null") && preferredVo != "gpu" && attachedSurface?.isValid == true) {
                    runCatching { MPVLib.setPropertyString("vo", "gpu") }
                }
                // Guarantee bookmark / resume timestamp seek if `start` property was ignored post-init
                val targetSeek = pendingFileLoadSeekMs
                pendingFileLoadSeekMs = 0L
                if (targetSeek > 1_000L) {
                    val curSec = runCatching { MPVLib.getPropertyDouble("time-pos") }.getOrNull() ?: 0.0
                    if (kotlin.math.abs((curSec * 1000.0) - targetSeek) > 2_000.0) {
                        val sec = (targetSeek / 1000.0).toString()
                        runCatching { MPVLib.command("seek", sec, "absolute", "exact") }
                    }
                }
                refreshTracksAndChaptersLocked()
                refreshLiveTelemetryLocked()
            }
        } else if (eventId == MPV_EVENT_VIDEO_RECONFIG) {
            refreshTracksAndChapters()
            refreshLiveTelemetry()
        }
    }

    companion object {
        // Stable libmpv C ABI constants from mpv/client.h
        private const val MPV_FORMAT_STRING = 1
        private const val MPV_FORMAT_FLAG = 3
        private const val MPV_FORMAT_INT64 = 4
        private const val MPV_FORMAT_DOUBLE = 5

        private const val MPV_EVENT_FILE_LOADED = 8
        private const val MPV_EVENT_VIDEO_RECONFIG = 17
    }
}
