package com.example

import com.example.domain.ConfigValidationIssue
import com.example.domain.DecoderLiveStats
import com.example.domain.DisplayHdrCapabilities
import com.example.domain.HdrFormat
import com.example.media.AspectRatioCalculator
import com.example.media.HdrInspector
import com.example.media.MpvConfigManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PersonalCinemaLogicTest {

    // ---- Aspect Ratio Calculations ----

    @Test
    fun `cinematic 2_39 and 2_40 aspect ratios are accurately distinguished`() {
        val scope240 = AspectRatioCalculator.calculate(3840, 1600)
        assertEquals("2.40:1", scope240.formattedLabel)

        val scope239 = AspectRatioCalculator.calculate(1920, 804)
        assertEquals("2.39:1", scope239.formattedLabel)
    }

    @Test
    fun `standard cinema and broadcast aspect ratios map accurately`() {
        assertEquals("1.90:1", AspectRatioCalculator.calculate(4096, 2160).formattedLabel)
        assertEquals("1.85:1", AspectRatioCalculator.calculate(1998, 1080).formattedLabel)
        assertEquals("1.78:1", AspectRatioCalculator.calculate(3840, 2160).formattedLabel)
        assertEquals("1.33:1", AspectRatioCalculator.calculate(1440, 1080).formattedLabel)
    }

    @Test
    fun `anamorphic SAR and rotation affect true display aspect ratio`() {
        // 1440x1080 with 4:3 SAR = 1920x1080 = 1.78:1 (NOT 4:3!)
        val anamorphic = AspectRatioCalculator.calculate(1440, 1080, sarNum = 4, sarDen = 3)
        assertEquals("1.78:1", anamorphic.formattedLabel)
        assertEquals(1920, anamorphic.displayWidth)

        // 1920x1080 rotated 90 degrees -> vertical 0.56:1
        val rotated = AspectRatioCalculator.calculate(1920, 1080, rotationDegrees = 90)
        assertEquals("0.56:1", rotated.formattedLabel)
    }

    @Test
    fun `missing or corrupted zero dimensions return Unknown safely`() {
        val invalid = AspectRatioCalculator.calculate(0, 0)
        assertEquals("Unknown", invalid.formattedLabel)
        assertEquals(0.0, invalid.darValue, 0.0001)
    }

    // ---- Strict HDR & HDR10+ Honesty ----

    @Test
    fun `HDR10 static PQ does NOT falsely claim HDR10+ dynamic metadata`() {
        val (format, evidence) = HdrInspector.classifySourceFormat(
            mimeType = "video/hevc",
            codecProfileName = "HEVC Main 10 HDR10",
            colorPrimaries = "BT.2020",
            transferCharacteristics = "PQ (SMPTE ST 2084)",
            hasHdr10PlusDynamicMetadata = false,
            hasDolbyVisionConfig = false,
        )
        assertEquals(HdrFormat.HDR10, format)
        assertTrue(evidence.contains("no HDR10+", ignoreCase = true))
    }

    @Test
    fun `verified HDR10+ dynamic metadata is identified distinctly`() {
        val (format, _) = HdrInspector.classifySourceFormat(
            mimeType = "video/hevc",
            codecProfileName = "HEVC Main 10 HDR10+",
            colorPrimaries = "BT.2020",
            transferCharacteristics = "PQ (SMPTE ST 2084)",
            hasHdr10PlusDynamicMetadata = true,
            hasDolbyVisionConfig = false,
        )
        assertEquals(HdrFormat.HDR10_PLUS, format)
    }

    @Test
    fun `Dolby Vision, HLG, and SDR classify accurately`() {
        val (dv, _) = HdrInspector.classifySourceFormat(
            mimeType = "video/dolby-vision",
            codecProfileName = "Dolby Vision Profile 8.1",
            colorPrimaries = "BT.2020",
            transferCharacteristics = "PQ (SMPTE ST 2084)",
            hasHdr10PlusDynamicMetadata = false,
            hasDolbyVisionConfig = true,
        )
        assertEquals(HdrFormat.DOLBY_VISION, dv)

        val (hlg, _) = HdrInspector.classifySourceFormat(
            mimeType = "video/hevc",
            codecProfileName = "HEVC Main 10",
            colorPrimaries = "BT.2020",
            transferCharacteristics = "HLG (ARIB STD-B67)",
            hasHdr10PlusDynamicMetadata = false,
            hasDolbyVisionConfig = false,
        )
        assertEquals(HdrFormat.HLG, hlg)

        val (sdr, _) = HdrInspector.classifySourceFormat(
            mimeType = "video/avc",
            codecProfileName = "H.264",
            colorPrimaries = "BT.709",
            transferCharacteristics = "SDR (BT.709)",
            hasHdr10PlusDynamicMetadata = false,
            hasDolbyVisionConfig = false,
        )
        assertEquals(HdrFormat.SDR, sdr)
    }

    @Test
    fun `SDR display never claims HDR output even when source is HDR10+`() {
        val sdrDisplay = DisplayHdrCapabilities(
            isDisplayHdrCapable = false,
            supportsDolbyVision = false,
            supportsHdr10Plus = false,
            supportsHdr10 = false,
            supportsHlg = false,
            maxLuminanceNits = null,
            maxAverageLuminanceNits = null,
            minLuminanceNits = null,
            wideColorGamutSupported = false,
            summary = "SDR Display Only",
        )
        val live = DecoderLiveStats(
            videoCodec = "hevc",
            hwDecCurrent = "mediacodec-copy",
            currentVo = "gpu",
            primaries = "bt.2020",
            gamma = "pq",
            targetColorspaceHint = true,
        )
        val report = HdrInspector.buildPipelineReport(
            sourceFormat = HdrFormat.HDR10_PLUS,
            sourceEvidence = "SMPTE ST 2094-40",
            liveStats = live,
            displayCaps = sdrDisplay,
        )
        assertFalse(report.isDisplayOutputtingHdrLikely)
        assertTrue(report.honestyNote.contains("tone-map", ignoreCase = true))
    }

    // ---- mpv.conf & input.conf Validation ----

    @Test
    fun `default HDR mpv config and input config pass validation cleanly`() {
        val mpvRes = MpvConfigManager.validateMpvConf(MpvConfigManager.DEFAULT_HDR_MPV_CONF)
        assertTrue(mpvRes.isValid)
        assertTrue(mpvRes.issues.none { it.severity == ConfigValidationIssue.Severity.ERROR })

        val inputRes = MpvConfigManager.validateInputConf(MpvConfigManager.DEFAULT_INPUT_CONF)
        assertTrue(inputRes.isValid)
    }

    @Test
    fun `malformed mpv config flags errors and offline network warning`() {
        val broken = """
            [unclosed-profile
            vo=gpu
            vo=gpu
            ytdl=yes
            bad line without equals
        """.trimIndent()
        val res = MpvConfigManager.validateMpvConf(broken)
        assertFalse(res.isValid)
        assertTrue(res.issues.any { it.severity == ConfigValidationIssue.Severity.ERROR && it.lineNumber == 1 })
        assertTrue(res.issues.any { it.severity == ConfigValidationIssue.Severity.WARNING && it.message.contains("Duplicate") })
        assertTrue(res.issues.any { it.severity == ConfigValidationIssue.Severity.WARNING && it.message.contains("offline") })
        assertTrue(res.issues.any { it.severity == ConfigValidationIssue.Severity.ERROR && it.lineNumber == 5 })
    }

    @Test
    fun `extractConfiguredVo respects top-level mpv conf vo and ignores profile sections`() {
        assertEquals("gpu-next", MpvConfigManager.extractConfiguredVo(MpvConfigManager.DEFAULT_HDR_MPV_CONF))
        assertEquals("gpu", MpvConfigManager.extractConfiguredVo(MpvConfigManager.CLASSIC_GPU_MPV_CONF))
        assertTrue(MpvConfigManager.validateMpvConf(MpvConfigManager.CLASSIC_GPU_MPV_CONF).isValid)

        val custom = """
            # comment vo=invalid
            vo=gpu # inline comment
            [high-quality]
            vo=gpu-next
        """.trimIndent()
        assertEquals("gpu", MpvConfigManager.extractConfiguredVo(custom))

        // Missing or null vo safely falls back to gpu-next
        assertEquals("gpu-next", MpvConfigManager.extractConfiguredVo("hwdec=mediacodec-copy"))
        assertEquals("gpu-next", MpvConfigManager.extractConfiguredVo("vo=null"))
    }
}
