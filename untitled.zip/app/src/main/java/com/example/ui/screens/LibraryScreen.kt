package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.VideoFile
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Hd
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.SubdirectoryArrowRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.db.WatchedFolderEntity
import com.example.domain.DisplayHdrCapabilities
import com.example.domain.HdrFormat
import com.example.domain.LibraryFilterState
import com.example.domain.LibrarySortOption
import com.example.domain.WatchedStatus
import com.example.media.Formatters
import com.example.ui.components.AspectRatioBadge
import com.example.ui.components.HdrFormatBadge
import com.example.ui.components.LocalThumbnailImage
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaBorderSubtle
import com.example.ui.theme.CinemaCharcoal
import com.example.ui.theme.CinemaEmerald
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.CinemaGoldContainer
import com.example.ui.theme.CinemaObsidian
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceHigh
import com.example.ui.theme.CinemaTextMuted
import com.example.ui.theme.CinemaTextPrimary
import com.example.ui.theme.CinemaTextSecondary
import com.example.viewmodel.CinemaAppViewModel
import com.example.viewmodel.LibraryVideoItem
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: CinemaAppViewModel,
    onOpenVideoDetail: (String) -> Unit,
    onPlayVideo: (String, Long?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val folders by viewModel.folders.collectAsStateWithLifecycle()
    val items by viewModel.filteredLibraryItems.collectAsStateWithLifecycle()
    val filter by viewModel.filterState.collectAsStateWithLifecycle()
    val subfolders by viewModel.availableSubfolders.collectAsStateWithLifecycle()
    val availableTags by viewModel.availableTags.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
    val displayCaps = viewModel.displayHdrCapabilities

    var showFilterSheet by remember { mutableStateOf(false) }

    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree(),
    ) { uri: Uri? ->
        if (uri != null) viewModel.addWatchedFolder(uri)
    }

    val singleVideoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.openSingleVideo(uri) { videoId ->
                onPlayVideo(videoId, null)
            }
        }
    }

    val activeFilterCount = listOfNotNull(
        filter.hdrFilter,
        filter.watchedFilter,
        if (filter.favouritesOnly) true else null,
        if (filter.minRating > 0f) filter.minRating else null,
        filter.selectedTag,
        filter.aspectRatioFilter,
    ).size

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CinemaObsidian)
            .padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(12.dp))

        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.library_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = CinemaTextPrimary,
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Shield,
                        contentDescription = null,
                        tint = CinemaEmerald,
                        modifier = Modifier.size(13.dp),
                    )
                    Text(
                        text = "Offline Local Vault · ${items.size} film${if (items.size == 1) "" else "s"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = CinemaTextSecondary,
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                IconButton(
                    onClick = { singleVideoPickerLauncher.launch(arrayOf("video/*")) },
                    modifier = Modifier.testTag("open_single_video_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.VideoFile,
                        contentDescription = stringResource(R.string.library_open_file),
                        tint = CinemaTextPrimary,
                    )
                }
                IconButton(
                    onClick = { folderPickerLauncher.launch(null) },
                    modifier = Modifier.testTag("add_folder_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.CreateNewFolder,
                        contentDescription = stringResource(R.string.library_add_folder),
                        tint = CinemaGold,
                    )
                }
                IconButton(
                    onClick = { viewModel.rescanLibrary() },
                    modifier = Modifier.testTag("rescan_library_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Refresh,
                        contentDescription = stringResource(R.string.library_rescan),
                        tint = CinemaTextSecondary,
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Display Hardware Capability Strip (Honest hardware status)
        DisplayHardwareStrip(displayCaps = displayCaps)

        if (isScanning) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = CinemaGold,
                trackColor = CinemaSurfaceHigh,
            )
        }

        Spacer(Modifier.height(10.dp))

        // Search + View Toggle + Sort/Filter Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = filter.query,
                onValueChange = { q -> viewModel.updateFilter { it.copy(query = q) } },
                modifier = Modifier
                    .weight(1f)
                    .testTag("library_search_input"),
                placeholder = {
                    Text(
                        text = stringResource(R.string.library_search_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = CinemaTextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                },
                leadingIcon = {
                    Icon(Icons.Outlined.Search, contentDescription = null, tint = CinemaTextSecondary)
                },
                trailingIcon = {
                    if (filter.query.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateFilter { it.copy(query = "") } }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search", tint = CinemaTextSecondary)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CinemaGold,
                    unfocusedBorderColor = CinemaBorder,
                    focusedContainerColor = CinemaSurface,
                    unfocusedContainerColor = CinemaSurface,
                    focusedTextColor = CinemaTextPrimary,
                    unfocusedTextColor = CinemaTextPrimary,
                ),
            )

            Surface(
                color = if (activeFilterCount > 0) CinemaGoldContainer else CinemaSurface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (activeFilterCount > 0) CinemaGold else CinemaBorder),
                modifier = Modifier
                    .size(52.dp)
                    .testTag("library_filter_button")
                    .clickable { showFilterSheet = true },
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Outlined.Tune,
                        contentDescription = stringResource(R.string.library_sort_filter),
                        tint = if (activeFilterCount > 0) CinemaGold else CinemaTextPrimary,
                    )
                }
            }

            Surface(
                color = CinemaSurface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CinemaBorder),
                modifier = Modifier
                    .size(52.dp)
                    .testTag("library_layout_toggle")
                    .clickable { viewModel.updateFilter { it.copy(isGridLayout = !it.isGridLayout) } },
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (filter.isGridLayout) Icons.AutoMirrored.Rounded.ViewList else Icons.Rounded.GridView,
                        contentDescription = if (filter.isGridLayout) {
                            stringResource(R.string.library_list_view)
                        } else {
                            stringResource(R.string.library_grid_view)
                        },
                        tint = CinemaTextPrimary,
                    )
                }
            }
        }

        // Folder Selector Row
        if (folders.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            FolderSelectorBar(
                folders = folders,
                selectedFolderUri = filter.selectedFolderUri,
                onSelectFolder = { uri ->
                    viewModel.updateFilter { it.copy(selectedFolderUri = uri, selectedSubfolder = null) }
                },
                onRemoveFolder = { uri -> viewModel.removeFolder(uri) },
            )
        }

        // Subfolder Navigation Strip
        if (subfolders.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Rounded.SubdirectoryArrowRight,
                    contentDescription = null,
                    tint = CinemaTextMuted,
                    modifier = Modifier.size(16.dp),
                )
                FilterChip(
                    selected = filter.selectedSubfolder == null,
                    onClick = { viewModel.updateFilter { it.copy(selectedSubfolder = null) } },
                    label = { Text("Root", style = MaterialTheme.typography.labelMedium) },
                )
                subfolders.forEach { sub ->
                    FilterChip(
                        selected = filter.selectedSubfolder == sub,
                        onClick = {
                            viewModel.updateFilter {
                                it.copy(selectedSubfolder = if (it.selectedSubfolder == sub) null else sub)
                            }
                        },
                        label = { Text(sub, style = MaterialTheme.typography.labelMedium) },
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // Main Library Grid / List / Empty State
        if (items.isEmpty()) {
            LibraryEmptyState(
                hasFolders = folders.isNotEmpty(),
                hasFilters = activeFilterCount > 0 || filter.query.isNotBlank(),
                onAddFolder = { folderPickerLauncher.launch(null) },
                onOpenSingleVideo = { singleVideoPickerLauncher.launch(arrayOf("video/*")) },
                onResetFilters = { viewModel.resetFilters() },
            )
        } else if (filter.isGridLayout) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 172.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("library_video_grid"),
            ) {
                items(items, key = { it.metadata.videoId }) { item ->
                    VideoGridCard(
                        item = item,
                        onClick = { onOpenVideoDetail(item.metadata.videoId) },
                        onPlay = { onPlayVideo(item.metadata.videoId, null) },
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("library_video_list"),
            ) {
                items(items, key = { it.metadata.videoId }) { item ->
                    VideoListRow(
                        item = item,
                        onClick = { onOpenVideoDetail(item.metadata.videoId) },
                        onPlay = { onPlayVideo(item.metadata.videoId, null) },
                    )
                }
            }
        }
    }

    if (showFilterSheet) {
        ModalBottomSheet(
            onDismissRequest = { showFilterSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = CinemaCharcoal,
            contentColor = CinemaTextPrimary,
        ) {
            LibrarySortFilterSheet(
                filter = filter,
                availableTags = availableTags,
                onUpdate = { viewModel.updateFilter(it) },
                onReset = { viewModel.resetFilters() },
                onDismiss = { showFilterSheet = false },
            )
        }
    }
}

@Composable
private fun DisplayHardwareStrip(displayCaps: DisplayHdrCapabilities) {
    Surface(
        color = CinemaSurface,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, CinemaBorderSubtle),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(
                imageVector = Icons.Rounded.Hd,
                contentDescription = null,
                tint = if (displayCaps.isDisplayHdrCapable) CinemaGold else CinemaTextMuted,
                modifier = Modifier.size(18.dp),
            )
            Text(
                text = "Display: ${displayCaps.summary}",
                style = MaterialTheme.typography.bodySmall,
                color = CinemaTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun FolderSelectorBar(
    folders: List<WatchedFolderEntity>,
    selectedFolderUri: String?,
    onSelectFolder: (String?) -> Unit,
    onRemoveFolder: (String) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FilterChip(
            selected = selectedFolderUri == null,
            onClick = { onSelectFolder(null) },
            leadingIcon = {
                Icon(Icons.Outlined.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
            },
            label = { Text(stringResource(R.string.library_all_folders)) },
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = CinemaGoldContainer,
                selectedLabelColor = CinemaGold,
                selectedLeadingIconColor = CinemaGold,
            ),
        )
        folders.forEach { folder ->
            val selected = selectedFolderUri == folder.folderUri
            FilterChip(
                selected = selected,
                onClick = { onSelectFolder(if (selected) null else folder.folderUri) },
                leadingIcon = {
                    Icon(Icons.Outlined.Folder, contentDescription = null, modifier = Modifier.size(16.dp))
                },
                label = { Text("${folder.displayName} (${folder.videoCount})") },
                trailingIcon = {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Remove folder ${folder.displayName}",
                        modifier = Modifier
                            .size(16.dp)
                            .clickable { onRemoveFolder(folder.folderUri) },
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CinemaGoldContainer,
                    selectedLabelColor = CinemaGold,
                    selectedLeadingIconColor = CinemaGold,
                ),
            )
        }
    }
}

@Composable
private fun VideoGridCard(
    item: LibraryVideoItem,
    onClick: () -> Unit,
    onPlay: () -> Unit,
) {
    val meta = item.metadata
    val progress = if (meta.durationMs > 0L && meta.lastPositionMs > 0L) {
        (meta.lastPositionMs.toFloat() / meta.durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }

    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("video_card_${meta.filename}"),
        colors = CardDefaults.cardColors(containerColor = CinemaSurface),
        border = BorderStroke(1.dp, CinemaBorderSubtle),
        shape = RoundedCornerShape(14.dp),
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9.5f),
            ) {
                LocalThumbnailImage(
                    thumbnailPath = meta.thumbnailPath,
                    modifier = Modifier.fillMaxSize(),
                )
                // Gradient scrim for legible badges
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Black.copy(alpha = 0.45f),
                                    Color.Transparent,
                                    Color.Black.copy(alpha = 0.78f),
                                )
                            )
                        )
                )
                // Top-left HDR & DAR Badges
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                    HdrFormatBadge(format = item.hdrFormat, compact = true)
                    AspectRatioBadge(darLabel = meta.displayAspectRatioLabel, compact = true)
                }

                // Top-right Favourite / Watched Indicator
                if (item.isFavourite || item.watchedStatus == WatchedStatus.WATCHED) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        if (item.isFavourite) {
                            Icon(
                                imageVector = Icons.Rounded.Favorite,
                                contentDescription = "Favourite",
                                tint = CinemaGold,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                        if (item.watchedStatus == WatchedStatus.WATCHED) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Watched",
                                tint = CinemaEmerald,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                    }
                }

                // Bottom-left Duration + Quick Play FAB
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = Formatters.formatDurationMs(meta.durationMs),
                        style = MaterialTheme.typography.labelMedium,
                        color = CinemaTextPrimary,
                    )
                    Surface(
                        color = CinemaGold,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .size(30.dp)
                            .clickable(onClick = onPlay),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = "Play ${meta.filename}",
                                tint = CinemaObsidian,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }

                if (progress > 0f) {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(3.dp),
                        color = CinemaGold,
                        trackColor = Color.Black.copy(alpha = 0.5f),
                    )
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = meta.filename.substringBeforeLast('.'),
                    style = MaterialTheme.typography.titleSmall,
                    color = CinemaTextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "${meta.videoCodec} · ${Formatters.formatFileSize(meta.fileSizeBytes)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = CinemaTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    if (item.rating > 0f) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Star,
                                contentDescription = null,
                                tint = CinemaGold,
                                modifier = Modifier.size(13.dp),
                            )
                            Text(
                                text = String.format(Locale.US, "%.1f", item.rating),
                                style = MaterialTheme.typography.labelSmall,
                                color = CinemaGold,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoListRow(
    item: LibraryVideoItem,
    onClick: () -> Unit,
    onPlay: () -> Unit,
) {
    val meta = item.metadata
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = CinemaSurface),
        border = BorderStroke(1.dp, CinemaBorderSubtle),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier
                    .width(124.dp)
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(10.dp)),
            ) {
                LocalThumbnailImage(
                    thumbnailPath = meta.thumbnailPath,
                    modifier = Modifier.fillMaxSize(),
                )
                Text(
                    text = Formatters.formatDurationMs(meta.durationMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = CinemaTextPrimary,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .background(Color.Black.copy(alpha = 0.72f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                )
            }

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = meta.filename.substringBeforeLast('.'),
                    style = MaterialTheme.typography.titleMedium,
                    color = CinemaTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    HdrFormatBadge(format = item.hdrFormat, compact = true)
                    AspectRatioBadge(darLabel = meta.displayAspectRatioLabel, compact = true)
                    if (meta.bitDepth > 0) {
                        Text(
                            text = "${meta.bitDepth}-bit",
                            style = MaterialTheme.typography.labelSmall,
                            color = CinemaTextSecondary,
                        )
                    }
                }
                Text(
                    text = buildString {
                        append(Formatters.formatResolutionLabel(meta.codedWidth, meta.codedHeight))
                        append(" · ")
                        append(meta.videoCodec)
                        append(" · ")
                        append(Formatters.formatFileSize(meta.fileSizeBytes))
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = CinemaTextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (meta.relativeSubfolder.isNotBlank()) {
                    Text(
                        text = meta.relativeSubfolder,
                        style = MaterialTheme.typography.labelSmall,
                        color = CinemaTextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            IconButton(
                onClick = onPlay,
                modifier = Modifier.size(48.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.PlayArrow,
                    contentDescription = "Play ${meta.filename}",
                    tint = CinemaGold,
                )
            }
        }
    }
}

@Composable
private fun LibraryEmptyState(
    hasFolders: Boolean,
    hasFilters: Boolean,
    onAddFolder: () -> Unit,
    onOpenSingleVideo: () -> Unit,
    onResetFilters: () -> Unit,
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            color = CinemaSurface,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, CinemaBorderSubtle),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = Icons.Outlined.FolderOpen,
                    contentDescription = null,
                    tint = CinemaGold,
                    modifier = Modifier.size(44.dp),
                )
                Text(
                    text = if (hasFilters) {
                        "No videos match current filters"
                    } else if (hasFolders) {
                        "No local video files found in selected folders"
                    } else {
                        stringResource(R.string.library_empty_title)
                    },
                    style = MaterialTheme.typography.titleLarge,
                    color = CinemaTextPrimary,
                )
                Text(
                    text = if (hasFilters) {
                        "Adjust your HDR format, rating, tag, or search filters to view your local films."
                    } else {
                        stringResource(R.string.library_empty_body)
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = CinemaTextSecondary,
                )
                Spacer(Modifier.height(4.dp))
                if (hasFilters) {
                    Button(
                        onClick = onResetFilters,
                        colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
                    ) {
                        Text("Clear Filters")
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onAddFolder,
                            modifier = Modifier.testTag("empty_add_folder_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
                        ) {
                            Icon(Icons.Outlined.CreateNewFolder, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.library_add_folder))
                        }
                        OutlinedButton(
                            onClick = onOpenSingleVideo,
                            modifier = Modifier.testTag("empty_open_video_button"),
                            border = BorderStroke(1.dp, CinemaBorder),
                        ) {
                            Icon(Icons.Outlined.VideoFile, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.library_open_file))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LibrarySortFilterSheet(
    filter: LibraryFilterState,
    availableTags: List<String>,
    onUpdate: ((LibraryFilterState) -> LibraryFilterState) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.AutoMirrored.Rounded.Sort, contentDescription = null, tint = CinemaGold)
                Text("Sort & Filter Library", style = MaterialTheme.typography.titleLarge)
            }
            TextButton(onClick = onReset) {
                Text("Reset", color = CinemaGold)
            }
        }

        Text("Sort By", style = MaterialTheme.typography.labelLarge, color = CinemaTextSecondary)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            LibrarySortOption.entries.forEach { opt ->
                FilterChip(
                    selected = filter.sortOption == opt,
                    onClick = { onUpdate { it.copy(sortOption = opt) } },
                    label = { Text(opt.label) },
                )
            }
        }

        HorizontalDivider(color = CinemaBorderSubtle)

        Text("Video Format (HDR / SDR)", style = MaterialTheme.typography.labelLarge, color = CinemaTextSecondary)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf(HdrFormat.HDR10_PLUS, HdrFormat.DOLBY_VISION, HdrFormat.HDR10, HdrFormat.HLG, HdrFormat.SDR).forEach { fmt ->
                FilterChip(
                    selected = filter.hdrFilter == fmt,
                    onClick = {
                        onUpdate { it.copy(hdrFilter = if (it.hdrFilter == fmt) null else fmt) }
                    },
                    label = { Text(fmt.displayName) },
                )
            }
        }

        Text("Watched Status & Favourites", style = MaterialTheme.typography.labelLarge, color = CinemaTextSecondary)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = filter.favouritesOnly,
                onClick = { onUpdate { it.copy(favouritesOnly = !it.favouritesOnly) } },
                leadingIcon = {
                    Icon(
                        if (filter.favouritesOnly) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                    )
                },
                label = { Text("Favourites") },
            )
            WatchedStatus.entries.forEach { status ->
                FilterChip(
                    selected = filter.watchedFilter == status,
                    onClick = {
                        onUpdate { it.copy(watchedFilter = if (it.watchedFilter == status) null else status) }
                    },
                    label = { Text(status.label) },
                )
            }
        }

        Text("Minimum Personal Rating", style = MaterialTheme.typography.labelLarge, color = CinemaTextSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0f, 3f, 4f, 4.5f, 5f).forEach { threshold ->
                FilterChip(
                    selected = filter.minRating == threshold,
                    onClick = { onUpdate { it.copy(minRating = threshold) } },
                    label = { Text(if (threshold == 0f) "Any" else "${threshold}+ ★") },
                )
            }
        }

        Text("Cinema Aspect Ratio", style = MaterialTheme.typography.labelLarge, color = CinemaTextSecondary)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf("2.39:1", "2.40:1", "1.90:1", "1.85:1", "1.78:1", "1.33:1").forEach { dar ->
                FilterChip(
                    selected = filter.aspectRatioFilter == dar,
                    onClick = {
                        onUpdate { it.copy(aspectRatioFilter = if (it.aspectRatioFilter == dar) null else dar) }
                    },
                    label = { Text(dar) },
                )
            }
        }

        if (availableTags.isNotEmpty()) {
            Text("Personal Tags", style = MaterialTheme.typography.labelLarge, color = CinemaTextSecondary)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                availableTags.forEach { tag ->
                    FilterChip(
                        selected = filter.selectedTag == tag,
                        onClick = {
                            onUpdate { it.copy(selectedTag = if (it.selectedTag == tag) null else tag) }
                        },
                        label = { Text("#$tag") },
                    )
                }
            }
        }

        Button(
            onClick = onDismiss,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
        ) {
            Text("Apply")
        }
        Spacer(Modifier.height(16.dp))
    }
}
