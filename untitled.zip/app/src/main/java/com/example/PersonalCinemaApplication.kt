package com.example

import android.app.Application
import com.example.data.CinemaRepository
import com.example.data.LocalVaultBackupManager
import com.example.data.db.AppDatabase
import com.example.media.MpvConfigManager
import com.example.media.VideoMetadataExtractor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PersonalCinemaApplication : Application() {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val mpvConfigManager: MpvConfigManager by lazy { MpvConfigManager(this) }
    val metadataExtractor: VideoMetadataExtractor by lazy { VideoMetadataExtractor(this) }
    val backupManager: LocalVaultBackupManager by lazy {
        LocalVaultBackupManager(this, database, mpvConfigManager)
    }
    val repository: CinemaRepository by lazy {
        CinemaRepository(
            context = this,
            db = database,
            mpvConfigManager = mpvConfigManager,
            metadataExtractor = metadataExtractor,
            backupManager = backupManager,
        )
    }

    override fun onCreate() {
        super.onCreate()
        appScope.launch {
            repository.performStartupMaintenance()
        }
    }
}
