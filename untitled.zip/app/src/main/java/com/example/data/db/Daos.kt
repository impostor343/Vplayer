package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FolderDao {
    @Query("SELECT * FROM watched_folders ORDER BY displayName ASC")
    fun observeFolders(): Flow<List<WatchedFolderEntity>>

    @Query("SELECT * FROM watched_folders ORDER BY displayName ASC")
    suspend fun getAllFolders(): List<WatchedFolderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFolder(folder: WatchedFolderEntity)

    @Query("DELETE FROM watched_folders WHERE folderUri = :folderUri")
    suspend fun deleteFolder(folderUri: String)
}

@Dao
interface VideoMetadataDao {
    @Query("SELECT * FROM video_metadata ORDER BY filename ASC")
    fun observeAllVideos(): Flow<List<VideoMetadataEntity>>

    @Query("SELECT * FROM video_metadata ORDER BY filename ASC")
    suspend fun getAllVideos(): List<VideoMetadataEntity>

    @Query("SELECT * FROM video_metadata WHERE videoId = :videoId LIMIT 1")
    fun observeVideoById(videoId: String): Flow<VideoMetadataEntity?>

    @Query("SELECT * FROM video_metadata WHERE videoId = :videoId LIMIT 1")
    suspend fun getVideoById(videoId: String): VideoMetadataEntity?

    @Query("SELECT * FROM video_metadata WHERE folderUri = :folderUri")
    suspend fun getVideosByFolder(folderUri: String): List<VideoMetadataEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVideo(video: VideoMetadataEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVideos(videos: List<VideoMetadataEntity>)

    @Query("UPDATE video_metadata SET lastPositionMs = :positionMs, lastWatchedAtMillis = :watchedAtMillis WHERE videoId = :videoId")
    suspend fun updatePlaybackProgress(videoId: String, positionMs: Long, watchedAtMillis: Long)

    @Query(
        """
        UPDATE video_metadata
        SET videoCodec = :videoCodec,
            bitDepth = CASE WHEN :bitDepth > 0 THEN :bitDepth ELSE bitDepth END,
            chromaSubsampling = CASE WHEN :chroma != 'Unknown' THEN :chroma ELSE chromaSubsampling END,
            colorPrimaries = CASE WHEN :primaries != 'Unknown' THEN :primaries ELSE colorPrimaries END,
            transferCharacteristics = CASE WHEN :transfer != 'Unknown' THEN :transfer ELSE transferCharacteristics END,
            displayAspectRatioLabel = CASE WHEN :darLabel != 'Unknown' THEN :darLabel ELSE displayAspectRatioLabel END,
            displayAspectRatioName = CASE WHEN :darName != 'Unknown' THEN :darName ELSE displayAspectRatioName END,
            displayAspectRatioValue = CASE WHEN :darValue > 0 THEN :darValue ELSE displayAspectRatioValue END
        WHERE videoId = :videoId
        """
    )
    suspend fun enrichTechnicalParams(
        videoId: String,
        videoCodec: String,
        bitDepth: Int,
        chroma: String,
        primaries: String,
        transfer: String,
        darLabel: String,
        darName: String,
        darValue: Double,
    )

    @Query("DELETE FROM video_metadata WHERE folderUri = :folderUri")
    suspend fun deleteVideosInFolder(folderUri: String)

    @Query("DELETE FROM video_metadata WHERE folderUri = :folderUri AND videoId NOT IN (:presentIds)")
    suspend fun pruneMissingInFolder(folderUri: String, presentIds: List<String>)
}

@Dao
interface PlaybackSessionDao {
    @Query("SELECT * FROM playback_sessions ORDER BY openedAtMillis DESC")
    fun observeAllSessions(): Flow<List<PlaybackSessionEntity>>

    @Query("SELECT * FROM playback_sessions ORDER BY openedAtMillis DESC")
    suspend fun getAllSessions(): List<PlaybackSessionEntity>

    @Query("SELECT * FROM playback_sessions WHERE videoId = :videoId ORDER BY openedAtMillis DESC")
    fun observeSessionsForVideo(videoId: String): Flow<List<PlaybackSessionEntity>>

    @Query("SELECT * FROM playback_sessions WHERE sessionId = :sessionId LIMIT 1")
    suspend fun getSessionById(sessionId: Long): PlaybackSessionEntity?

    @Query("SELECT * FROM playback_sessions WHERE terminationState = 'ACTIVE'")
    suspend fun getStaleActiveSessions(): List<PlaybackSessionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: PlaybackSessionEntity): Long

    @Update
    suspend fun updateSession(session: PlaybackSessionEntity)

    @Query("DELETE FROM playback_sessions WHERE sessionId = :sessionId")
    suspend fun deleteSession(sessionId: Long)

    @Query("DELETE FROM playback_sessions")
    suspend fun clearAllSessions()
}

@Dao
interface PersonalReviewDao {
    @Query("SELECT * FROM personal_reviews")
    fun observeAllReviews(): Flow<List<PersonalReviewEntity>>

    @Query("SELECT * FROM personal_reviews")
    suspend fun getAllReviews(): List<PersonalReviewEntity>

    @Query("SELECT * FROM personal_reviews WHERE videoId = :videoId LIMIT 1")
    fun observeReview(videoId: String): Flow<PersonalReviewEntity?>

    @Query("SELECT * FROM personal_reviews WHERE videoId = :videoId LIMIT 1")
    suspend fun getReview(videoId: String): PersonalReviewEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReview(review: PersonalReviewEntity)

    @Query("DELETE FROM personal_reviews WHERE videoId = :videoId")
    suspend fun deleteReview(videoId: String)
}

@Dao
interface TimestampBookmarkDao {
    @Query("SELECT * FROM timestamp_bookmarks ORDER BY createdAtMillis DESC")
    fun observeAllBookmarks(): Flow<List<TimestampBookmarkEntity>>

    @Query("SELECT * FROM timestamp_bookmarks ORDER BY createdAtMillis DESC")
    suspend fun getAllBookmarks(): List<TimestampBookmarkEntity>

    @Query("SELECT * FROM timestamp_bookmarks WHERE videoId = :videoId ORDER BY timestampMs ASC")
    fun observeBookmarksForVideo(videoId: String): Flow<List<TimestampBookmarkEntity>>

    @Query("SELECT * FROM timestamp_bookmarks WHERE isFavouriteScene = 1 ORDER BY createdAtMillis DESC")
    fun observeFavouriteScenes(): Flow<List<TimestampBookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: TimestampBookmarkEntity): Long

    @Update
    suspend fun updateBookmark(bookmark: TimestampBookmarkEntity)

    @Query("DELETE FROM timestamp_bookmarks WHERE bookmarkId = :bookmarkId")
    suspend fun deleteBookmark(bookmarkId: Long)
}

@Dao
interface MpvConfigDao {
    @Query("SELECT * FROM mpv_profiles ORDER BY isBuiltIn DESC, name ASC")
    fun observeProfiles(): Flow<List<MpvProfileEntity>>

    @Query("SELECT * FROM mpv_profiles")
    suspend fun getAllProfiles(): List<MpvProfileEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: MpvProfileEntity)

    @Query("UPDATE mpv_profiles SET isActive = CASE WHEN profileId = :profileId THEN 1 ELSE 0 END")
    suspend fun setActiveProfile(profileId: String)

    @Query("DELETE FROM mpv_profiles WHERE profileId = :profileId AND isBuiltIn = 0")
    suspend fun deleteCustomProfile(profileId: String)

    @Query("SELECT * FROM mpv_config_backups ORDER BY createdAtMillis DESC LIMIT 30")
    fun observeBackups(): Flow<List<MpvConfigBackupEntity>>

    @Query("SELECT * FROM mpv_config_backups ORDER BY createdAtMillis DESC")
    suspend fun getAllBackups(): List<MpvConfigBackupEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBackup(backup: MpvConfigBackupEntity): Long

    @Query("DELETE FROM mpv_config_backups WHERE backupId = :backupId")
    suspend fun deleteBackup(backupId: Long)
}
