package com.example

import android.content.Context
import android.content.pm.PackageManager
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.CinemaRepository
import com.example.data.LocalVaultBackupManager
import com.example.data.db.AppDatabase
import com.example.data.db.PersonalReviewEntity
import com.example.data.db.VideoMetadataEntity
import com.example.domain.HdrFormat
import com.example.domain.SessionTerminationState
import com.example.domain.WatchedStatus
import com.example.media.MpvConfigManager
import com.example.media.VideoMetadataExtractor
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PersonalCinemaDatabaseAndPrivacyTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var configManager: MpvConfigManager
    private lateinit var repository: CinemaRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        configManager = MpvConfigManager(context)
        val extractor = VideoMetadataExtractor(context)
        val backup = LocalVaultBackupManager(context, db, configManager)
        repository = CinemaRepository(context, db, configManager, extractor, backup)
    }

    @After
    fun tearDown() {
        db.close()
    }

    private fun sampleVideo(id: String = "content://local/dune.mkv", hdr: HdrFormat = HdrFormat.HDR10_PLUS) =
        VideoMetadataEntity(
            videoId = id,
            filename = "Dune.Part.Two.2024.2160p.mkv",
            folderUri = "content://local/movies",
            relativeSubfolder = "Sci-Fi",
            fileSizeBytes = 28_500_000_000L,
            lastModifiedMillis = 1_700_000_000_000L,
            durationMs = 9_960_000L,
            codedWidth = 3840,
            codedHeight = 1608,
            sarNum = 1,
            sarDen = 1,
            rotationDegrees = 0,
            displayAspectRatioLabel = "2.39:1",
            displayAspectRatioName = "Scope / DCI Scope",
            displayAspectRatioValue = 2.388,
            videoCodec = "HEVC (H.265)",
            bitDepth = 10,
            frameRate = 23.976f,
            chromaSubsampling = "4:2:0",
            colorPrimaries = "BT.2020",
            transferCharacteristics = "PQ (SMPTE ST 2084)",
            hdrFormat = hdr.name,
            hdrEvidence = "Verified HDR10+ dynamic metadata",
            audioCodec = "Dolby TrueHD",
            audioTracksJson = "[]",
            audioTrackCount = 2,
            subtitleTracksJson = "[]",
            subtitleTrackCount = 3,
            thumbnailPath = null,
            lastScannedMillis = 1_700_000_000_000L,
        )

    @Test
    fun `manifest declares ZERO internet permissions for strict offline privacy`() {
        val pkgInfo = context.packageManager.getPackageInfo(
            context.packageName,
            PackageManager.GET_PERMISSIONS,
        )
        val requested = pkgInfo.requestedPermissions?.toSet().orEmpty()
        assertFalse(
            "INTERNET permission must not be present",
            requested.contains(android.Manifest.permission.INTERNET),
        )
        assertFalse(
            "ACCESS_NETWORK_STATE permission must not be present",
            requested.contains(android.Manifest.permission.ACCESS_NETWORK_STATE),
        )
    }

    @Test
    fun `each video opening creates a new session and crash recovery finalizes stale ACTIVE sessions`() = runTest {
        val video = sampleVideo()
        db.videoMetadataDao().upsertVideo(video)

        // Session 1: simulates unexpected crash while ACTIVE after a checkpoint
        val s1 = repository.startPlaybackSession(video, startPositionMs = 0L)
        repository.checkpointPlaybackSession(s1, currentPositionMs = 1_200_000L, watchedDurationMs = 1_200_000L, videoDurationMs = video.durationMs)

        val recoveredCount = repository.recoverInterruptedSessions()
        assertEquals(1, recoveredCount)
        val s1After = db.playbackSessionDao().getSessionById(s1)
        assertNotNull(s1After)
        assertEquals(SessionTerminationState.CRASH_RECOVERED.name, s1After!!.terminationState)
        assertEquals(1_200_000L, s1After.endPositionMs)

        // Session 2: reopening the same video creates a separate new record
        val s2 = repository.startPlaybackSession(video, startPositionMs = 1_200_000L)
        assertTrue(s2 != s1)
        repository.finalizePlaybackSession(s2, endPositionMs = 9_500_000L, watchedDurationMs = 8_300_000L, videoDurationMs = video.durationMs, terminationState = SessionTerminationState.NORMAL)

        val allSessions = db.playbackSessionDao().getAllSessions()
        assertEquals(2, allSessions.size)
        assertTrue(allSessions.first { it.sessionId == s2 }.isCompleted)
    }

    @Test
    fun `multiple viewing sessions preserve personal review text and increment rewatches`() = runTest {
        val video = sampleVideo()
        db.videoMetadataDao().upsertVideo(video)

        repository.savePersonalReview(
            PersonalReviewEntity(
                videoId = video.videoId,
                rating = 5.0f,
                writtenReview = "Reference cinematography and sound design.",
                watchedStatus = WatchedStatus.WATCHED.name,
                isFavourite = true,
                tagsCsv = "sci-fi, reference-hdr",
                viewingDateMillis = 1_700_000_000_000L,
                rewatchCount = 1,
                notes = "Keep HDR10+ active",
            )
        )

        // Complete another session
        val sid = repository.startPlaybackSession(video, 0L)
        repository.finalizePlaybackSession(sid, endPositionMs = 9_600_000L, watchedDurationMs = 9_600_000L, videoDurationMs = video.durationMs, terminationState = SessionTerminationState.NORMAL)

        val review = db.personalReviewDao().getReview(video.videoId)
        assertNotNull(review)
        assertEquals("Reference cinematography and sound design.", review!!.writtenReview)
        assertEquals(5.0f, review.rating, 0.01f)
        assertEquals(2, review.rewatchCount)
    }

    @Test
    fun `bookmarks, config backups, and full local JSON vault export-import roundtrip succeed`() = runTest {
        repository.performStartupMaintenance()
        val video = sampleVideo()
        db.videoMetadataDao().upsertVideo(video)

        repository.addBookmark(
            videoId = video.videoId,
            videoFilename = video.filename,
            timestampMs = 3_420_000L,
            title = "Sandworm Ride",
            note = "Reference LFE bass and specular sand highlights",
            isFavouriteScene = true,
        )
        repository.savePersonalReview(
            PersonalReviewEntity(
                videoId = video.videoId,
                rating = 4.5f,
                writtenReview = "Incredible scale.",
                watchedStatus = WatchedStatus.WATCHED.name,
                isFavourite = true,
                tagsCsv = "imax",
            )
        )
        val sid = repository.startPlaybackSession(video, 0L)
        repository.finalizePlaybackSession(sid, 5_000_000L, 5_000_000L, video.durationMs, SessionTerminationState.NORMAL)

        // Apply custom mpv config -> must automatically store backup first
        repository.applyMpvConfigWithBackup(
            mpvConf = "vo=gpu\nhwdec=mediacodec-copy\ntarget-colorspace-hint=yes\nytdl=no",
            inputConf = "SPACE cycle pause",
            reason = "Test update",
        )
        assertTrue(db.mpvConfigDao().getAllBackups().isNotEmpty())

        // Export JSON vault
        val exportedJson = repository.backupManager.exportToJsonString()
        assertTrue(exportedJson.contains("Sandworm Ride"))
        assertTrue(exportedJson.contains("Incredible scale."))

        // Import into a brand-new empty Room database
        val restoredDb = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val restoreManager = LocalVaultBackupManager(context, restoredDb, configManager)
            val summary = restoreManager.importFromJsonString(exportedJson)
            assertEquals(1, summary.videosImported)
            assertEquals(1, summary.sessionsImported)
            assertEquals(1, summary.reviewsImported)
            assertEquals(1, summary.bookmarksImported)
            assertTrue(summary.configRestored)
        } finally {
            restoredDb.close()
        }
    }

    @Test
    fun `statistics never fabricate data when no sessions exist and compute accurately with sessions`() = runTest {
        val emptyStats = repository.computeStats(emptyList(), emptyList(), emptyList())
        assertEquals(0L, emptyStats.totalViewingMs)
        assertEquals(0, emptyStats.totalSessions)
        assertTrue(emptyStats.mostWatched.isEmpty())

        val hdrVideo = sampleVideo("content://local/hdr.mkv", HdrFormat.HDR10_PLUS)
        val sdrVideo = sampleVideo("content://local/sdr.mkv", HdrFormat.SDR)
        db.videoMetadataDao().upsertVideos(listOf(hdrVideo, sdrVideo))

        val s1 = repository.startPlaybackSession(hdrVideo, 0L)
        repository.finalizePlaybackSession(s1, 3_600_000L, 3_600_000L, 7_200_000L, SessionTerminationState.NORMAL)

        val s2 = repository.startPlaybackSession(sdrVideo, 0L)
        repository.finalizePlaybackSession(s2, 1_800_000L, 1_800_000L, 3_600_000L, SessionTerminationState.NORMAL)

        val stats = repository.computeStats(
            db.playbackSessionDao().getAllSessions(),
            db.personalReviewDao().getAllReviews(),
            db.videoMetadataDao().getAllVideos(),
        )
        assertEquals(2, stats.totalSessions)
        assertEquals(2, stats.uniqueVideosWatched)
        assertEquals(5_400_000L, stats.totalViewingMs)
        assertEquals(2_700_000L, stats.averageSessionMs)
        assertEquals(1, stats.hdrBreakdownCounts[HdrFormat.HDR10_PLUS])
        assertEquals(1, stats.hdrBreakdownCounts[HdrFormat.SDR])
    }
}
