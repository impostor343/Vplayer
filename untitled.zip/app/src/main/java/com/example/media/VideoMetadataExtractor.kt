package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import com.example.data.db.VideoMetadataEntity
import com.example.domain.HdrFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

/**
 * Extracts technical video/audio/subtitle metadata and local preview thumbnails
 * purely on-device using Android's MediaExtractor and MediaMetadataRetriever.
 * Live mpv playback refines decoder-level details (bit depth, chroma, dynamic peak)
 * whenever the file is played.
 */
class VideoMetadataExtractor(private val context: Context) {

    private val thumbnailDir: File by lazy {
        File(context.cacheDir, "cinema_thumbnails").apply { mkdirs() }
    }

    suspend fun extractMetadata(
        uri: Uri,
        displayName: String,
        folderUri: String,
        relativeSubfolder: String,
        fileSizeBytes: Long,
        lastModifiedMillis: Long,
    ): VideoMetadataEntity = withContext(Dispatchers.IO) {
        val videoId = uri.toString()

        var width = 0
        var height = 0
        var rotation = 0
        var sarNum = 1
        var sarDen = 1
        var durationMs = 0L
        var videoCodec = "Unknown"
        var videoMime: String? = null
        var profileName: String? = null
        var bitDepth = 0
        var frameRate = 0f
        var chromaSubsampling = "Unknown"
        var colorPrimaries = "Unknown"
        var transferCharacteristics = "Unknown"
        var hasHdr10PlusMeta = false
        var hasDolbyVision = false

        val audioTracks = JSONArray()
        val subtitleTracks = JSONArray()
        var primaryAudioCodec = "Unknown"

        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()

                when {
                    mime.startsWith("video/") && videoMime == null -> {
                        videoMime = mime
                        videoCodec = Formatters.prettyCodecName(mime)
                        width = format.getIntOrDefault(MediaFormat.KEY_WIDTH, 0)
                        height = format.getIntOrDefault(MediaFormat.KEY_HEIGHT, 0)
                        if (format.containsKey(MediaFormat.KEY_DURATION)) {
                            durationMs = format.getLong(MediaFormat.KEY_DURATION) / 1000L
                        }
                        if (format.containsKey(MediaFormat.KEY_ROTATION)) {
                            rotation = format.getInteger(MediaFormat.KEY_ROTATION)
                        }
                        if (format.containsKey("sar-width") && format.containsKey("sar-height")) {
                            sarNum = format.getInteger("sar-width").coerceAtLeast(1)
                            sarDen = format.getInteger("sar-height").coerceAtLeast(1)
                        } else if (format.containsKey("display-width") && format.containsKey("display-height") && width > 0 && height > 0) {
                            val dw = format.getInteger("display-width")
                            val dh = format.getInteger("display-height")
                            if (dw > 0 && dh > 0) {
                                sarNum = dw * height
                                sarDen = dh * width
                            }
                        }

                        frameRate = readFrameRate(format)

                        if (format.containsKey(MediaFormat.KEY_COLOR_STANDARD)) {
                            colorPrimaries = mapColorStandard(format.getInteger(MediaFormat.KEY_COLOR_STANDARD))
                        }
                        if (format.containsKey(MediaFormat.KEY_COLOR_TRANSFER)) {
                            transferCharacteristics = mapColorTransfer(format.getInteger(MediaFormat.KEY_COLOR_TRANSFER))
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                            format.containsKey(MediaFormat.KEY_HDR10_PLUS_INFO)
                        ) {
                            val buf = format.getByteBuffer(MediaFormat.KEY_HDR10_PLUS_INFO)
                            if (buf != null && buf.remaining() > 0) {
                                hasHdr10PlusMeta = true
                            }
                        }
                        if (mime.contains("dolby-vision", ignoreCase = true)) {
                            hasDolbyVision = true
                        }

                        val profile = format.getIntOrDefault(MediaFormat.KEY_PROFILE, -1)
                        val profileInfo = inspectCodecProfile(mime, profile)
                        profileName = profileInfo.name
                        if (profileInfo.bitDepth > 0) bitDepth = profileInfo.bitDepth
                        if (profileInfo.chroma != null) chromaSubsampling = profileInfo.chroma
                        if (profileInfo.isHdr10Plus) hasHdr10PlusMeta = true
                        if (profileInfo.isDolbyVision) hasDolbyVision = true
                    }

                    mime.startsWith("audio/") -> {
                        val codec = Formatters.prettyCodecName(mime)
                        if (primaryAudioCodec == "Unknown") primaryAudioCodec = codec
                        val lang = format.getString(MediaFormat.KEY_LANGUAGE) ?: "und"
                        val channels = format.getIntOrDefault(MediaFormat.KEY_CHANNEL_COUNT, 0)
                        val sampleRate = format.getIntOrDefault(MediaFormat.KEY_SAMPLE_RATE, 0)
                        audioTracks.put(
                            JSONObject().apply {
                                put("index", i)
                                put("codec", codec)
                                put("language", lang)
                                put("channels", channels)
                                put("sampleRate", sampleRate)
                            }
                        )
                    }

                    mime.startsWith("text/") || mime.contains("subtitle") || mime.contains("cea") || mime.contains("vtt") -> {
                        val lang = format.getString(MediaFormat.KEY_LANGUAGE) ?: "und"
                        subtitleTracks.put(
                            JSONObject().apply {
                                put("index", i)
                                put("codec", Formatters.prettyCodecName(mime))
                                put("language", lang)
                            }
                        )
                    }
                }
            }
        } catch (_: Throwable) {
            // Gracefully handle corrupted/unsupported containers; retriever fallback below
        } finally {
            runCatching { extractor.release() }
        }

        // MediaMetadataRetriever complements duration, rotation, color transfer, and extracts thumbnail
        var thumbnailPath: String? = null
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            if (durationMs <= 0L) {
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            }
            if (width <= 0) {
                width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            }
            if (height <= 0) {
                height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            }
            if (rotation == 0) {
                rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (colorPrimaries == "Unknown") {
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_COLOR_STANDARD)?.toIntOrNull()?.let {
                        colorPrimaries = mapColorStandard(it)
                    }
                }
                if (transferCharacteristics == "Unknown") {
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_COLOR_TRANSFER)?.toIntOrNull()?.let {
                        transferCharacteristics = mapColorTransfer(it)
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && bitDepth == 0) {
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITS_PER_SAMPLE)?.toIntOrNull()?.let {
                    if (it in listOf(8, 10, 12)) bitDepth = it
                }
            }
            if (frameRate <= 0f) {
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull()?.let {
                    if (it > 0f) frameRate = it
                }
            }
            thumbnailPath = extractAndCacheThumbnail(retriever, videoId, lastModifiedMillis, durationMs)
        } catch (_: Throwable) {
            // Inaccessible or non-standard container handled safely
        } finally {
            runCatching { retriever.release() }
        }

        val dar = AspectRatioCalculator.calculate(
            codedWidth = width,
            codedHeight = height,
            sarNum = sarNum,
            sarDen = sarDen,
            rotationDegrees = rotation,
        )

        val (hdrFormat, hdrEvidence) = HdrInspector.classifySourceFormat(
            mimeType = videoMime,
            codecProfileName = profileName,
            colorPrimaries = colorPrimaries.takeUnless { it == "Unknown" },
            transferCharacteristics = transferCharacteristics.takeUnless { it == "Unknown" },
            hasHdr10PlusDynamicMetadata = hasHdr10PlusMeta,
            hasDolbyVisionConfig = hasDolbyVision,
        )

        val inferredBitDepth = when {
            bitDepth > 0 -> bitDepth
            hdrFormat.isHdr -> 10
            width > 0 -> 8
            else -> 0
        }

        VideoMetadataEntity(
            videoId = videoId,
            filename = displayName,
            folderUri = folderUri,
            relativeSubfolder = relativeSubfolder,
            fileSizeBytes = fileSizeBytes,
            lastModifiedMillis = lastModifiedMillis,
            durationMs = durationMs,
            codedWidth = width,
            codedHeight = height,
            sarNum = sarNum,
            sarDen = sarDen,
            rotationDegrees = rotation,
            displayAspectRatioLabel = dar.formattedLabel,
            displayAspectRatioName = dar.standardName,
            displayAspectRatioValue = dar.darValue,
            videoCodec = videoCodec,
            bitDepth = inferredBitDepth,
            frameRate = frameRate,
            chromaSubsampling = chromaSubsampling,
            colorPrimaries = colorPrimaries,
            transferCharacteristics = transferCharacteristics,
            hdrFormat = hdrFormat.name,
            hdrEvidence = hdrEvidence,
            audioCodec = primaryAudioCodec,
            audioTracksJson = audioTracks.toString(),
            audioTrackCount = audioTracks.length(),
            subtitleTracksJson = subtitleTracks.toString(),
            subtitleTrackCount = subtitleTracks.length(),
            thumbnailPath = thumbnailPath,
            lastScannedMillis = System.currentTimeMillis(),
        )
    }

    private fun extractAndCacheThumbnail(
        retriever: MediaMetadataRetriever,
        videoId: String,
        lastModified: Long,
        durationMs: Long,
    ): String? {
        val hash = sha256Short("${videoId}_$lastModified")
        val target = File(thumbnailDir, "$hash.jpg")
        if (target.exists() && target.length() > 0L) {
            return target.absolutePath
        }
        val frameTimeUs = when {
            durationMs > 20_000L -> (durationMs * 1000L) / 8L
            durationMs > 2_000L -> 1_000_000L
            else -> 0L
        }
        val bitmap: Bitmap? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            retriever.getScaledFrameAtTime(
                frameTimeUs,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                480,
                270,
            )
        } else {
            @Suppress("DEPRECATION")
            retriever.getFrameAtTime(frameTimeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        }
        if (bitmap == null) return null
        return try {
            FileOutputStream(target).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
            }
            bitmap.recycle()
            target.absolutePath
        } catch (_: Throwable) {
            bitmap.recycle()
            null
        }
    }

    private fun readFrameRate(format: MediaFormat): Float {
        if (!format.containsKey(MediaFormat.KEY_FRAME_RATE)) return 0f
        return try {
            format.getFloat(MediaFormat.KEY_FRAME_RATE)
        } catch (_: ClassCastException) {
            runCatching { format.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }.getOrDefault(0f)
        }
    }

    private fun MediaFormat.getIntOrDefault(key: String, defaultValue: Int): Int {
        if (!containsKey(key)) return defaultValue
        return runCatching { getInteger(key) }.getOrDefault(defaultValue)
    }

    private fun mapColorStandard(standard: Int): String = when (standard) {
        MediaFormat.COLOR_STANDARD_BT2020 -> "BT.2020"
        MediaFormat.COLOR_STANDARD_BT709 -> "BT.709"
        MediaFormat.COLOR_STANDARD_BT601_NTSC -> "BT.601 (NTSC)"
        MediaFormat.COLOR_STANDARD_BT601_PAL -> "BT.601 (PAL)"
        else -> "Standard #$standard"
    }

    private fun mapColorTransfer(transfer: Int): String = when (transfer) {
        MediaFormat.COLOR_TRANSFER_ST2084 -> "PQ (SMPTE ST 2084)"
        MediaFormat.COLOR_TRANSFER_HLG -> "HLG (ARIB STD-B67)"
        MediaFormat.COLOR_TRANSFER_SDR_VIDEO -> "SDR (BT.709)"
        MediaFormat.COLOR_TRANSFER_LINEAR -> "Linear"
        else -> "Transfer #$transfer"
    }

    private data class ProfileInspection(
        val name: String?,
        val bitDepth: Int = 0,
        val chroma: String? = null,
        val isHdr10Plus: Boolean = false,
        val isDolbyVision: Boolean = false,
    )

    private fun inspectCodecProfile(mime: String, profile: Int): ProfileInspection {
        if (profile < 0) return ProfileInspection(null)
        return when {
            mime.contains("hevc", ignoreCase = true) -> when (profile) {
                MediaCodecInfo.CodecProfileLevel.HEVCProfileMain ->
                    ProfileInspection("HEVC Main", bitDepth = 8, chroma = "4:2:0")
                MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10 ->
                    ProfileInspection("HEVC Main 10", bitDepth = 10, chroma = "4:2:0")
                MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10HDR10 ->
                    ProfileInspection("HEVC Main 10 HDR10", bitDepth = 10, chroma = "4:2:0")
                MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10HDR10Plus ->
                    ProfileInspection("HEVC Main 10 HDR10+", bitDepth = 10, chroma = "4:2:0", isHdr10Plus = true)
                else -> ProfileInspection("HEVC Profile $profile")
            }
            mime.contains("av01", ignoreCase = true) -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    when (profile) {
                        MediaCodecInfo.CodecProfileLevel.AV1ProfileMain8 ->
                            ProfileInspection("AV1 Main 8-bit", bitDepth = 8, chroma = "4:2:0")
                        MediaCodecInfo.CodecProfileLevel.AV1ProfileMain10 ->
                            ProfileInspection("AV1 Main 10-bit", bitDepth = 10, chroma = "4:2:0")
                        MediaCodecInfo.CodecProfileLevel.AV1ProfileMain10HDR10 ->
                            ProfileInspection("AV1 Main 10 HDR10", bitDepth = 10, chroma = "4:2:0")
                        MediaCodecInfo.CodecProfileLevel.AV1ProfileMain10HDR10Plus ->
                            ProfileInspection("AV1 Main 10 HDR10+", bitDepth = 10, chroma = "4:2:0", isHdr10Plus = true)
                        else -> ProfileInspection("AV1 Profile $profile")
                    }
                } else {
                    ProfileInspection("AV1 Profile $profile")
                }
            }
            mime.contains("dolby-vision", ignoreCase = true) ->
                ProfileInspection("Dolby Vision (Profile #$profile)", bitDepth = 10, chroma = "4:2:0", isDolbyVision = true)
            mime.contains("avc", ignoreCase = true) -> when (profile) {
                MediaCodecInfo.CodecProfileLevel.AVCProfileHigh10 ->
                    ProfileInspection("H.264 High 10", bitDepth = 10, chroma = "4:2:0")
                MediaCodecInfo.CodecProfileLevel.AVCProfileHigh422 ->
                    ProfileInspection("H.264 High 4:2:2", bitDepth = 10, chroma = "4:2:2")
                MediaCodecInfo.CodecProfileLevel.AVCProfileHigh444 ->
                    ProfileInspection("H.264 High 4:4:4", bitDepth = 10, chroma = "4:4:4")
                else -> ProfileInspection("H.264", bitDepth = 8, chroma = "4:2:0")
            }
            mime.contains("vp9", ignoreCase = true) -> when (profile) {
                MediaCodecInfo.CodecProfileLevel.VP9Profile0 ->
                    ProfileInspection("VP9 Profile 0", bitDepth = 8, chroma = "4:2:0")
                MediaCodecInfo.CodecProfileLevel.VP9Profile2,
                MediaCodecInfo.CodecProfileLevel.VP9Profile2HDR,
                -> ProfileInspection("VP9 Profile 2", bitDepth = 10, chroma = "4:2:0")
                MediaCodecInfo.CodecProfileLevel.VP9Profile2HDR10Plus ->
                    ProfileInspection("VP9 Profile 2 HDR10+", bitDepth = 10, chroma = "4:2:0", isHdr10Plus = true)
                else -> ProfileInspection("VP9 Profile $profile")
            }
            else -> ProfileInspection(null)
        }
    }

    private fun sha256Short(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return digest.take(12).joinToString("") { "%02x".format(it) }
    }
}
