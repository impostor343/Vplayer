package com.example.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.example.data.db.AppDatabase
import com.example.data.db.MpvConfigBackupEntity
import com.example.data.db.MpvProfileEntity
import com.example.data.db.PersonalReviewEntity
import com.example.data.db.PlaybackSessionEntity
import com.example.data.db.TimestampBookmarkEntity
import com.example.data.db.VideoMetadataEntity
import com.example.data.db.WatchedFolderEntity
import com.example.domain.CinemaStatsSummary
import com.example.domain.DailyWatchPoint
import com.example.domain.DecoderLiveStats
import com.example.domain.HdrFormat
import com.example.domain.MonthlyWatchPoint
import com.example.domain.MostWatchedItem
import com.example.domain.SessionTerminationState
import com.example.domain.WatchedStatus
import com.example.media.AspectRatioCalculator
import com.example.media.MpvConfigManager
import com.example.media.VideoMetadataExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class CinemaRepository(
    private val context: Context,
    private val db: AppDatabase,
    val mpvConfigManager: MpvConfigManager,
    private val metadataExtractor: VideoMetadataExtractor,
    val backupManager: LocalVaultBackupManager,
) {
    val foldersFlow: Flow<List<WatchedFolderEntity>> = db.folderDao().observeFolders()
    val videosFlow: Flow<List<VideoMetadataEntity>> = db.videoMetadataDao().observeAllVideos()
    val sessionsFlow: Flow<List<PlaybackSessionEntity>> = db.playbackSessionDao().observeAllSessions()
    val reviewsFlow: Flow<List<PersonalReviewEntity>> = db.personalReviewDao().observeAllReviews()
    val bookmarksFlow: Flow<List<TimestampBookmarkEntity>> = db.timestampBookmarkDao().observeAllBookmarks()
    val favouriteScenesFlow: Flow<List<TimestampBookmarkEntity>> = db.timestampBookmarkDao().observeFavouriteScenes()
    val mpvProfilesFlow: Flow<List<MpvProfileEntity>> = db.mpvConfigDao().observeProfiles()
    val mpvBackupsFlow: Flow<List<MpvConfigBackupEntity>> = db.mpvConfigDao().observeBackups()

    fun observeVideo(videoId: String): Flow<VideoMetadataEntity?> = db.videoMetadataDao().observeVideoById(videoId)
    fun observeReview(videoId: String): Flow<PersonalReviewEntity?> = db.personalReviewDao().observeReview(videoId)
    fun observeBookmarksForVideo(videoId: String): Flow<List<TimestampBookmarkEntity>> =
        db.timestampBookmarkDao().observeBookmarksForVideo(videoId)
    fun observeSessionsForVideo(videoId: String): Flow<List<PlaybackSessionEntity>> =
        db.playbackSessionDao().observeSessionsForVideo(videoId)

    suspend fun getVideoById(videoId: String): VideoMetadataEntity? = db.videoMetadataDao().getVideoById(videoId)
    suspend fun getAllVideos(): List<VideoMetadataEntity> = db.videoMetadataDao().getAllVideos()

    /**
     * Seeds built-in mpv profiles (without overwriting any existing user configuration)
     * and recovers any stale ACTIVE playback sessions left open by an unexpected crash.
     */
    suspend fun performStartupMaintenance() = withContext(Dispatchers.IO) {
        mpvConfigManager.ensureInitialized()
        seedBuiltInProfilesIfNeeded()
        recoverInterruptedSessions()
    }

    private suspend fun seedBuiltInProfilesIfNeeded() {
        val existing = db.mpvConfigDao().getAllProfiles()
        if (existing.isEmpty()) {
            db.mpvConfigDao().upsertProfile(
                MpvProfileEntity(
                    profileId = "builtin_hdr_reference",
                    name = "HDR Reference (gpu-next)",
                    description = "libplacebo gpu-next + MediaCodec hardware decode + HDR colorspace hint + BT.2446a tone-mapping.",
                    mpvConf = MpvConfigManager.DEFAULT_HDR_MPV_CONF,
                    inputConf = MpvConfigManager.DEFAULT_INPUT_CONF,
                    isActive = true,
                    isBuiltIn = true,
                )
            )
            db.mpvConfigDao().upsertProfile(
                MpvProfileEntity(
                    profileId = "builtin_classic_gpu",
                    name = "Classic GPU Compatibility",
                    description = "Traditional vo=gpu renderer with HDR tone-mapping for older Android GPUs.",
                    mpvConf = MpvConfigManager.CLASSIC_GPU_MPV_CONF,
                    inputConf = MpvConfigManager.DEFAULT_INPUT_CONF,
                    isActive = false,
                    isBuiltIn = true,
                )
            )
            db.mpvConfigDao().upsertProfile(
                MpvProfileEntity(
                    profileId = "builtin_battery_hwdec",
                    name = "Low-Power Hardware Decode",
                    description = "Zero-copy MediaCodec pipeline optimized for battery life and thermals.",
                    mpvConf = MpvConfigManager.BATTERY_HWDEC_MPV_CONF,
                    inputConf = MpvConfigManager.DEFAULT_INPUT_CONF,
                    isActive = false,
                    isBuiltIn = true,
                )
            )
            db.mpvConfigDao().upsertProfile(
                MpvProfileEntity(
                    profileId = "builtin_cinema_hq",
                    name = "Cinema HQ Upscaling",
                    description = "gpu-next + EWA Lanczos Sharp scaling, spline tone-mapping, and 2-pass debanding.",
                    mpvConf = MpvConfigManager.CINEMA_HQ_MPV_CONF,
                    inputConf = MpvConfigManager.DEFAULT_INPUT_CONF,
                    isActive = false,
                    isBuiltIn = true,
                )
            )
        }
    }

    /**
     * Marks any playback session left in ACTIVE state from a force-kill or crash as
     * CRASH_RECOVERED using its last persisted checkpoint timestamp.
     */
    suspend fun recoverInterruptedSessions(): Int = withContext(Dispatchers.IO) {
        val stale = db.playbackSessionDao().getStaleActiveSessions()
        stale.forEach { session ->
            val recoveredClose = session.lastCheckpointMillis.coerceAtLeast(session.openedAtMillis)
            db.playbackSessionDao().updateSession(
                session.copy(
                    closedAtMillis = recoveredClose,
                    terminationState = SessionTerminationState.CRASH_RECOVERED.name,
                )
            )
        }
        stale.size
    }

    // ---- SAF Folder & Video Library Indexing ----

    suspend fun addWatchedFolder(treeUri: Uri): Result<WatchedFolderEntity> = withContext(Dispatchers.IO) {
        runCatching {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }
            val rootDoc = DocumentFile.fromTreeUri(context, treeUri)
            val name = rootDoc?.name ?: treeUri.lastPathSegment?.substringAfterLast(':') ?: "Selected Folder"
            val folder = WatchedFolderEntity(
                folderUri = treeUri.toString(),
                displayName = name,
                includeSubfolders = true,
                addedAtMillis = System.currentTimeMillis(),
            )
            db.folderDao().upsertFolder(folder)
            scanFolder(folder)
            db.folderDao().getAllFolders().firstOrNull { it.folderUri == folder.folderUri } ?: folder
        }
    }

    suspend fun removeWatchedFolder(folderUri: String) = withContext(Dispatchers.IO) {
        db.videoMetadataDao().deleteVideosInFolder(folderUri)
        db.folderDao().deleteFolder(folderUri)
        runCatching {
            context.contentResolver.releasePersistableUriPermission(
                Uri.parse(folderUri),
                Intent.FLAG_GRANT_READ_URI_PERMISSION,
            )
        }
    }

    suspend fun rescanAllFolders(): Int = withContext(Dispatchers.IO) {
        var totalScanned = 0
        db.folderDao().getAllFolders().forEach { folder ->
            totalScanned += scanFolder(folder)
        }
        totalScanned
    }

    suspend fun scanFolder(folder: WatchedFolderEntity): Int = withContext(Dispatchers.IO) {
        val treeUri = Uri.parse(folder.folderUri)
        val rootDoc = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext 0
        val existingById = db.videoMetadataDao().getVideosByFolder(folder.folderUri)
            .associateBy { it.videoId }

        val discoveredIds = mutableListOf<String>()
        val updatedEntries = mutableListOf<VideoMetadataEntity>()

        suspend fun walk(dir: DocumentFile, relativePath: String) {
            val children = runCatching { dir.listFiles() }.getOrElse { emptyArray() }
            for (child in children) {
                if (child.isDirectory) {
                    if (folder.includeSubfolders) {
                        val subName = child.name ?: continue
                        val nextRel = if (relativePath.isEmpty()) subName else "$relativePath/$subName"
                        walk(child, nextRel)
                    }
                } else if (child.isFile && isVideoDocument(child)) {
                    val uri = child.uri
                    val id = uri.toString()
                    discoveredIds += id
                    val size = child.length()
                    val modified = child.lastModified()
                    val cached = existingById[id]
                    if (cached != null &&
                        cached.lastModifiedMillis == modified &&
                        cached.fileSizeBytes == size &&
                        cached.relativeSubfolder == relativePath
                    ) {
                        // Cache is still fresh
                        continue
                    }
                    // Extract fresh metadata (preserving prior playback progress if re-indexing modified file)
                    val extracted = metadataExtractor.extractMetadata(
                        uri = uri,
                        displayName = child.name ?: "Untitled Video",
                        folderUri = folder.folderUri,
                        relativeSubfolder = relativePath,
                        fileSizeBytes = size,
                        lastModifiedMillis = modified,
                    ).copy(
                        lastPositionMs = cached?.lastPositionMs ?: 0L,
                        lastWatchedAtMillis = cached?.lastWatchedAtMillis ?: 0L,
                    )
                    updatedEntries += extracted
                }
            }
        }

        walk(rootDoc, "")

        if (updatedEntries.isNotEmpty()) {
            db.videoMetadataDao().upsertVideos(updatedEntries)
        }
        if (discoveredIds.isEmpty()) {
            db.videoMetadataDao().deleteVideosInFolder(folder.folderUri)
        } else {
            db.videoMetadataDao().pruneMissingInFolder(folder.folderUri, discoveredIds)
        }

        db.folderDao().upsertFolder(
            folder.copy(
                lastScannedMillis = System.currentTimeMillis(),
                videoCount = discoveredIds.size,
            )
        )
        discoveredIds.size
    }

    /**
     * Registers and extracts technical metadata for an individual video opened via
     * SAF OpenDocument or an external Android ACTION_VIEW intent.
     */
    suspend fun registerSingleVideoUri(uri: Uri): VideoMetadataEntity = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION,
            )
        }
        val videoId = uri.toString()
        val cached = db.videoMetadataDao().getVideoById(videoId)

        var displayName = uri.lastPathSegment?.substringAfterLast('/') ?: "Local Video"
        var sizeBytes = 0L
        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) cursor.getString(nameIdx)?.let { displayName = it }
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) sizeBytes = cursor.getLong(sizeIdx)
                }
            }
        }

        if (cached != null && (sizeBytes == 0L || cached.fileSizeBytes == sizeBytes)) {
            return@withContext cached
        }

        val extracted = metadataExtractor.extractMetadata(
            uri = uri,
            displayName = displayName,
            folderUri = SINGLE_FILES_FOLDER_URI,
            relativeSubfolder = "",
            fileSizeBytes = sizeBytes,
            lastModifiedMillis = System.currentTimeMillis(),
        ).copy(
            lastPositionMs = cached?.lastPositionMs ?: 0L,
            lastWatchedAtMillis = cached?.lastWatchedAtMillis ?: 0L,
        )
        db.videoMetadataDao().upsertVideo(extracted)
        extracted
    }

    /**
     * Enriches cached metadata with live decoder values read from libmpv during playback.
     */
    suspend fun enrichVideoFromMpvDecoder(videoId: String, stats: DecoderLiveStats) = withContext(Dispatchers.IO) {
        val dar = if (stats.aspect > 0.0) {
            AspectRatioCalculator.fromDarValue(stats.aspect, stats.displayWidth, stats.displayHeight)
        } else {
            AspectRatioCalculator.calculateFromPar(stats.width, stats.height, stats.par)
        }

        val bitDepth = when {
            stats.pixelFormat.contains("12") -> 12
            stats.pixelFormat.contains("10") || stats.pixelFormat.contains("p010") -> 10
            stats.pixelFormat.contains("yuv") || stats.pixelFormat.contains("nv12") -> 8
            else -> 0
        }

        val chroma = when {
            stats.pixelFormat.contains("444") -> "4:4:4"
            stats.pixelFormat.contains("422") -> "4:2:2"
            stats.pixelFormat.contains("420") || stats.pixelFormat.contains("nv12") || stats.pixelFormat.contains("p010") -> "4:2:0"
            else -> "Unknown"
        }

        val primaries = when (stats.primaries.lowercase(Locale.US)) {
            "bt.2020" -> "BT.2020"
            "bt.709" -> "BT.709"
            "bt.601-525", "bt.601-625", "smpte-170m" -> "BT.601"
            "dci-p3", "display-p3" -> "DCI-P3"
            else -> "Unknown"
        }

        val transfer = when (stats.gamma.lowercase(Locale.US)) {
            "pq" -> "PQ (SMPTE ST 2084)"
            "hlg" -> "HLG (ARIB STD-B67)"
            "bt.1886", "gamma2.2" -> "SDR (BT.1886)"
            else -> "Unknown"
        }

        db.videoMetadataDao().enrichTechnicalParams(
            videoId = videoId,
            videoCodec = if (stats.videoCodec != "—") stats.videoCodec else "Unknown",
            bitDepth = bitDepth,
            chroma = chroma,
            primaries = primaries,
            transfer = transfer,
            darLabel = dar.formattedLabel,
            darName = dar.standardName,
            darValue = dar.darValue,
        )
    }

    // ---- Playback Session Lifecycle (Crash-Safe) ----

    suspend fun startPlaybackSession(
        video: VideoMetadataEntity,
        startPositionMs: Long,
    ): Long = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val epochDay = now / 86_400_000L
        val session = PlaybackSessionEntity(
            videoId = video.videoId,
            videoFilename = video.filename,
            videoPath = buildDisplayPath(video),
            hdrFormatSnapshot = video.hdrFormat,
            sessionDateEpochDay = epochDay,
            openedAtMillis = now,
            closedAtMillis = now,
            startPositionMs = startPositionMs.coerceAtLeast(0L),
            endPositionMs = startPositionMs.coerceAtLeast(0L),
            watchedDurationMs = 0L,
            videoDurationMs = video.durationMs,
            completionPercent = computeCompletionPercent(startPositionMs, video.durationMs),
            isCompleted = false,
            terminationState = SessionTerminationState.ACTIVE.name,
            lastCheckpointMillis = now,
        )
        db.playbackSessionDao().insertSession(session)
    }

    suspend fun checkpointPlaybackSession(
        sessionId: Long,
        currentPositionMs: Long,
        watchedDurationMs: Long,
        videoDurationMs: Long,
    ) = withContext(Dispatchers.IO) {
        val existing = db.playbackSessionDao().getSessionById(sessionId) ?: return@withContext
        val now = System.currentTimeMillis()
        val effectiveDuration = videoDurationMs.coerceAtLeast(existing.videoDurationMs)
        val pct = computeCompletionPercent(currentPositionMs, effectiveDuration)
        val completed = pct >= COMPLETION_THRESHOLD_PERCENT

        db.playbackSessionDao().updateSession(
            existing.copy(
                closedAtMillis = now,
                endPositionMs = currentPositionMs.coerceAtLeast(0L),
                watchedDurationMs = watchedDurationMs.coerceAtLeast(existing.watchedDurationMs),
                videoDurationMs = effectiveDuration,
                completionPercent = pct,
                isCompleted = completed,
                lastCheckpointMillis = now,
            )
        )
        db.videoMetadataDao().updatePlaybackProgress(
            videoId = existing.videoId,
            positionMs = if (completed) 0L else currentPositionMs.coerceAtLeast(0L),
            watchedAtMillis = now,
        )
    }

    suspend fun finalizePlaybackSession(
        sessionId: Long,
        endPositionMs: Long,
        watchedDurationMs: Long,
        videoDurationMs: Long,
        terminationState: SessionTerminationState,
    ) = withContext(Dispatchers.IO) {
        val existing = db.playbackSessionDao().getSessionById(sessionId) ?: return@withContext
        val now = System.currentTimeMillis()
        val effectiveDuration = videoDurationMs.coerceAtLeast(existing.videoDurationMs)
        val pct = computeCompletionPercent(endPositionMs, effectiveDuration)
        val completed = pct >= COMPLETION_THRESHOLD_PERCENT

        db.playbackSessionDao().updateSession(
            existing.copy(
                closedAtMillis = now,
                endPositionMs = endPositionMs.coerceAtLeast(0L),
                watchedDurationMs = watchedDurationMs.coerceAtLeast(existing.watchedDurationMs),
                videoDurationMs = effectiveDuration,
                completionPercent = pct,
                isCompleted = completed,
                terminationState = terminationState.name,
                lastCheckpointMillis = now,
            )
        )
        db.videoMetadataDao().updatePlaybackProgress(
            videoId = existing.videoId,
            positionMs = if (completed) 0L else endPositionMs.coerceAtLeast(0L),
            watchedAtMillis = now,
        )

        // Update review watched status & rewatch counter WITHOUT overwriting user's written review or rating
        if (completed) {
            val review = db.personalReviewDao().getReview(existing.videoId)
            if (review == null) {
                db.personalReviewDao().upsertReview(
                    PersonalReviewEntity(
                        videoId = existing.videoId,
                        watchedStatus = WatchedStatus.WATCHED.name,
                        viewingDateMillis = now,
                        rewatchCount = 0,
                        createdAtMillis = now,
                        updatedAtMillis = now,
                    )
                )
            } else {
                val wasAlreadyWatched = review.watchedStatus == WatchedStatus.WATCHED.name
                db.personalReviewDao().upsertReview(
                    review.copy(
                        watchedStatus = WatchedStatus.WATCHED.name,
                        viewingDateMillis = if (review.viewingDateMillis == 0L) now else review.viewingDateMillis,
                        rewatchCount = if (wasAlreadyWatched) review.rewatchCount + 1 else review.rewatchCount,
                        updatedAtMillis = now,
                    )
                )
            }
        }
    }

    suspend fun deleteSession(sessionId: Long) = withContext(Dispatchers.IO) {
        db.playbackSessionDao().deleteSession(sessionId)
    }

    // ---- Personal Reviews ----

    suspend fun savePersonalReview(review: PersonalReviewEntity) = withContext(Dispatchers.IO) {
        val existing = db.personalReviewDao().getReview(review.videoId)
        val now = System.currentTimeMillis()
        db.personalReviewDao().upsertReview(
            review.copy(
                createdAtMillis = existing?.createdAtMillis ?: now,
                updatedAtMillis = now,
            )
        )
    }

    // ---- Timestamp Bookmarks ----

    suspend fun addBookmark(
        videoId: String,
        videoFilename: String,
        timestampMs: Long,
        title: String,
        note: String,
        isFavouriteScene: Boolean,
    ): Long = withContext(Dispatchers.IO) {
        db.timestampBookmarkDao().insertBookmark(
            TimestampBookmarkEntity(
                videoId = videoId,
                videoFilename = videoFilename,
                timestampMs = timestampMs.coerceAtLeast(0L),
                title = title.trim(),
                note = note.trim(),
                isFavouriteScene = isFavouriteScene,
                createdAtMillis = System.currentTimeMillis(),
            )
        )
    }

    suspend fun toggleBookmarkFavourite(bookmark: TimestampBookmarkEntity) = withContext(Dispatchers.IO) {
        db.timestampBookmarkDao().updateBookmark(bookmark.copy(isFavouriteScene = !bookmark.isFavouriteScene))
    }

    suspend fun deleteBookmark(bookmarkId: Long) = withContext(Dispatchers.IO) {
        db.timestampBookmarkDao().deleteBookmark(bookmarkId)
    }

    // ---- mpv Configuration & Backups ----

    suspend fun applyMpvConfigWithBackup(
        mpvConf: String,
        inputConf: String,
        reason: String,
    ) = withContext(Dispatchers.IO) {
        // Always save backup of previous config before overwriting
        db.mpvConfigDao().insertBackup(
            MpvConfigBackupEntity(
                reason = reason,
                mpvConf = mpvConfigManager.readMpvConf(),
                inputConf = mpvConfigManager.readInputConf(),
            )
        )
        mpvConfigManager.writeConfigs(mpvConf, inputConf)
    }

    suspend fun activateProfile(profile: MpvProfileEntity) = withContext(Dispatchers.IO) {
        applyMpvConfigWithBackup(
            mpvConf = profile.mpvConf,
            inputConf = profile.inputConf,
            reason = "Before switching to profile: ${profile.name}",
        )
        db.mpvConfigDao().setActiveProfile(profile.profileId)
    }

    suspend fun saveCustomProfile(
        name: String,
        description: String,
        mpvConf: String,
        inputConf: String,
    ) = withContext(Dispatchers.IO) {
        val id = "custom_${UUID.randomUUID().toString().take(8)}"
        db.mpvConfigDao().upsertProfile(
            MpvProfileEntity(
                profileId = id,
                name = name.trim().ifBlank { "Custom Profile" },
                description = description.trim(),
                mpvConf = mpvConf,
                inputConf = inputConf,
                isActive = false,
                isBuiltIn = false,
                updatedAtMillis = System.currentTimeMillis(),
            )
        )
    }

    suspend fun deleteCustomProfile(profileId: String) = withContext(Dispatchers.IO) {
        db.mpvConfigDao().deleteCustomProfile(profileId)
    }

    suspend fun restoreBackup(backup: MpvConfigBackupEntity) = withContext(Dispatchers.IO) {
        applyMpvConfigWithBackup(
            mpvConf = backup.mpvConf,
            inputConf = backup.inputConf,
            reason = "Before restoring backup #${backup.backupId}",
        )
    }

    suspend fun restoreDefaultConfigs() = withContext(Dispatchers.IO) {
        applyMpvConfigWithBackup(
            mpvConf = MpvConfigManager.DEFAULT_HDR_MPV_CONF,
            inputConf = MpvConfigManager.DEFAULT_INPUT_CONF,
            reason = "Before restoring factory defaults",
        )
        db.mpvConfigDao().setActiveProfile("builtin_hdr_reference")
    }

    // ---- Pure Statistics Calculation (No Fabricated Data) ----

    fun computeStats(
        sessions: List<PlaybackSessionEntity>,
        reviews: List<PersonalReviewEntity>,
        videos: List<VideoMetadataEntity>,
    ): CinemaStatsSummary {
        if (sessions.isEmpty()) return CinemaStatsSummary()

        val totalMs = sessions.sumOf { it.watchedDurationMs }
        val uniqueVideos = sessions.map { it.videoId }.distinct().size
        val avgMs = totalMs / sessions.size
        val completedCount = sessions.count { it.isCompleted }
        val reviewMap = reviews.associateBy { it.videoId }
        val videoMap = videos.associateBy { it.videoId }
        val totalRewatches = reviews.sumOf { it.rewatchCount }

        // Weekly chart: last 7 calendar days
        val cal = Calendar.getInstance()
        val dayFmt = SimpleDateFormat("EEE", Locale.getDefault())
        val weekly = (6 downTo 0).map { daysAgo ->
            val c = (cal.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, -daysAgo)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val start = c.timeInMillis
            val end = start + 86_400_000L
            val dayMs = sessions.filter { it.openedAtMillis in start until end }
                .sumOf { it.watchedDurationMs }
            DailyWatchPoint(
                label = dayFmt.format(Date(start)),
                watchedMinutes = dayMs / 60_000f,
            )
        }

        // Monthly chart: last 6 calendar months
        val monthFmt = SimpleDateFormat("MMM", Locale.getDefault())
        val monthly = (5 downTo 0).map { monthsAgo ->
            val c = (cal.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.MONTH, -monthsAgo)
            }
            val start = c.timeInMillis
            val nextMonth = (c.clone() as Calendar).apply { add(Calendar.MONTH, 1) }.timeInMillis
            val monthMs = sessions.filter { it.openedAtMillis in start until nextMonth }
                .sumOf { it.watchedDurationMs }
            MonthlyWatchPoint(
                label = monthFmt.format(Date(start)),
                watchedHours = monthMs / 3_600_000f,
            )
        }

        // HDR vs SDR distribution strictly from recorded sessions
        val hdrCounts = mutableMapOf<HdrFormat, Int>()
        val hdrDurations = mutableMapOf<HdrFormat, Long>()
        sessions.forEach { s ->
            val fmt = HdrFormat.fromStored(videoMap[s.videoId]?.hdrFormat ?: s.hdrFormatSnapshot)
            hdrCounts[fmt] = (hdrCounts[fmt] ?: 0) + 1
            hdrDurations[fmt] = (hdrDurations[fmt] ?: 0L) + s.watchedDurationMs
        }

        // Most-watched videos
        val mostWatched = sessions.groupBy { it.videoId }
            .map { (vid, list) ->
                val latest = list.maxBy { it.openedAtMillis }
                val meta = videoMap[vid]
                val rev = reviewMap[vid]
                MostWatchedItem(
                    videoId = vid,
                    filename = meta?.filename ?: latest.videoFilename,
                    sessionCount = list.size,
                    totalWatchedMs = list.sumOf { it.watchedDurationMs },
                    hdrFormat = HdrFormat.fromStored(meta?.hdrFormat ?: latest.hdrFormatSnapshot),
                    rewatchCount = rev?.rewatchCount ?: 0,
                )
            }
            .sortedByDescending { it.totalWatchedMs }
            .take(8)

        return CinemaStatsSummary(
            totalViewingMs = totalMs,
            uniqueVideosWatched = uniqueVideos,
            totalSessions = sessions.size,
            averageSessionMs = avgMs,
            totalRewatches = totalRewatches,
            completedSessions = completedCount,
            weeklyPoints = weekly,
            monthlyPoints = monthly,
            hdrBreakdownCounts = hdrCounts,
            hdrBreakdownDurationMs = hdrDurations,
            mostWatched = mostWatched,
        )
    }

    private fun isVideoDocument(doc: DocumentFile): Boolean {
        val mime = doc.type.orEmpty().lowercase(Locale.US)
        if (mime.startsWith("video/")) return true
        val ext = doc.name.orEmpty().substringAfterLast('.', "").lowercase(Locale.US)
        return ext in SUPPORTED_VIDEO_EXTENSIONS
    }

    private fun buildDisplayPath(video: VideoMetadataEntity): String {
        return if (video.relativeSubfolder.isNotBlank()) {
            "${video.relativeSubfolder}/${video.filename}"
        } else {
            video.filename
        }
    }

    companion object {
        const val SINGLE_FILES_FOLDER_URI = "local://opened-files"
        const val COMPLETION_THRESHOLD_PERCENT = 90f

        private val SUPPORTED_VIDEO_EXTENSIONS = setOf(
            "mkv", "mp4", "m4v", "mov", "webm", "avi", "ts", "m2ts", "mts", "wmv", "flv", "3gp", "ogv", "mpg", "mpeg",
        )

        fun computeCompletionPercent(positionMs: Long, durationMs: Long): Float {
            if (durationMs <= 0L) return 0f
            return ((positionMs.toFloat() / durationMs.toFloat()) * 100f).coerceIn(0f, 100f)
        }
    }
}
