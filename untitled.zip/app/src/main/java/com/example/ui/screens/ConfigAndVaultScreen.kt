package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Upload
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.ConfigValidationIssue
import com.example.domain.ConfigValidationResult
import com.example.media.Formatters
import com.example.ui.components.MpvConfigSyntaxTransformation
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaBorderSubtle
import com.example.ui.theme.CinemaCharcoal
import com.example.ui.theme.CinemaCrimson
import com.example.ui.theme.CinemaEmerald
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.CinemaGoldContainer
import com.example.ui.theme.CinemaIce
import com.example.ui.theme.CinemaObsidian
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceHigh
import com.example.ui.theme.CinemaTextMuted
import com.example.ui.theme.CinemaTextPrimary
import com.example.ui.theme.CinemaTextSecondary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.viewmodel.CinemaAppViewModel

@Composable
fun ConfigAndVaultScreen(
    viewModel: CinemaAppViewModel,
    modifier: Modifier = Modifier,
) {
    val editorState by viewModel.configEditorState.collectAsStateWithLifecycle()
    val profiles by viewModel.mpvProfiles.collectAsStateWithLifecycle()
    val backups by viewModel.mpvBackups.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var showRestoreDefaultsDialog by remember { mutableStateOf(false) }
    var showSaveProfileDialog by remember { mutableStateOf(false) }

    val importMpvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) viewModel.importConfigFile(uri, isInputConf = false)
    }
    val exportMpvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri: Uri? ->
        if (uri != null) viewModel.exportConfigFile(uri, isInputConf = false)
    }
    val importInputLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) viewModel.importConfigFile(uri, isInputConf = true)
    }
    val exportInputLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri: Uri? ->
        if (uri != null) viewModel.exportConfigFile(uri, isInputConf = true)
    }
    val exportVaultLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) viewModel.exportPersonalVault(uri)
    }
    val importVaultLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) viewModel.importPersonalVault(uri)
    }

    val tabs = listOf(
        stringResource(R.string.config_tab_mpv),
        stringResource(R.string.config_tab_input),
        stringResource(R.string.config_tab_profiles),
        stringResource(R.string.config_tab_vault),
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CinemaObsidian),
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(
                text = stringResource(R.string.config_title),
                style = MaterialTheme.typography.headlineMedium,
                color = CinemaTextPrimary,
            )
            Text(
                text = "Local libmpv engine configuration, backups, and offline vault",
                style = MaterialTheme.typography.bodySmall,
                color = CinemaTextSecondary,
            )
        }

        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = CinemaCharcoal,
            contentColor = CinemaGold,
            edgePadding = 12.dp,
        ) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = {
                        Text(
                            text = title,
                            color = if (selectedTab == idx) CinemaGold else CinemaTextSecondary,
                        )
                    },
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when (selectedTab) {
                0 -> {
                    ConfigEditorPanel(
                        fileLabel = "mpv.conf",
                        text = editorState.mpvConfText,
                        isInputConf = false,
                        validation = editorState.mpvValidation,
                        hasUnsavedChanges = editorState.hasUnsavedChanges,
                        onTextChange = { viewModel.updateMpvConfText(it) },
                        onValidate = { viewModel.validateConfigs() },
                        onApply = { viewModel.applyConfigsWithBackup("Manual mpv.conf apply") },
                        onImport = { importMpvLauncher.launch(arrayOf("text/*", "*/*")) },
                        onExport = { exportMpvLauncher.launch("mpv.conf") },
                        onRestoreDefaults = { showRestoreDefaultsDialog = true },
                    )
                }

                1 -> {
                    ConfigEditorPanel(
                        fileLabel = "input.conf",
                        text = editorState.inputConfText,
                        isInputConf = true,
                        validation = editorState.inputValidation,
                        hasUnsavedChanges = editorState.hasUnsavedChanges,
                        onTextChange = { viewModel.updateInputConfText(it) },
                        onValidate = { viewModel.validateConfigs() },
                        onApply = { viewModel.applyConfigsWithBackup("Manual input.conf apply") },
                        onImport = { importInputLauncher.launch(arrayOf("text/*", "*/*")) },
                        onExport = { exportInputLauncher.launch("input.conf") },
                        onRestoreDefaults = { showRestoreDefaultsDialog = true },
                    )
                }

                2 -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Configuration Profiles", style = MaterialTheme.typography.titleMedium)
                        OutlinedButton(
                            onClick = { showSaveProfileDialog = true },
                            border = BorderStroke(1.dp, CinemaGold),
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, tint = CinemaGold, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Save Current", color = CinemaGold)
                        }
                    }

                    profiles.forEach { profile ->
                        Surface(
                            color = if (profile.isActive) CinemaGoldContainer.copy(alpha = 0.45f) else CinemaSurface,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, if (profile.isActive) CinemaGold else CinemaBorderSubtle),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        text = profile.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = if (profile.isActive) CinemaGold else CinemaTextPrimary,
                                    )
                                    if (!profile.isBuiltIn) {
                                        IconButton(
                                            onClick = { viewModel.deleteCustomProfile(profile.profileId) },
                                            modifier = Modifier.size(32.dp),
                                        ) {
                                            Icon(Icons.Outlined.Delete, contentDescription = "Delete profile", tint = CinemaTextMuted)
                                        }
                                    }
                                }
                                if (profile.description.isNotBlank()) {
                                    Text(profile.description, style = MaterialTheme.typography.bodySmall, color = CinemaTextSecondary)
                                }
                                Button(
                                    onClick = { viewModel.activateProfile(profile) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (profile.isActive) CinemaSurfaceHigh else CinemaGold,
                                        contentColor = if (profile.isActive) CinemaTextPrimary else CinemaObsidian,
                                    ),
                                ) {
                                    Text(if (profile.isActive) "Re-Apply Profile (Creates Backup)" else "Activate Profile")
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    Text("Automatic Config Backups (${backups.size})", style = MaterialTheme.typography.titleMedium)
                    if (backups.isEmpty()) {
                        Text(
                            text = "Backups are created automatically every time you apply changes, switch profiles, or restore defaults.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CinemaTextMuted,
                        )
                    } else {
                        backups.forEach { backup ->
                            Surface(
                                color = CinemaSurface,
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, CinemaBorderSubtle),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(backup.reason, style = MaterialTheme.typography.titleSmall, color = CinemaTextPrimary)
                                        Text(
                                            Formatters.formatDateTime(backup.createdAtMillis),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CinemaTextMuted,
                                        )
                                    }
                                    TextButton(onClick = { viewModel.restoreConfigBackup(backup) }) {
                                        Icon(Icons.Outlined.Restore, contentDescription = null, tint = CinemaGold, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Restore", color = CinemaGold)
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // Local Database Vault Backup & Restore
                    Surface(
                        color = CinemaSurface,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, CinemaBorderSubtle),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Outlined.Backup, contentDescription = null, tint = CinemaGold)
                                Text("Local Vault Backup & Restore", style = MaterialTheme.typography.titleMedium)
                            }
                            Text(
                                text = "Export all indexed metadata, playback session history, personal reviews, timestamp bookmarks, and mpv configuration profiles into a portable offline JSON file stored wherever you choose.",
                                style = MaterialTheme.typography.bodySmall,
                                color = CinemaTextSecondary,
                            )
                            Button(
                                onClick = { exportVaultLauncher.launch("personal_cinema_vault_backup.json") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("export_vault_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
                            ) {
                                Icon(Icons.Outlined.Upload, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(stringResource(R.string.vault_export_db))
                            }
                            OutlinedButton(
                                onClick = { importVaultLauncher.launch(arrayOf("application/json", "*/*")) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("import_vault_button"),
                                border = BorderStroke(1.dp, CinemaBorder),
                            ) {
                                Icon(Icons.Outlined.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(stringResource(R.string.vault_import_db))
                            }
                        }
                    }

                    // Strict Offline Privacy Audit Card
                    Surface(
                        color = CinemaSurface,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, CinemaEmerald.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Rounded.Shield, contentDescription = null, tint = CinemaEmerald)
                                Text("Offline Privacy Architecture", style = MaterialTheme.typography.titleMedium, color = CinemaEmerald)
                            }
                            Text("• INTERNET permission stripped from AndroidManifest (tools:node=\"remove\").", style = MaterialTheme.typography.bodySmall)
                            Text("• Zero cloud sync, zero accounts, zero analytics, zero remote metadata or subtitle scrapers.", style = MaterialTheme.typography.bodySmall)
                            Text("• Zero broad storage permissions: uses Android Storage Access Framework (SAF) scoped URI permissions.", style = MaterialTheme.typography.bodySmall)
                            Text("• libmpv hardened with ytdl=no and load-scripts=no by default.", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    // Licensing & Attribution Notice
                    Surface(
                        color = CinemaSurface,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, CinemaBorderSubtle),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text("Licensing & Upstream Attribution", style = MaterialTheme.typography.titleMedium, color = CinemaGold)
                            Text(
                                text = "Personal Cinema is an offline-first personal fork inspired by mpvEx / mpvKt and built on libmpv via mpv-android-lib (is.xyz.mpv.MPVLib).",
                                style = MaterialTheme.typography.bodySmall,
                                color = CinemaTextPrimary,
                            )
                            Text(
                                text = "• mpv & libmpv: Copyright © mpv developers — GPLv2+ / LGPLv2.1+.\n" +
                                    "• mpv-android & mpv-android-lib: Copyright © mpv-android & Abdallah Mehiz contributors — MIT / GPLv3 (with GPL libmpv binary redistribution obligations).\n" +
                                    "• mpvEx (mpvExtended): Copyright © marlboro-advance & contributors.\n" +
                                    "• FFmpeg, libass, libplacebo, dav1d, MediaCodec JNI components: respective open-source licences preserved.",
                                style = MaterialTheme.typography.bodySmall,
                                color = CinemaTextSecondary,
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showRestoreDefaultsDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDefaultsDialog = false },
            containerColor = CinemaCharcoal,
            title = { Text("Restore Factory Defaults?") },
            text = {
                Text(
                    "Your current mpv.conf and input.conf will be automatically backed up before restoring the default HDR Reference configuration."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.restoreFactoryDefaults()
                        showRestoreDefaultsDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
                ) {
                    Text("Backup & Restore Defaults")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDefaultsDialog = false }) { Text("Cancel") }
            },
        )
    }

    if (showSaveProfileDialog) {
        var name by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSaveProfileDialog = false },
            containerColor = CinemaCharcoal,
            title = { Text("Save Custom mpv Profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Profile Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = desc,
                        onValueChange = { desc = it },
                        label = { Text("Description (optional)") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveCurrentAsProfile(name, desc)
                        showSaveProfileDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
                ) {
                    Text("Save Profile")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveProfileDialog = false }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun ConfigEditorPanel(
    fileLabel: String,
    text: String,
    isInputConf: Boolean,
    validation: ConfigValidationResult?,
    hasUnsavedChanges: Boolean,
    onTextChange: (String) -> Unit,
    onValidate: () -> Unit,
    onApply: () -> Unit,
    onImport: () -> Unit,
    onExport: () -> Unit,
    onRestoreDefaults: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = if (hasUnsavedChanges) "$fileLabel · Unsaved edits" else "$fileLabel · Synced",
            style = MaterialTheme.typography.titleMedium,
            color = if (hasUnsavedChanges) CinemaGold else CinemaEmerald,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = onImport) { Text(stringResource(R.string.config_import), color = CinemaIce) }
            TextButton(onClick = onExport) { Text(stringResource(R.string.config_export), color = CinemaIce) }
        }
    }

    OutlinedTextField(
        value = text,
        onValueChange = onTextChange,
        visualTransformation = remember(isInputConf) { MpvConfigSyntaxTransformation(isInputConf) },
        textStyle = TextStyle(
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 13.sp,
            lineHeight = 20.sp,
            color = CinemaTextPrimary,
        ),
        minLines = 14,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("editor_$fileLabel"),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = CinemaCharcoal,
            unfocusedContainerColor = CinemaCharcoal,
            focusedBorderColor = CinemaGold,
            unfocusedBorderColor = CinemaBorder,
        ),
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Button(
            onClick = onApply,
            modifier = Modifier
                .weight(1f)
                .testTag("apply_config_button"),
            colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
        ) {
            Icon(Icons.Outlined.Save, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.config_apply))
        }
        OutlinedButton(
            onClick = onValidate,
            border = BorderStroke(1.dp, CinemaBorder),
        ) {
            Text(stringResource(R.string.config_validate))
        }
    }

    OutlinedButton(
        onClick = onRestoreDefaults,
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, CinemaBorderSubtle),
    ) {
        Icon(Icons.Outlined.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(stringResource(R.string.config_restore_defaults))
    }

    validation?.let { result ->
        Surface(
            color = CinemaSurface,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, if (result.isValid) CinemaEmerald.copy(alpha = 0.5f) else CinemaCrimson),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = if (result.isValid) Icons.Outlined.CheckCircle else Icons.Rounded.ErrorOutline,
                        contentDescription = null,
                        tint = if (result.isValid) CinemaEmerald else CinemaCrimson,
                        modifier = Modifier.size(18.dp),
                    )
                    Text(
                        text = if (result.isValid) "Validation Passed (${result.issues.size} notice(s))" else "Validation Errors Found",
                        style = MaterialTheme.typography.titleSmall,
                        color = if (result.isValid) CinemaEmerald else CinemaCrimson,
                    )
                }
                if (result.issues.isNotEmpty()) {
                    HorizontalDivider(color = CinemaBorderSubtle)
                    result.issues.forEach { issue ->
                        val tint = when (issue.severity) {
                            ConfigValidationIssue.Severity.ERROR -> CinemaCrimson
                            ConfigValidationIssue.Severity.WARNING -> CinemaGold
                            ConfigValidationIssue.Severity.INFO -> CinemaIce
                        }
                        val icon = when (issue.severity) {
                            ConfigValidationIssue.Severity.ERROR -> Icons.Rounded.ErrorOutline
                            ConfigValidationIssue.Severity.WARNING -> Icons.Rounded.WarningAmber
                            ConfigValidationIssue.Severity.INFO -> Icons.Rounded.Info
                        }
                        Row(
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Line ${issue.lineNumber}: ${issue.message}",
                                style = MaterialTheme.typography.bodySmall,
                                color = CinemaTextPrimary,
                            )
                        }
                    }
                }
            }
        }
    }
}
