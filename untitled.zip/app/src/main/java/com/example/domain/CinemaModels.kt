package com.example.domain

enum class HdrFormat(val displayName: String, val shortLabel: String) {
    DOLBY_VISION("Dolby Vision", "DV"),
    HDR10_PLUS("HDR10+", "HDR10+"),
    HDR10("HDR10", "HDR10"),
    HLG("HLG", "HLG"),
    SDR("SDR", "SDR"),
    UNKNOWN("Unverified", "N/A");

    val isHdr: Boolean
        get() = this == DOLBY_VISION || this == HDR10_PLUS || this == HDR10 || this == HLG

    companion object {
        fun fromStored(value: String?): HdrFormat =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: UNKNOWN
    }
}

enum class WatchedStatus(val label: String) {
    UNWATCHED("Unwatched"),
    WATCHING("In Progress"),
    WATCHED("Watched"),
    ON_HOLD("On Hold");

    companion object {
        fun fromStored(value: String?): WatchedStatus =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: UNWATCHED
    }
}

enum class SessionTerminationState(val label: String) {
    ACTIVE("In Progress"),
    NORMAL("Ended Normally"),
    INTERRUPTED("Interrupted"),
    CRASH_RECOVERED("Recovered After Crash");

    companion object {
        fun fromStored(value: String?): SessionTerminationState =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: INTERRUPTED
    }
}

enum class AspectRatioPreset(val label: String, val mpvValue: String) {
    NATIVE("Native DAR", "-1"),
    SCOPE_239("2.39:1 Scope", "2.39"),
    SCOPE_240("2.40:1 Scope", "2.40"),
    IMAX_190("1.90:1 IMAX", "1.90"),
    FLAT_185("1.85:1 Flat", "1.85"),
    HD_178("1.78:1 (16:9)", "16:9"),
    ACADEMY_133("1.33:1 (4:3)", "4:3"),
    FILL_CROP("Fill / Crop", "fill"),
}

data class TrackInfo(
    val id: Int,
    val type: String, // "video", "audio", "sub"
    val title: String,
    val language: String,
    val codec: String,
    val channels: Int? = null,
    val isDefault: Boolean = false,
    val isSelected: Boolean = false,
    val isExternal: Boolean = false,
)

data class ChapterInfo(
    val index: Int,
    val title: String,
    val startTimeMs: Long,
)

data class DisplayHdrCapabilities(
    val isDisplayHdrCapable: Boolean,
    val supportsDolbyVision: Boolean,
    val supportsHdr10Plus: Boolean,
    val supportsHdr10: Boolean,
    val supportsHlg: Boolean,
    val maxLuminanceNits: Float?,
    val maxAverageLuminanceNits: Float?,
    val minLuminanceNits: Float?,
    val wideColorGamutSupported: Boolean,
    val summary: String,
)

data class DecoderLiveStats(
    val videoCodec: String = "—",
    val hwDecCurrent: String = "—",
    val currentVo: String = "—",
    val width: Int = 0,
    val height: Int = 0,
    val displayWidth: Int = 0,
    val displayHeight: Int = 0,
    val par: Double = 1.0,
    val aspect: Double = 0.0,
    val fps: Double = 0.0,
    val pixelFormat: String = "—",
    val hwPixelFormat: String = "—",
    val primaries: String = "—",
    val gamma: String = "—",
    val colorMatrix: String = "—",
    val sigPeak: Double? = null,
    val maxLuma: Double? = null,
    val targetColorspaceHint: Boolean = false,
    val toneMappingMode: String = "auto",
    val audioCodec: String = "—",
    val audioChannels: Int = 0,
    val audioSampleRate: Int = 0,
)

/**
 * Strictly separates the four independent stages of the HDR pipeline so the UI
 * never conflates container flags with actual decoder metadata or display output.
 */
data class HdrPipelineReport(
    val sourceFormat: HdrFormat,
    val sourceEvidence: String,
    val decoderMetadataSummary: String,
    val rendererCapabilitySummary: String,
    val displayHardwareSummary: String,
    val isDisplayOutputtingHdrLikely: Boolean,
    val honestyNote: String,
)

enum class LibrarySortOption(val label: String) {
    TITLE_ASC("Title (A–Z)"),
    DATE_MODIFIED_DESC("Newest File"),
    LAST_WATCHED_DESC("Recently Watched"),
    RATING_DESC("Highest Rated"),
    DURATION_DESC("Longest Duration"),
    FILE_SIZE_DESC("Largest Size"),
}

data class LibraryFilterState(
    val query: String = "",
    val selectedFolderUri: String? = null,
    val selectedSubfolder: String? = null,
    val hdrFilter: HdrFormat? = null,
    val watchedFilter: WatchedStatus? = null,
    val favouritesOnly: Boolean = false,
    val minRating: Float = 0f,
    val selectedTag: String? = null,
    val aspectRatioFilter: String? = null,
    val sortOption: LibrarySortOption = LibrarySortOption.TITLE_ASC,
    val isGridLayout: Boolean = true,
)

data class ConfigValidationIssue(
    val lineNumber: Int,
    val severity: Severity,
    val message: String,
) {
    enum class Severity { ERROR, WARNING, INFO }
}

data class ConfigValidationResult(
    val isValid: Boolean,
    val issues: List<ConfigValidationIssue>,
)

data class DailyWatchPoint(
    val label: String,
    val watchedMinutes: Float,
)

data class MonthlyWatchPoint(
    val label: String,
    val watchedHours: Float,
)

data class MostWatchedItem(
    val videoId: String,
    val filename: String,
    val sessionCount: Int,
    val totalWatchedMs: Long,
    val hdrFormat: HdrFormat,
    val rewatchCount: Int,
)

data class CinemaStatsSummary(
    val totalViewingMs: Long = 0L,
    val uniqueVideosWatched: Int = 0,
    val totalSessions: Int = 0,
    val averageSessionMs: Long = 0L,
    val totalRewatches: Int = 0,
    val completedSessions: Int = 0,
    val weeklyPoints: List<DailyWatchPoint> = emptyList(),
    val monthlyPoints: List<MonthlyWatchPoint> = emptyList(),
    val hdrBreakdownCounts: Map<HdrFormat, Int> = emptyMap(),
    val hdrBreakdownDurationMs: Map<HdrFormat, Long> = emptyMap(),
    val mostWatched: List<MostWatchedItem> = emptyList(),
)
