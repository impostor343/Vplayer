package com.example.media

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object Formatters {

    fun formatDurationMs(ms: Long): String {
        if (ms <= 0L) return "0:00"
        val totalSeconds = ms / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatHumanDuration(ms: Long): String {
        if (ms <= 0L) return "0m"
        val totalMinutes = ms / 60_000L
        val hours = totalMinutes / 60L
        val minutes = totalMinutes % 60L
        return when {
            hours > 0L && minutes > 0L -> "${hours}h ${minutes}m"
            hours > 0L -> "${hours}h"
            totalMinutes > 0L -> "${totalMinutes}m"
            else -> "${(ms / 1000L).coerceAtLeast(1L)}s"
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "—"
        val kb = 1024.0
        val mb = kb * 1024.0
        val gb = mb * 1024.0
        return when {
            bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
            bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
            bytes >= kb -> String.format(Locale.US, "%.0f KB", bytes / kb)
            else -> "$bytes B"
        }
    }

    fun formatFrameRate(fps: Float): String {
        if (fps <= 0f || !fps.isFinite()) return "Unknown"
        return when {
            abs(fps - 23.976f) < 0.03f -> "23.976 fps"
            abs(fps - 24f) < 0.03f -> "24.000 fps"
            abs(fps - 25f) < 0.03f -> "25.000 fps"
            abs(fps - 29.97f) < 0.04f -> "29.970 fps"
            abs(fps - 30f) < 0.03f -> "30.000 fps"
            abs(fps - 50f) < 0.05f -> "50.000 fps"
            abs(fps - 59.94f) < 0.06f -> "59.940 fps"
            abs(fps - 60f) < 0.05f -> "60.000 fps"
            else -> String.format(Locale.US, "%.2f fps", fps)
        }
    }

    fun formatDateTime(epochMillis: Long): String {
        if (epochMillis <= 0L) return "—"
        val sdf = SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.getDefault())
        return sdf.format(Date(epochMillis))
    }

    fun formatDateOnly(epochMillis: Long): String {
        if (epochMillis <= 0L) return "—"
        val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
        return sdf.format(Date(epochMillis))
    }

    fun formatTimeOnly(epochMillis: Long): String {
        if (epochMillis <= 0L) return "—"
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(epochMillis))
    }

    fun formatResolutionLabel(width: Int, height: Int): String {
        if (width <= 0 || height <= 0) return "Unknown"
        val tier = when {
            width >= 3800 || height >= 2000 -> "4K UHD"
            width >= 2500 || height >= 1400 -> "1440p"
            width >= 1900 || height >= 1000 -> "1080p"
            width >= 1260 || height >= 700 -> "720p"
            else -> "SD"
        }
        return "${width}×${height} ($tier)"
    }

    fun prettyCodecName(mimeOrCodec: String?): String {
        val raw = mimeOrCodec.orEmpty().lowercase(Locale.US)
        return when {
            raw.contains("dolby-vision") || raw.contains("dvhe") || raw.contains("dvh1") -> "Dolby Vision (HEVC)"
            raw.contains("hevc") || raw.contains("h265") || raw.contains("265") -> "HEVC (H.265)"
            raw.contains("av01") || raw.contains("av1") -> "AV1"
            raw.contains("avc") || raw.contains("h264") || raw.contains("264") -> "AVC (H.264)"
            raw.contains("vp09") || raw.contains("vp9") -> "VP9"
            raw.contains("vp08") || raw.contains("vp8") -> "VP8"
            raw.contains("mp4v") -> "MPEG-4 Visual"
            raw.contains("mpeg2") -> "MPEG-2"
            raw.contains("eac3") || raw.contains("ec-3") -> "E-AC-3 (Dolby Digital+)"
            raw.contains("ac3") || raw.contains("ac-3") -> "AC-3 (Dolby Digital)"
            raw.contains("truehd") -> "Dolby TrueHD"
            raw.contains("dts") -> "DTS"
            raw.contains("opus") -> "Opus"
            raw.contains("flac") -> "FLAC"
            raw.contains("mp4a") || raw.contains("aac") -> "AAC"
            raw.contains("vorbis") -> "Vorbis"
            raw.contains("pcm") || raw.contains("raw") -> "PCM"
            raw.isBlank() -> "Unknown"
            else -> mimeOrCodec!!.substringAfter('/').uppercase(Locale.US)
        }
    }
}
