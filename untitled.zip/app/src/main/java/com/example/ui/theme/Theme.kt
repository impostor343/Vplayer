package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val CinemaDarkColorScheme = darkColorScheme(
    primary = CinemaGold,
    onPrimary = CinemaObsidian,
    primaryContainer = CinemaGoldContainer,
    onPrimaryContainer = CinemaGoldBright,
    secondary = CinemaIce,
    onSecondary = CinemaObsidian,
    secondaryContainer = CinemaIceContainer,
    onSecondaryContainer = CinemaIce,
    tertiary = CinemaEmerald,
    onTertiary = CinemaObsidian,
    background = CinemaObsidian,
    onBackground = CinemaTextPrimary,
    surface = CinemaCharcoal,
    onSurface = CinemaTextPrimary,
    surfaceVariant = CinemaSurface,
    onSurfaceVariant = CinemaTextSecondary,
    surfaceContainerLowest = CinemaObsidian,
    surfaceContainerLow = CinemaCharcoal,
    surfaceContainer = CinemaSurface,
    surfaceContainerHigh = CinemaSurfaceHigh,
    surfaceContainerHighest = CinemaSurfaceHighest,
    outline = CinemaBorder,
    outlineVariant = CinemaBorderSubtle,
    error = CinemaCrimson,
    onError = CinemaObsidian,
    errorContainer = CinemaCrimsonContainer,
    onErrorContainer = CinemaCrimson,
)

private val CinemaShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun PersonalCinemaTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = CinemaDarkColorScheme,
        typography = CinemaTypography,
        shapes = CinemaShapes,
        content = content,
    )
}
