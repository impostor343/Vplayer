package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.domain.HdrFormat
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.CinemaIce
import com.example.ui.theme.CinemaTextMuted
import com.example.ui.theme.CinemaTextPrimary
import com.example.ui.theme.CinemaTextSecondary
import com.example.ui.theme.FormatDolbyVisionViolet
import com.example.ui.theme.FormatHdr10Amber
import com.example.ui.theme.FormatHdr10PlusGold
import com.example.ui.theme.FormatHlgCyan
import com.example.ui.theme.FormatSdrSlate
import java.util.Locale

data class BarDatum(
    val label: String,
    val value: Float,
    val formattedValue: String,
)

@Composable
fun CinemaBarChart(
    data: List<BarDatum>,
    barColor: Color = CinemaGold,
    modifier: Modifier = Modifier,
) {
    val maxVal = (data.maxOfOrNull { it.value } ?: 0f).coerceAtLeast(1f)
    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            if (data.isEmpty()) return@Canvas
            val count = data.size
            val slotWidth = size.width / count
            val barWidth = (slotWidth * 0.52f).coerceAtMost(36.dp.toPx())
            val chartHeight = size.height - 8.dp.toPx()

            // Subtle horizontal gridlines
            for (step in 0..3) {
                val y = chartHeight * (step / 3f)
                drawLine(
                    color = CinemaBorder.copy(alpha = 0.45f),
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1.dp.toPx(),
                )
            }

            data.forEachIndexed { idx, datum ->
                val ratio = (datum.value / maxVal).coerceIn(0f, 1f)
                val barHeight = (chartHeight * ratio).coerceAtLeast(if (datum.value > 0f) 4.dp.toPx() else 0f)
                val left = idx * slotWidth + (slotWidth - barWidth) / 2f
                val top = chartHeight - barHeight

                // Track background
                drawRoundRect(
                    color = CinemaBorder.copy(alpha = 0.22f),
                    topLeft = Offset(left, 0f),
                    size = Size(barWidth, chartHeight),
                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                )

                if (barHeight > 0f) {
                    drawRoundRect(
                        color = barColor,
                        topLeft = Offset(left, top),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
        ) {
            data.forEach { datum ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = datum.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = CinemaTextSecondary,
                    )
                    Text(
                        text = datum.formattedValue,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (datum.value > 0f) CinemaTextPrimary else CinemaTextMuted,
                    )
                }
            }
        }
    }
}

@Composable
fun HdrDistributionChart(
    countsByFormat: Map<HdrFormat, Int>,
    modifier: Modifier = Modifier,
) {
    val ordered = listOf(
        HdrFormat.HDR10_PLUS to FormatHdr10PlusGold,
        HdrFormat.DOLBY_VISION to FormatDolbyVisionViolet,
        HdrFormat.HDR10 to FormatHdr10Amber,
        HdrFormat.HLG to FormatHlgCyan,
        HdrFormat.SDR to FormatSdrSlate,
        HdrFormat.UNKNOWN to CinemaIce,
    ).filter { (fmt, _) -> (countsByFormat[fmt] ?: 0) > 0 }

    val total = ordered.sumOf { (fmt, _) -> countsByFormat[fmt] ?: 0 }.coerceAtLeast(1)

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Box(
            modifier = Modifier.size(124.dp),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(modifier = Modifier.size(124.dp)) {
                val strokeWidth = 18.dp.toPx()
                val inset = strokeWidth / 2f
                val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
                var startAngle = -90f
                ordered.forEach { (fmt, color) ->
                    val count = countsByFormat[fmt] ?: 0
                    val sweep = (count.toFloat() / total.toFloat()) * 360f
                    if (sweep > 0f) {
                        drawArc(
                            color = color,
                            startAngle = startAngle,
                            sweepAngle = (sweep - 2f).coerceAtLeast(2f),
                            useCenter = false,
                            topLeft = Offset(inset, inset),
                            size = arcSize,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Butt),
                        )
                        startAngle += sweep
                    }
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val hdrCount = ordered.filter { it.first.isHdr }.sumOf { countsByFormat[it.first] ?: 0 }
                val hdrPct = (hdrCount * 100) / total
                Text(
                    text = "$hdrPct%",
                    style = MaterialTheme.typography.titleLarge,
                    color = CinemaTextPrimary,
                )
                Text(
                    text = "HDR",
                    style = MaterialTheme.typography.labelSmall,
                    color = CinemaGold,
                )
            }
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ordered.forEach { (fmt, color) ->
                val count = countsByFormat[fmt] ?: 0
                val pct = (count.toFloat() / total.toFloat()) * 100f
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(color)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = fmt.displayName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = CinemaTextPrimary,
                        )
                    }
                    Text(
                        text = String.format(Locale.US, "%d (%.0f%%)", count, pct),
                        style = MaterialTheme.typography.labelMedium,
                        color = CinemaTextSecondary,
                    )
                }
            }
        }
    }
}
