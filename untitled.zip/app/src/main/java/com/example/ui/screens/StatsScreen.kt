package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.media.Formatters
import com.example.ui.components.BarDatum
import com.example.ui.components.CinemaBarChart
import com.example.ui.components.HdrDistributionChart
import com.example.ui.components.HdrFormatBadge
import com.example.ui.theme.CinemaBorderSubtle
import com.example.ui.theme.CinemaEmerald
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.CinemaIce
import com.example.ui.theme.CinemaObsidian
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceHigh
import com.example.ui.theme.CinemaTextMuted
import com.example.ui.theme.CinemaTextPrimary
import com.example.ui.theme.CinemaTextSecondary
import com.example.viewmodel.CinemaAppViewModel
import java.util.Locale

@Composable
fun StatsScreen(
    viewModel: CinemaAppViewModel,
    onOpenVideoDetail: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val stats by viewModel.statsSummary.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CinemaObsidian)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Spacer(Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.stats_title),
            style = MaterialTheme.typography.headlineMedium,
            color = CinemaTextPrimary,
        )
        Text(
            text = "Computed strictly from your local Room playback database",
            style = MaterialTheme.typography.bodySmall,
            color = CinemaTextSecondary,
        )

        if (stats.totalSessions == 0) {
            Surface(
                color = CinemaSurface,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, CinemaBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 36.dp),
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.BarChart,
                        contentDescription = null,
                        tint = CinemaGold,
                        modifier = Modifier.size(44.dp),
                    )
                    Text(stringResource(R.string.stats_empty_title), style = MaterialTheme.typography.titleLarge)
                    Text(
                        stringResource(R.string.stats_empty_body),
                        style = MaterialTheme.typography.bodyMedium,
                        color = CinemaTextSecondary,
                    )
                }
            }
            return
        }

        // KPI Grid
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("stats_kpi_row_1"),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            StatMetricCard(
                label = "Total Viewing Time",
                value = Formatters.formatHumanDuration(stats.totalViewingMs),
                accent = CinemaGold,
                modifier = Modifier.weight(1f),
            )
            StatMetricCard(
                label = "Films Watched",
                value = "${stats.uniqueVideosWatched}",
                accent = CinemaIce,
                modifier = Modifier.weight(1f),
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            StatMetricCard(
                label = "Viewing Sessions",
                value = "${stats.totalSessions}",
                accent = CinemaTextPrimary,
                modifier = Modifier.weight(1f),
            )
            StatMetricCard(
                label = "Avg. Session",
                value = Formatters.formatHumanDuration(stats.averageSessionMs),
                accent = CinemaEmerald,
                modifier = Modifier.weight(1f),
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            StatMetricCard(
                label = "Completed Finishes",
                value = "${stats.completedSessions}",
                accent = CinemaEmerald,
                modifier = Modifier.weight(1f),
            )
            StatMetricCard(
                label = "Total Rewatches",
                value = "${stats.totalRewatches}",
                accent = CinemaGold,
                modifier = Modifier.weight(1f),
            )
        }

        // Weekly Viewing Bar Chart
        StatsCard(title = "Weekly Viewing Activity (Last 7 Days)") {
            CinemaBarChart(
                data = stats.weeklyPoints.map { pt ->
                    BarDatum(
                        label = pt.label,
                        value = pt.watchedMinutes,
                        formattedValue = "${pt.watchedMinutes.toInt()}m",
                    )
                },
                barColor = CinemaGold,
            )
        }

        // Monthly Viewing Bar Chart
        StatsCard(title = "Monthly Viewing Trend (Last 6 Months)") {
            CinemaBarChart(
                data = stats.monthlyPoints.map { pt ->
                    BarDatum(
                        label = pt.label,
                        value = pt.watchedHours,
                        formattedValue = String.format(Locale.US, "%.1fh", pt.watchedHours),
                    )
                },
                barColor = CinemaIce,
            )
        }

        // HDR vs SDR Distribution
        if (stats.hdrBreakdownCounts.isNotEmpty()) {
            StatsCard(title = "HDR vs SDR Viewing Distribution") {
                HdrDistributionChart(countsByFormat = stats.hdrBreakdownCounts)
            }
        }

        // Most-Watched Films Leaderboard
        if (stats.mostWatched.isNotEmpty()) {
            StatsCard(title = "Most-Watched Films") {
                stats.mostWatched.forEachIndexed { idx, item ->
                    Surface(
                        color = CinemaSurfaceHigh,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenVideoDetail(item.videoId) },
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Text(
                                text = "#${idx + 1}",
                                style = MaterialTheme.typography.titleMedium,
                                color = CinemaGold,
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.filename.substringBeforeLast('.'),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = CinemaTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = "${item.sessionCount} session(s) · ${Formatters.formatHumanDuration(item.totalWatchedMs)}" +
                                        if (item.rewatchCount > 0) " · ${item.rewatchCount} rewatch(es)" else "",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CinemaTextSecondary,
                                )
                            }
                            HdrFormatBadge(format = item.hdrFormat, compact = true)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StatMetricCard(
    label: String,
    value: String,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        color = CinemaSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CinemaBorderSubtle),
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = CinemaTextMuted)
            Text(text = value, style = MaterialTheme.typography.headlineSmall, color = accent)
        }
    }
}

@Composable
private fun StatsCard(
    title: String,
    content: @Composable () -> Unit,
) {
    Surface(
        color = CinemaSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CinemaBorderSubtle),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = CinemaTextPrimary)
            content()
        }
    }
}
