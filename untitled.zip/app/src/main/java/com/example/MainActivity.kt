package com.example

import android.content.Intent
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.ConfigAndVaultScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.ScenesScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.screens.VideoDetailScreen
import com.example.ui.theme.CinemaCharcoal
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.CinemaGoldContainer
import com.example.ui.theme.CinemaObsidian
import com.example.ui.theme.CinemaTextMuted
import com.example.ui.theme.CinemaTextPrimary
import com.example.ui.theme.PersonalCinemaTheme
import com.example.viewmodel.CinemaAppViewModel
import com.example.viewmodel.PlayerViewModel

object Routes {
    const val LIBRARY = "library"
    const val HISTORY = "history"
    const val SCENES = "scenes"
    const val STATS = "stats"
    const val CONFIG = "config"
    const val DETAIL = "detail/{videoId}"
    const val PLAYER = "player/{videoId}?startMs={startMs}"

    fun detail(videoId: String): String = "detail/${Uri.encode(videoId)}"
    fun player(videoId: String, startMs: Long? = null): String {
        val enc = Uri.encode(videoId)
        return if (startMs != null && startMs >= 0L) "player/$enc?startMs=$startMs" else "player/$enc?startMs=-1"
    }
}

private data class TopDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
)

class MainActivity : ComponentActivity() {

    private var incomingExternalVideoUri by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
        )
        handleIncomingIntent(intent)

        setContent {
            PersonalCinemaTheme {
                PersonalCinemaApp(
                    incomingUri = incomingExternalVideoUri,
                    onConsumeIncomingUri = { incomingExternalVideoUri = null },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { uri ->
                incomingExternalVideoUri = uri
            }
        }
    }
}

@Composable
fun PersonalCinemaApp(
    incomingUri: Uri?,
    onConsumeIncomingUri: () -> Unit,
    appViewModel: CinemaAppViewModel = viewModel(),
) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val statusBanner by appViewModel.statusBanner.collectAsStateWithLifecycle()

    LaunchedEffect(statusBanner) {
        statusBanner?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            appViewModel.clearBanner()
        }
    }

    LaunchedEffect(incomingUri) {
        if (incomingUri != null) {
            appViewModel.openSingleVideo(incomingUri) { videoId ->
                onConsumeIncomingUri()
                navController.navigate(Routes.player(videoId, null))
            }
        }
    }

    val destinations = remember {
        listOf(
            TopDestination(Routes.LIBRARY, R.string.nav_library, Icons.Rounded.Movie, Icons.Outlined.Movie),
            TopDestination(Routes.HISTORY, R.string.nav_history, Icons.Rounded.History, Icons.Outlined.History),
            TopDestination(Routes.SCENES, R.string.nav_scenes, Icons.Rounded.Bookmarks, Icons.Outlined.Bookmarks),
            TopDestination(Routes.STATS, R.string.nav_stats, Icons.Rounded.BarChart, Icons.Outlined.BarChart),
            TopDestination(Routes.CONFIG, R.string.nav_config, Icons.Rounded.Tune, Icons.Outlined.Tune),
        )
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showChrome = currentRoute in destinations.map { it.route }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = CinemaObsidian,
            contentColor = CinemaTextPrimary,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = if (currentRoute?.startsWith("player/") == true) {
                WindowInsets(0, 0, 0, 0)
            } else {
                WindowInsets.safeDrawing
            },
            bottomBar = {
                if (showChrome && !useNavigationRail) {
                    NavigationBar(containerColor = CinemaCharcoal) {
                        destinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(dest.route) {
                                        popUpTo(Routes.LIBRARY) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes),
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CinemaGold,
                                    selectedTextColor = CinemaGold,
                                    indicatorColor = CinemaGoldContainer,
                                    unselectedIconColor = CinemaTextMuted,
                                    unselectedTextColor = CinemaTextMuted,
                                ),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (showChrome && useNavigationRail) {
                    NavigationRail(
                        containerColor = CinemaCharcoal,
                        modifier = Modifier.fillMaxHeight(),
                    ) {
                        destinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(dest.route) {
                                        popUpTo(Routes.LIBRARY) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes),
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = CinemaGold,
                                    selectedTextColor = CinemaGold,
                                    indicatorColor = CinemaGoldContainer,
                                    unselectedIconColor = CinemaTextMuted,
                                    unselectedTextColor = CinemaTextMuted,
                                ),
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    NavHost(
                        navController = navController,
                        startDestination = Routes.LIBRARY,
                    ) {
                        composable(Routes.LIBRARY) {
                            LibraryScreen(
                                viewModel = appViewModel,
                                onOpenVideoDetail = { videoId -> navController.navigate(Routes.detail(videoId)) },
                                onPlayVideo = { videoId, startMs -> navController.navigate(Routes.player(videoId, startMs)) },
                            )
                        }

                        composable(Routes.HISTORY) {
                            HistoryScreen(
                                viewModel = appViewModel,
                                onPlayAtTimestamp = { videoId, pos -> navController.navigate(Routes.player(videoId, pos)) },
                                onOpenVideoDetail = { videoId -> navController.navigate(Routes.detail(videoId)) },
                            )
                        }

                        composable(Routes.SCENES) {
                            ScenesScreen(
                                viewModel = appViewModel,
                                onPlayAtTimestamp = { videoId, pos -> navController.navigate(Routes.player(videoId, pos)) },
                            )
                        }

                        composable(Routes.STATS) {
                            StatsScreen(
                                viewModel = appViewModel,
                                onOpenVideoDetail = { videoId -> navController.navigate(Routes.detail(videoId)) },
                            )
                        }

                        composable(Routes.CONFIG) {
                            ConfigAndVaultScreen(viewModel = appViewModel)
                        }

                        composable(
                            route = Routes.DETAIL,
                            arguments = listOf(navArgument("videoId") { type = NavType.StringType }),
                        ) { backStackEntry ->
                            val decodedId = Uri.decode(backStackEntry.arguments?.getString("videoId").orEmpty())
                            VideoDetailScreen(
                                videoId = decodedId,
                                viewModel = appViewModel,
                                onBack = { navController.popBackStack() },
                                onPlay = { vid, startMs -> navController.navigate(Routes.player(vid, startMs)) },
                            )
                        }

                        composable(
                            route = Routes.PLAYER,
                            arguments = listOf(
                                navArgument("videoId") { type = NavType.StringType },
                                navArgument("startMs") {
                                    type = NavType.LongType
                                    defaultValue = -1L
                                },
                            ),
                        ) { backStackEntry ->
                            val decodedId = Uri.decode(backStackEntry.arguments?.getString("videoId").orEmpty())
                            val startArg = backStackEntry.arguments?.getLong("startMs") ?: -1L
                            val playerViewModel: PlayerViewModel = viewModel(backStackEntry)
                            PlayerScreen(
                                videoId = decodedId,
                                startPositionMs = startArg.takeIf { it >= 0L },
                                playerViewModel = playerViewModel,
                                onNavigateBack = { navController.popBackStack() },
                                onOpenMpvConfig = {
                                    navController.navigate(Routes.CONFIG) {
                                        launchSingleTop = true
                                    }
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}
