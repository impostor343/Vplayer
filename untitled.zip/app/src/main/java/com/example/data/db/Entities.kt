package com.example.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "watched_folders")
data class WatchedFolderEntity(
    @PrimaryKey val folderUri: String,
    val displayName: String,
    val includeSubfolders: Boolean = true,
    val addedAtMillis: Long = System.currentTimeMillis(),
    val lastScannedMillis: Long = 0L,
    val videoCount: Int = 0,
)

@Entity(
    tableName = "video_metadata",
    indices = [
        Index(value = ["folderUri"]),
        Index(value = ["filename"]),
        Index(value = ["hdrFormat"]),
    ],
)
data class VideoMetadataEntity(
    @PrimaryKey val videoId: String,
    val filename: String,
    val folderUri: String,
    val relativeSubfolder: String,
    val fileSizeBytes: Long,
    val lastModifiedMillis: Long,
    val durationMs: Long,
    val codedWidth: Int,
    val codedHeight: Int,
    val sarNum: Int,
    val sarDen: Int,
    val rotationDegrees: Int,
    val displayAspectRatioLabel: String,
    val displayAspectRatioName: String,
    val displayAspectRatioValue: Double,
    val videoCodec: String,
    val bitDepth: Int,
    val frameRate: Float,
    val chromaSubsampling: String,
    val colorPrimaries: String,
    val transferCharacteristics: String,
    val hdrFormat: String,
    val hdrEvidence: String,
    val audioCodec: String,
    val audioTracksJson: String,
    val audioTrackCount: Int,
    val subtitleTracksJson: String,
    val subtitleTrackCount: Int,
    val thumbnailPath: String?,
    val lastScannedMillis: Long,
    val lastPositionMs: Long = 0L,
    val lastWatchedAtMillis: Long = 0L,
)

@Entity(
    tableName = "playback_sessions",
    indices = [
        Index(value = ["videoId"]),
        Index(value = ["openedAtMillis"]),
        Index(value = ["terminationState"]),
    ],
)
data class PlaybackSessionEntity(
    @PrimaryKey(autoGenerate = true) val sessionId: Long = 0L,
    val videoId: String,
    val videoFilename: String,
    val videoPath: String,
    val hdrFormatSnapshot: String,
    val sessionDateEpochDay: Long,
    val openedAtMillis: Long,
    val closedAtMillis: Long,
    val startPositionMs: Long,
    val endPositionMs: Long,
    val watchedDurationMs: Long,
    val videoDurationMs: Long,
    val completionPercent: Float,
    val isCompleted: Boolean,
    val terminationState: String,
    val lastCheckpointMillis: Long,
)

@Entity(
    tableName = "personal_reviews",
    indices = [
        Index(value = ["watchedStatus"]),
        Index(value = ["isFavourite"]),
        Index(value = ["rating"]),
    ],
)
data class PersonalReviewEntity(
    @PrimaryKey val videoId: String,
    val rating: Float = 0f, // 0.0 to 5.0 (0 = unrated)
    val writtenReview: String = "",
    val watchedStatus: String = "UNWATCHED",
    val isFavourite: Boolean = false,
    val tagsCsv: String = "",
    val viewingDateMillis: Long = 0L,
    val rewatchCount: Int = 0,
    val notes: String = "",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "timestamp_bookmarks",
    indices = [
        Index(value = ["videoId"]),
        Index(value = ["isFavouriteScene"]),
        Index(value = ["createdAtMillis"]),
    ],
)
data class TimestampBookmarkEntity(
    @PrimaryKey(autoGenerate = true) val bookmarkId: Long = 0L,
    val videoId: String,
    val videoFilename: String,
    val timestampMs: Long,
    val title: String,
    val note: String,
    val isFavouriteScene: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis(),
)

@Entity(tableName = "mpv_profiles")
data class MpvProfileEntity(
    @PrimaryKey val profileId: String,
    val name: String,
    val description: String,
    val mpvConf: String,
    val inputConf: String,
    val isActive: Boolean = false,
    val isBuiltIn: Boolean = false,
    val updatedAtMillis: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "mpv_config_backups",
    indices = [Index(value = ["createdAtMillis"])],
)
data class MpvConfigBackupEntity(
    @PrimaryKey(autoGenerate = true) val backupId: Long = 0L,
    val reason: String,
    val mpvConf: String,
    val inputConf: String,
    val createdAtMillis: Long = System.currentTimeMillis(),
)
