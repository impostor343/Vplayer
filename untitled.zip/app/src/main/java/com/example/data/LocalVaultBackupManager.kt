package com.example.data

import android.content.Context
import android.net.Uri
import com.example.data.db.AppDatabase
import com.example.data.db.MpvConfigBackupEntity
import com.example.data.db.MpvProfileEntity
import com.example.data.db.PersonalReviewEntity
import com.example.data.db.PlaybackSessionEntity
import com.example.data.db.TimestampBookmarkEntity
import com.example.data.db.VideoMetadataEntity
import com.example.data.db.WatchedFolderEntity
import com.example.media.MpvConfigManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Local-only JSON vault backup & restore manager.
 * Operates strictly via Android Storage Access Framework — zero network or cloud access.
 */
class LocalVaultBackupManager(
    private val context: Context,
    private val db: AppDatabase,
    private val mpvConfigManager: MpvConfigManager,
) {
    data class ImportSummary(
        val foldersImported: Int,
        val videosImported: Int,
        val sessionsImported: Int,
        val reviewsImported: Int,
        val bookmarksImported: Int,
        val profilesImported: Int,
        val configRestored: Boolean,
    )

    suspend fun exportToJsonString(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("schemaVersion", BACKUP_SCHEMA_VERSION)
        root.put("app", "Personal Cinema")
        root.put("exportedAtMillis", System.currentTimeMillis())

        val folders = JSONArray()
        db.folderDao().getAllFolders().forEach { f ->
            folders.put(
                JSONObject().apply {
                    put("folderUri", f.folderUri)
                    put("displayName", f.displayName)
                    put("includeSubfolders", f.includeSubfolders)
                    put("addedAtMillis", f.addedAtMillis)
                    put("lastScannedMillis", f.lastScannedMillis)
                    put("videoCount", f.videoCount)
                }
            )
        }
        root.put("folders", folders)

        val videos = JSONArray()
        db.videoMetadataDao().getAllVideos().forEach { v ->
            videos.put(
                JSONObject().apply {
                    put("videoId", v.videoId)
                    put("filename", v.filename)
                    put("folderUri", v.folderUri)
                    put("relativeSubfolder", v.relativeSubfolder)
                    put("fileSizeBytes", v.fileSizeBytes)
                    put("lastModifiedMillis", v.lastModifiedMillis)
                    put("durationMs", v.durationMs)
                    put("codedWidth", v.codedWidth)
                    put("codedHeight", v.codedHeight)
                    put("sarNum", v.sarNum)
                    put("sarDen", v.sarDen)
                    put("rotationDegrees", v.rotationDegrees)
                    put("displayAspectRatioLabel", v.displayAspectRatioLabel)
                    put("displayAspectRatioName", v.displayAspectRatioName)
                    put("displayAspectRatioValue", v.displayAspectRatioValue)
                    put("videoCodec", v.videoCodec)
                    put("bitDepth", v.bitDepth)
                    put("frameRate", v.frameRate.toDouble())
                    put("chromaSubsampling", v.chromaSubsampling)
                    put("colorPrimaries", v.colorPrimaries)
                    put("transferCharacteristics", v.transferCharacteristics)
                    put("hdrFormat", v.hdrFormat)
                    put("hdrEvidence", v.hdrEvidence)
                    put("audioCodec", v.audioCodec)
                    put("audioTracksJson", v.audioTracksJson)
                    put("audioTrackCount", v.audioTrackCount)
                    put("subtitleTracksJson", v.subtitleTracksJson)
                    put("subtitleTrackCount", v.subtitleTrackCount)
                    put("lastScannedMillis", v.lastScannedMillis)
                    put("lastPositionMs", v.lastPositionMs)
                    put("lastWatchedAtMillis", v.lastWatchedAtMillis)
                }
            )
        }
        root.put("videos", videos)

        val sessions = JSONArray()
        db.playbackSessionDao().getAllSessions().forEach { s ->
            sessions.put(
                JSONObject().apply {
                    put("videoId", s.videoId)
                    put("videoFilename", s.videoFilename)
                    put("videoPath", s.videoPath)
                    put("hdrFormatSnapshot", s.hdrFormatSnapshot)
                    put("sessionDateEpochDay", s.sessionDateEpochDay)
                    put("openedAtMillis", s.openedAtMillis)
                    put("closedAtMillis", s.closedAtMillis)
                    put("startPositionMs", s.startPositionMs)
                    put("endPositionMs", s.endPositionMs)
                    put("watchedDurationMs", s.watchedDurationMs)
                    put("videoDurationMs", s.videoDurationMs)
                    put("completionPercent", s.completionPercent.toDouble())
                    put("isCompleted", s.isCompleted)
                    put("terminationState", s.terminationState)
                    put("lastCheckpointMillis", s.lastCheckpointMillis)
                }
            )
        }
        root.put("sessions", sessions)

        val reviews = JSONArray()
        db.personalReviewDao().getAllReviews().forEach { r ->
            reviews.put(
                JSONObject().apply {
                    put("videoId", r.videoId)
                    put("rating", r.rating.toDouble())
                    put("writtenReview", r.writtenReview)
                    put("watchedStatus", r.watchedStatus)
                    put("isFavourite", r.isFavourite)
                    put("tagsCsv", r.tagsCsv)
                    put("viewingDateMillis", r.viewingDateMillis)
                    put("rewatchCount", r.rewatchCount)
                    put("notes", r.notes)
                    put("createdAtMillis", r.createdAtMillis)
                    put("updatedAtMillis", r.updatedAtMillis)
                }
            )
        }
        root.put("reviews", reviews)

        val bookmarks = JSONArray()
        db.timestampBookmarkDao().getAllBookmarks().forEach { b ->
            bookmarks.put(
                JSONObject().apply {
                    put("videoId", b.videoId)
                    put("videoFilename", b.videoFilename)
                    put("timestampMs", b.timestampMs)
                    put("title", b.title)
                    put("note", b.note)
                    put("isFavouriteScene", b.isFavouriteScene)
                    put("createdAtMillis", b.createdAtMillis)
                }
            )
        }
        root.put("bookmarks", bookmarks)

        val profiles = JSONArray()
        db.mpvConfigDao().getAllProfiles().forEach { p ->
            profiles.put(
                JSONObject().apply {
                    put("profileId", p.profileId)
                    put("name", p.name)
                    put("description", p.description)
                    put("mpvConf", p.mpvConf)
                    put("inputConf", p.inputConf)
                    put("isActive", p.isActive)
                    put("isBuiltIn", p.isBuiltIn)
                    put("updatedAtMillis", p.updatedAtMillis)
                }
            )
        }
        root.put("mpvProfiles", profiles)

        root.put(
            "activeConfig",
            JSONObject().apply {
                put("mpvConf", mpvConfigManager.readMpvConf())
                put("inputConf", mpvConfigManager.readInputConf())
            },
        )

        root.toString(2)
    }

    suspend fun exportToUri(uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = exportToJsonString()
            context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use {
                it.write(payload)
            } ?: error("Unable to open destination file for vault export")
        }
    }

    suspend fun importFromUri(uri: Uri): Result<ImportSummary> = withContext(Dispatchers.IO) {
        runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use {
                it.readText()
            } ?: error("Unable to read selected backup file")
            importFromJsonString(raw)
        }
    }

    suspend fun importFromJsonString(rawJson: String): ImportSummary = withContext(Dispatchers.IO) {
        val root = JSONObject(rawJson)
        val version = root.optInt("schemaVersion", -1)
        require(version in 1..BACKUP_SCHEMA_VERSION) {
            "Unsupported Personal Cinema backup schema version: $version"
        }

        // Back up existing mpv config before touching anything
        db.mpvConfigDao().insertBackup(
            MpvConfigBackupEntity(
                reason = "Pre-vault-import safety backup",
                mpvConf = mpvConfigManager.readMpvConf(),
                inputConf = mpvConfigManager.readInputConf(),
            )
        )

        var foldersCount = 0
        root.optJSONArray("folders")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                db.folderDao().upsertFolder(
                    WatchedFolderEntity(
                        folderUri = o.getString("folderUri"),
                        displayName = o.optString("displayName", "Folder"),
                        includeSubfolders = o.optBoolean("includeSubfolders", true),
                        addedAtMillis = o.optLong("addedAtMillis", System.currentTimeMillis()),
                        lastScannedMillis = o.optLong("lastScannedMillis", 0L),
                        videoCount = o.optInt("videoCount", 0),
                    )
                )
                foldersCount++
            }
        }

        var videosCount = 0
        root.optJSONArray("videos")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                db.videoMetadataDao().upsertVideo(
                    VideoMetadataEntity(
                        videoId = o.getString("videoId"),
                        filename = o.optString("filename", "Video"),
                        folderUri = o.optString("folderUri", ""),
                        relativeSubfolder = o.optString("relativeSubfolder", ""),
                        fileSizeBytes = o.optLong("fileSizeBytes", 0L),
                        lastModifiedMillis = o.optLong("lastModifiedMillis", 0L),
                        durationMs = o.optLong("durationMs", 0L),
                        codedWidth = o.optInt("codedWidth", 0),
                        codedHeight = o.optInt("codedHeight", 0),
                        sarNum = o.optInt("sarNum", 1),
                        sarDen = o.optInt("sarDen", 1),
                        rotationDegrees = o.optInt("rotationDegrees", 0),
                        displayAspectRatioLabel = o.optString("displayAspectRatioLabel", "Unknown"),
                        displayAspectRatioName = o.optString("displayAspectRatioName", "Unknown"),
                        displayAspectRatioValue = o.optDouble("displayAspectRatioValue", 0.0),
                        videoCodec = o.optString("videoCodec", "Unknown"),
                        bitDepth = o.optInt("bitDepth", 0),
                        frameRate = o.optDouble("frameRate", 0.0).toFloat(),
                        chromaSubsampling = o.optString("chromaSubsampling", "Unknown"),
                        colorPrimaries = o.optString("colorPrimaries", "Unknown"),
                        transferCharacteristics = o.optString("transferCharacteristics", "Unknown"),
                        hdrFormat = o.optString("hdrFormat", "SDR"),
                        hdrEvidence = o.optString("hdrEvidence", ""),
                        audioCodec = o.optString("audioCodec", "Unknown"),
                        audioTracksJson = o.optString("audioTracksJson", "[]"),
                        audioTrackCount = o.optInt("audioTrackCount", 0),
                        subtitleTracksJson = o.optString("subtitleTracksJson", "[]"),
                        subtitleTrackCount = o.optInt("subtitleTrackCount", 0),
                        thumbnailPath = null,
                        lastScannedMillis = o.optLong("lastScannedMillis", System.currentTimeMillis()),
                        lastPositionMs = o.optLong("lastPositionMs", 0L),
                        lastWatchedAtMillis = o.optLong("lastWatchedAtMillis", 0L),
                    )
                )
                videosCount++
            }
        }

        // Deduplicate sessions by (videoId + openedAtMillis) on merge
        val existingSessionKeys = db.playbackSessionDao().getAllSessions()
            .map { "${it.videoId}|${it.openedAtMillis}" }
            .toHashSet()
        var sessionsCount = 0
        root.optJSONArray("sessions")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val vid = o.getString("videoId")
                val opened = o.optLong("openedAtMillis", 0L)
                if (existingSessionKeys.add("$vid|$opened")) {
                    db.playbackSessionDao().insertSession(
                        PlaybackSessionEntity(
                            videoId = vid,
                            videoFilename = o.optString("videoFilename", "Video"),
                            videoPath = o.optString("videoPath", ""),
                            hdrFormatSnapshot = o.optString("hdrFormatSnapshot", "SDR"),
                            sessionDateEpochDay = o.optLong("sessionDateEpochDay", 0L),
                            openedAtMillis = opened,
                            closedAtMillis = o.optLong("closedAtMillis", opened),
                            startPositionMs = o.optLong("startPositionMs", 0L),
                            endPositionMs = o.optLong("endPositionMs", 0L),
                            watchedDurationMs = o.optLong("watchedDurationMs", 0L),
                            videoDurationMs = o.optLong("videoDurationMs", 0L),
                            completionPercent = o.optDouble("completionPercent", 0.0).toFloat(),
                            isCompleted = o.optBoolean("isCompleted", false),
                            terminationState = o.optString("terminationState", "NORMAL"),
                            lastCheckpointMillis = o.optLong("lastCheckpointMillis", opened),
                        )
                    )
                    sessionsCount++
                }
            }
        }

        var reviewsCount = 0
        root.optJSONArray("reviews")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                db.personalReviewDao().upsertReview(
                    PersonalReviewEntity(
                        videoId = o.getString("videoId"),
                        rating = o.optDouble("rating", 0.0).toFloat(),
                        writtenReview = o.optString("writtenReview", ""),
                        watchedStatus = o.optString("watchedStatus", "UNWATCHED"),
                        isFavourite = o.optBoolean("isFavourite", false),
                        tagsCsv = o.optString("tagsCsv", ""),
                        viewingDateMillis = o.optLong("viewingDateMillis", 0L),
                        rewatchCount = o.optInt("rewatchCount", 0),
                        notes = o.optString("notes", ""),
                        createdAtMillis = o.optLong("createdAtMillis", System.currentTimeMillis()),
                        updatedAtMillis = o.optLong("updatedAtMillis", System.currentTimeMillis()),
                    )
                )
                reviewsCount++
            }
        }

        val existingBookmarkKeys = db.timestampBookmarkDao().getAllBookmarks()
            .map { "${it.videoId}|${it.timestampMs}|${it.createdAtMillis}" }
            .toHashSet()
        var bookmarksCount = 0
        root.optJSONArray("bookmarks")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val vid = o.getString("videoId")
                val ts = o.optLong("timestampMs", 0L)
                val created = o.optLong("createdAtMillis", System.currentTimeMillis())
                if (existingBookmarkKeys.add("$vid|$ts|$created")) {
                    db.timestampBookmarkDao().insertBookmark(
                        TimestampBookmarkEntity(
                            videoId = vid,
                            videoFilename = o.optString("videoFilename", "Video"),
                            timestampMs = ts,
                            title = o.optString("title", ""),
                            note = o.optString("note", ""),
                            isFavouriteScene = o.optBoolean("isFavouriteScene", false),
                            createdAtMillis = created,
                        )
                    )
                    bookmarksCount++
                }
            }
        }

        var profilesCount = 0
        root.optJSONArray("mpvProfiles")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                db.mpvConfigDao().upsertProfile(
                    MpvProfileEntity(
                        profileId = o.getString("profileId"),
                        name = o.optString("name", "Imported Profile"),
                        description = o.optString("description", ""),
                        mpvConf = o.optString("mpvConf", MpvConfigManager.DEFAULT_HDR_MPV_CONF),
                        inputConf = o.optString("inputConf", MpvConfigManager.DEFAULT_INPUT_CONF),
                        isActive = o.optBoolean("isActive", false),
                        isBuiltIn = o.optBoolean("isBuiltIn", false),
                        updatedAtMillis = o.optLong("updatedAtMillis", System.currentTimeMillis()),
                    )
                )
                profilesCount++
            }
        }

        var configRestored = false
        root.optJSONObject("activeConfig")?.let { cfg ->
            val mpv = cfg.optString("mpvConf", "")
            val inp = cfg.optString("inputConf", "")
            if (mpv.isNotBlank() || inp.isNotBlank()) {
                mpvConfigManager.writeConfigs(
                    mpvConf = mpv.ifBlank { MpvConfigManager.DEFAULT_HDR_MPV_CONF },
                    inputConf = inp.ifBlank { MpvConfigManager.DEFAULT_INPUT_CONF },
                )
                configRestored = true
            }
        }

        ImportSummary(
            foldersImported = foldersCount,
            videosImported = videosCount,
            sessionsImported = sessionsCount,
            reviewsImported = reviewsCount,
            bookmarksImported = bookmarksCount,
            profilesImported = profilesCount,
            configRestored = configRestored,
        )
    }

    companion object {
        const val BACKUP_SCHEMA_VERSION = 1
    }
}
