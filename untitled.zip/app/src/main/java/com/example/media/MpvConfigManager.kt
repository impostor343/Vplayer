package com.example.media

import android.content.Context
import android.net.Uri
import com.example.domain.ConfigValidationIssue
import com.example.domain.ConfigValidationResult
import java.io.File
import java.util.Locale

/**
 * Manages local mpv.conf and input.conf files in app-private storage, validates syntax
 * and offline-safety rules, and ships HDR-preserving built-in configuration profiles.
 */
class MpvConfigManager(private val context: Context) {

    val configDir: File by lazy {
        File(context.filesDir, "mpv_config").apply { mkdirs() }
    }

    val mpvConfFile: File get() = File(configDir, "mpv.conf")
    val inputConfFile: File get() = File(configDir, "input.conf")

    fun ensureInitialized() {
        if (!mpvConfFile.exists()) {
            mpvConfFile.writeText(DEFAULT_HDR_MPV_CONF)
        }
        if (!inputConfFile.exists()) {
            inputConfFile.writeText(DEFAULT_INPUT_CONF)
        }
    }

    fun readMpvConf(): String {
        ensureInitialized()
        return runCatching { mpvConfFile.readText() }.getOrDefault(DEFAULT_HDR_MPV_CONF)
    }

    fun readInputConf(): String {
        ensureInitialized()
        return runCatching { inputConfFile.readText() }.getOrDefault(DEFAULT_INPUT_CONF)
    }

    fun writeConfigs(mpvConf: String, inputConf: String) {
        configDir.mkdirs()
        mpvConfFile.writeText(mpvConf)
        inputConfFile.writeText(inputConf)
    }

    fun readTextFromUri(uri: Uri): Result<String> = runCatching {
        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            ?: error("Unable to open selected configuration file")
    }

    fun writeTextToUri(uri: Uri, content: String): Result<Unit> = runCatching {
        context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(content) }
            ?: error("Unable to write to destination file")
    }

    companion object {
        val DEFAULT_HDR_MPV_CONF = """
            # Personal Cinema — HDR Reference Profile (Offline)
            # Uses libplacebo (gpu-next) + MediaCodec hardware decoding for HDR10, HDR10+, HLG & Dolby Vision.
            vo=gpu-next
            gpu-context=android
            gpu-api=opengl
            hwdec=mediacodec-copy
            hwdec-codecs=all
            target-colorspace-hint=yes
            tone-mapping=bt.2446a
            hdr-compute-peak=yes

            # Audio & Subtitles (Local Only)
            ao=audiotrack,opensles
            sub-auto=fuzzy
            sub-font-size=44
            sub-border-size=2.5
            sub-shadow-offset=1

            # Strict Offline Hardening
            ytdl=no
            load-scripts=no
            cache=yes
            demuxer-max-bytes=64MiB
            demuxer-max-back-bytes=32MiB
            keep-open=yes
        """.trimIndent()

        val CLASSIC_GPU_MPV_CONF = """
            # Personal Cinema — Classic GPU Compatibility Profile (Offline)
            # Fallback for older Android GPUs that prefer vo=gpu over vo=gpu-next.
            vo=gpu
            gpu-context=android
            hwdec=mediacodec-copy
            hwdec-codecs=all
            target-colorspace-hint=yes
            tone-mapping=bt.2446a
            hdr-compute-peak=yes
            ao=audiotrack,opensles
            sub-auto=fuzzy
            ytdl=no
            load-scripts=no
            keep-open=yes
        """.trimIndent()

        val BATTERY_HWDEC_MPV_CONF = """
            # Personal Cinema — Hardware Low-Power Profile
            vo=gpu
            gpu-context=android
            hwdec=mediacodec
            hwdec-codecs=all
            target-colorspace-hint=yes
            scale=bilinear
            cscale=bilinear
            dscale=bilinear
            ao=audiotrack,opensles
            ytdl=no
            load-scripts=no
            keep-open=yes
        """.trimIndent()

        val CINEMA_HQ_MPV_CONF = """
            # Personal Cinema — High-Quality Cinema Upscaling Profile
            vo=gpu-next
            gpu-context=android
            gpu-api=opengl
            hwdec=mediacodec-copy
            hwdec-codecs=all
            target-colorspace-hint=yes
            tone-mapping=spline
            hdr-compute-peak=yes
            scale=ewa_lanczossharp
            cscale=ewa_lanczossharp
            dscale=mitchell
            deband=yes
            deband-iterations=2
            ao=audiotrack,opensles
            ytdl=no
            load-scripts=no
            keep-open=yes
        """.trimIndent()

        val DEFAULT_INPUT_CONF = """
            # Personal Cinema — Local Key Bindings (input.conf)
            SPACE cycle pause
            LEFT seek -10
            RIGHT seek 10
            UP add volume 5
            DOWN add volume -5
            [ multiply speed 1/1.1
            ] multiply speed 1.1
            BS set speed 1.0
            v cycle sub-visibility
            j cycle sub
            SHARP cycle audio
            PGUP add chapter 1
            PGDWN add chapter -1
            i script-binding stats/display-stats-toggle
        """.trimIndent()

        /**
         * Parses the top-level `vo=...` setting from mpv.conf (ignoring comments and conditional
         * profile sections) so the Android SurfaceHolder lifecycle restores the user's chosen
         * video output driver (e.g. `gpu-next` or `gpu`) instead of overriding it.
         */
        fun extractConfiguredVo(mpvConf: String): String {
            var inProfileSection = false
            var configuredVo: String? = null
            for (rawLine in mpvConf.lines()) {
                val line = rawLine.trim()
                if (line.isEmpty() || line.startsWith("#")) continue
                if (line.startsWith("[") && line.endsWith("]")) {
                    inProfileSection = true
                    continue
                }
                if (inProfileSection) continue
                val effective = line.split(" #", "\t#", limit = 2).first().trim()
                val eqIndex = effective.indexOf('=')
                if (eqIndex <= 0) continue
                val key = effective.substring(0, eqIndex).trim().lowercase(Locale.US)
                if (key == "vo") {
                    val value = effective.substring(eqIndex + 1).trim()
                    if (value.isNotEmpty() && !value.equals("null", ignoreCase = true)) {
                        configuredVo = value
                    }
                }
            }
            return configuredVo ?: "gpu-next"
        }

        private val networkOptionKeys = setOf(
            "ytdl",
            "ytdl-format",
            "ytdl-raw-options",
            "http-proxy",
            "cookies",
            "user-agent",
            "stream-lavf-o",
        )

        /**
         * Validates mpv.conf lines for syntax correctness, duplicate keys within a section,
         * HDR/hardware playback caveats, and strict offline compliance.
         */
        fun validateMpvConf(content: String): ConfigValidationResult {
            val issues = mutableListOf<ConfigValidationIssue>()
            val seenKeysInSection = mutableMapOf<String, Int>()
            var currentSection = "global"

            content.lines().forEachIndexed { idx, rawLine ->
                val lineNo = idx + 1
                val line = rawLine.trim()
                if (line.isEmpty() || line.startsWith("#")) return@forEachIndexed

                if (line.startsWith("[")) {
                    if (!line.endsWith("]") || line.length < 3) {
                        issues += ConfigValidationIssue(
                            lineNumber = lineNo,
                            severity = ConfigValidationIssue.Severity.ERROR,
                            message = "Malformed profile header '$line' (expected [profile-name]).",
                        )
                    } else {
                        currentSection = line.substring(1, line.length - 1).trim()
                        seenKeysInSection.clear()
                    }
                    return@forEachIndexed
                }

                // Strip inline comment if preceded by whitespace
                val effective = line.split(" #", "\t#", limit = 2).first().trim()
                val eqIndex = effective.indexOf('=')

                if (eqIndex == -1) {
                    // Boolean flag syntax like "no-border" or "keep-open" is valid if single token
                    if (effective.any { it.isWhitespace() }) {
                        issues += ConfigValidationIssue(
                            lineNumber = lineNo,
                            severity = ConfigValidationIssue.Severity.ERROR,
                            message = "Invalid option syntax '$effective'. Use key=value.",
                        )
                    }
                    return@forEachIndexed
                }

                val key = effective.substring(0, eqIndex).trim().lowercase(Locale.US)
                val value = effective.substring(eqIndex + 1).trim()

                if (key.isEmpty() || !key.matches(Regex("^[a-z0-9._-]+$"))) {
                    issues += ConfigValidationIssue(
                        lineNumber = lineNo,
                        severity = ConfigValidationIssue.Severity.ERROR,
                        message = "Invalid option key '$key'.",
                    )
                    return@forEachIndexed
                }

                if (value.isEmpty()) {
                    issues += ConfigValidationIssue(
                        lineNumber = lineNo,
                        severity = ConfigValidationIssue.Severity.WARNING,
                        message = "Option '$key' has an empty value.",
                    )
                }

                seenKeysInSection[key]?.let { prevLine ->
                    issues += ConfigValidationIssue(
                        lineNumber = lineNo,
                        severity = ConfigValidationIssue.Severity.WARNING,
                        message = "Duplicate option '$key' in [$currentSection] (previously set on line $prevLine).",
                    )
                }
                seenKeysInSection[key] = lineNo

                if (key == "vo" && value.equals("null", ignoreCase = true)) {
                    issues += ConfigValidationIssue(
                        lineNumber = lineNo,
                        severity = ConfigValidationIssue.Severity.WARNING,
                        message = "vo=null disables video output completely.",
                    )
                }
                if (key == "hwdec" && value.equals("no", ignoreCase = true)) {
                    issues += ConfigValidationIssue(
                        lineNumber = lineNo,
                        severity = ConfigValidationIssue.Severity.INFO,
                        message = "hwdec=no forces software decoding; 4K HDR playback may drop frames.",
                    )
                }
                if (key in networkOptionKeys && !value.equals("no", ignoreCase = true)) {
                    issues += ConfigValidationIssue(
                        lineNumber = lineNo,
                        severity = ConfigValidationIssue.Severity.WARNING,
                        message = "Network option '$key=$value' has no effect because Personal Cinema runs strictly offline without INTERNET permission.",
                    )
                }
            }

            val hasErrors = issues.any { it.severity == ConfigValidationIssue.Severity.ERROR }
            return ConfigValidationResult(isValid = !hasErrors, issues = issues)
        }

        fun validateInputConf(content: String): ConfigValidationResult {
            val issues = mutableListOf<ConfigValidationIssue>()
            content.lines().forEachIndexed { idx, rawLine ->
                val lineNo = idx + 1
                val line = rawLine.trim()
                if (line.isEmpty() || line.startsWith("#")) return@forEachIndexed
                val tokens = line.split(Regex("\\s+"), limit = 2)
                if (tokens.size < 2 || tokens[1].isBlank()) {
                    issues += ConfigValidationIssue(
                        lineNumber = lineNo,
                        severity = ConfigValidationIssue.Severity.ERROR,
                        message = "Key binding '$line' is missing an mpv command.",
                    )
                }
            }
            return ConfigValidationResult(
                isValid = issues.none { it.severity == ConfigValidationIssue.Severity.ERROR },
                issues = issues,
            )
        }
    }
}
