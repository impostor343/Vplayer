package com.example.ui.components

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import com.example.ui.theme.CinemaTextPrimary
import com.example.ui.theme.SyntaxComment
import com.example.ui.theme.SyntaxEquals
import com.example.ui.theme.SyntaxKey
import com.example.ui.theme.SyntaxProfile
import com.example.ui.theme.SyntaxValue

/**
 * Syntax highlighting VisualTransformation for mpv.conf and input.conf editors.
 */
class MpvConfigSyntaxTransformation(
    private val isInputConf: Boolean = false,
) : VisualTransformation {

    override fun filter(text: AnnotatedString): TransformedText {
        val highlighted = buildAnnotatedString {
            val raw = text.text
            var cursor = 0
            val lines = raw.split("\n")
            lines.forEachIndexed { lineIdx, line ->
                val trimmed = line.trimStart()
                val leadingSpaces = line.length - trimmed.length
                if (leadingSpaces > 0) {
                    append(line.substring(0, leadingSpaces))
                }
                when {
                    trimmed.isEmpty() -> Unit
                    trimmed.startsWith("#") -> {
                        pushStyle(SpanStyle(color = SyntaxComment))
                        append(trimmed)
                        pop()
                    }
                    !isInputConf && trimmed.startsWith("[") && trimmed.endsWith("]") -> {
                        pushStyle(SpanStyle(color = SyntaxProfile, fontWeight = FontWeight.Bold))
                        append(trimmed)
                        pop()
                    }
                    !isInputConf -> {
                        val eqIdx = trimmed.indexOf('=')
                        if (eqIdx > 0) {
                            pushStyle(SpanStyle(color = SyntaxKey))
                            append(trimmed.substring(0, eqIdx))
                            pop()
                            pushStyle(SpanStyle(color = SyntaxEquals, fontWeight = FontWeight.Bold))
                            append("=")
                            pop()
                            val rest = trimmed.substring(eqIdx + 1)
                            val commentIdx = rest.indexOf(" #")
                            if (commentIdx >= 0) {
                                pushStyle(SpanStyle(color = SyntaxValue))
                                append(rest.substring(0, commentIdx))
                                pop()
                                pushStyle(SpanStyle(color = SyntaxComment))
                                append(rest.substring(commentIdx))
                                pop()
                            } else {
                                pushStyle(SpanStyle(color = SyntaxValue))
                                append(rest)
                                pop()
                            }
                        } else {
                            pushStyle(SpanStyle(color = SyntaxKey))
                            append(trimmed)
                            pop()
                        }
                    }
                    else -> {
                        // input.conf: KEY command args
                        val firstSpace = trimmed.indexOfFirst { it.isWhitespace() }
                        if (firstSpace > 0) {
                            pushStyle(SpanStyle(color = SyntaxProfile, fontWeight = FontWeight.Bold))
                            append(trimmed.substring(0, firstSpace))
                            pop()
                            val rest = trimmed.substring(firstSpace)
                            pushStyle(SpanStyle(color = SyntaxValue))
                            append(rest)
                            pop()
                        } else {
                            pushStyle(SpanStyle(color = CinemaTextPrimary))
                            append(trimmed)
                            pop()
                        }
                    }
                }
                if (lineIdx < lines.lastIndex) {
                    append("\n")
                }
                cursor += line.length + 1
            }
        }
        return TransformedText(highlighted, OffsetMapping.Identity)
    }
}
