package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.db.PersonalReviewEntity
import com.example.domain.HdrFormat
import com.example.domain.SessionTerminationState
import com.example.domain.WatchedStatus
import com.example.media.Formatters
import com.example.media.HdrInspector
import com.example.ui.components.AspectRatioBadge
import com.example.ui.components.HdrFormatBadge
import com.example.ui.components.LocalThumbnailImage
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaBorderSubtle
import com.example.ui.theme.CinemaCharcoal
import com.example.ui.theme.CinemaEmerald
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.CinemaIce
import com.example.ui.theme.CinemaObsidian
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceHigh
import com.example.ui.theme.CinemaTextMuted
import com.example.ui.theme.CinemaTextPrimary
import com.example.ui.theme.CinemaTextSecondary
import com.example.viewmodel.CinemaAppViewModel
import org.json.JSONArray
import java.util.Locale

@Composable
fun VideoDetailScreen(
    videoId: String,
    viewModel: CinemaAppViewModel,
    onBack: () -> Unit,
    onPlay: (String, Long?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val videoFlow = remember(videoId) { viewModel.repository.observeVideo(videoId) }
    val reviewFlow = remember(videoId) { viewModel.repository.observeReview(videoId) }
    val bookmarksFlow = remember(videoId) { viewModel.repository.observeBookmarksForVideo(videoId) }
    val sessionsFlow = remember(videoId) { viewModel.repository.observeSessionsForVideo(videoId) }

    val video by videoFlow.collectAsStateWithLifecycle(initialValue = null)
    val review by reviewFlow.collectAsStateWithLifecycle(initialValue = null)
    val bookmarks by bookmarksFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    val sessions by sessionsFlow.collectAsStateWithLifecycle(initialValue = emptyList())

    // Editable review form state synced cleanly with Room
    var rating by remember(videoId) { mutableFloatStateOf(0f) }
    var watchedStatus by remember(videoId) { mutableStateOf(WatchedStatus.UNWATCHED) }
    var isFavourite by remember(videoId) { mutableStateOf(false) }
    var writtenReview by remember(videoId) { mutableStateOf("") }
    var tagsCsv by remember(videoId) { mutableStateOf("") }
    var rewatchCount by remember(videoId) { mutableIntStateOf(0) }
    var notes by remember(videoId) { mutableStateOf("") }
    var reviewInitialized by remember(videoId) { mutableStateOf(false) }

    LaunchedEffect(review) {
        if (review != null && !reviewInitialized) {
            rating = review!!.rating
            watchedStatus = WatchedStatus.fromStored(review!!.watchedStatus)
            isFavourite = review!!.isFavourite
            writtenReview = review!!.writtenReview
            tagsCsv = review!!.tagsCsv
            rewatchCount = review!!.rewatchCount
            notes = review!!.notes
            reviewInitialized = true
        }
    }

    var showAddBookmarkDialog by remember { mutableStateOf(false) }

    val meta = video
    if (meta == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(CinemaObsidian),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Loading film metadata…", color = CinemaTextSecondary)
                TextButton(onClick = onBack) { Text("Return to Library", color = CinemaGold) }
            }
        }
        return
    }

    val hdrFormat = HdrFormat.fromStored(meta.hdrFormat)
    val hdrReport = remember(meta, viewModel.displayHdrCapabilities) {
        HdrInspector.buildPipelineReport(
            sourceFormat = hdrFormat,
            sourceEvidence = meta.hdrEvidence,
            liveStats = null,
            displayCaps = viewModel.displayHdrCapabilities,
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CinemaObsidian)
            .verticalScroll(rememberScrollState()),
    ) {
        // Hero Thumbnail Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f),
        ) {
            LocalThumbnailImage(
                thumbnailPath = meta.thumbnailPath,
                modifier = Modifier.fillMaxSize(),
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.65f),
                                Color.Transparent,
                                CinemaObsidian,
                            )
                        )
                    )
            )

            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
                    .testTag("detail_back_button"),
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = stringResource(R.string.cd_back),
                    tint = CinemaTextPrimary,
                )
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    HdrFormatBadge(format = hdrFormat)
                    AspectRatioBadge(darLabel = "${meta.displayAspectRatioLabel} · ${meta.displayAspectRatioName}")
                }
                Text(
                    text = meta.filename.substringBeforeLast('.'),
                    style = MaterialTheme.typography.headlineSmall,
                    color = CinemaTextPrimary,
                )
                Text(
                    text = "${Formatters.formatDurationMs(meta.durationMs)} · ${Formatters.formatFileSize(meta.fileSizeBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CinemaTextSecondary,
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Play / Resume Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Button(
                    onClick = { onPlay(meta.videoId, null) },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("detail_play_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (meta.lastPositionMs > 2_000L) {
                            "Resume (${Formatters.formatDurationMs(meta.lastPositionMs)})"
                        } else {
                            stringResource(R.string.detail_play_now)
                        }
                    )
                }
                if (meta.lastPositionMs > 2_000L) {
                    OutlinedButton(
                        onClick = { onPlay(meta.videoId, 0L) },
                        modifier = Modifier.height(50.dp),
                        border = BorderStroke(1.dp, CinemaBorder),
                        shape = RoundedCornerShape(12.dp),
                    ) {
                        Icon(Icons.Rounded.Replay, contentDescription = "Restart from beginning", tint = CinemaTextPrimary)
                    }
                }
            }

            // 1. Complete 14-Field Technical Specification Matrix
            SectionCard(title = stringResource(R.string.detail_tech_specs)) {
                TechSpecRow("Resolution", Formatters.formatResolutionLabel(meta.codedWidth, meta.codedHeight))
                TechSpecRow(
                    "Display Aspect Ratio",
                    "${meta.displayAspectRatioLabel} (${meta.displayAspectRatioName}) · SAR ${meta.sarNum}:${meta.sarDen}",
                )
                TechSpecRow("Video Codec", meta.videoCodec)
                TechSpecRow("Bit Depth", if (meta.bitDepth > 0) "${meta.bitDepth}-bit" else "Unknown")
                TechSpecRow("Frame Rate", Formatters.formatFrameRate(meta.frameRate))
                TechSpecRow("Chroma Subsampling", meta.chromaSubsampling)
                TechSpecRow("Colour Primaries", meta.colorPrimaries)
                TechSpecRow("Transfer Characteristics", meta.transferCharacteristics)
                TechSpecRow("HDR Format", hdrFormat.displayName)
                TechSpecRow("Primary Audio Codec", meta.audioCodec)
                TechSpecRow("Audio Tracks (${meta.audioTrackCount})", summarizeTracksJson(meta.audioTracksJson))
                TechSpecRow("Subtitle Tracks (${meta.subtitleTrackCount})", summarizeTracksJson(meta.subtitleTracksJson))
                TechSpecRow("Duration", Formatters.formatDurationMs(meta.durationMs))
                TechSpecRow("File Size", Formatters.formatFileSize(meta.fileSizeBytes))
            }

            // 2. Honest 4-Layer HDR Pipeline Report
            SectionCard(title = stringResource(R.string.detail_hdr_pipeline)) {
                PipelineStageRow("1. Source Container", "${hdrReport.sourceFormat.displayName} — ${hdrReport.sourceEvidence}")
                PipelineStageRow("2. Decoder Metadata", hdrReport.decoderMetadataSummary)
                PipelineStageRow("3. Renderer Capabilities", hdrReport.rendererCapabilitySummary)
                PipelineStageRow("4. Display Hardware", hdrReport.displayHardwareSummary)
                HorizontalDivider(color = CinemaBorderSubtle, modifier = Modifier.padding(vertical = 4.dp))
                Text(
                    text = hdrReport.honestyNote,
                    style = MaterialTheme.typography.bodySmall,
                    color = CinemaIce,
                )
            }

            // 3. Personal Review System (Persists Independently of Multiple Playback Sessions)
            SectionCard(title = stringResource(R.string.detail_personal_review)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        for (star in 1..5) {
                            IconButton(
                                onClick = { rating = if (rating == star.toFloat()) 0f else star.toFloat() },
                                modifier = Modifier.size(42.dp),
                            ) {
                                Icon(
                                    imageVector = if (rating >= star) Icons.Rounded.Star else Icons.Rounded.StarOutline,
                                    contentDescription = "Rate $star stars",
                                    tint = if (rating >= star) CinemaGold else CinemaTextMuted,
                                )
                            }
                        }
                        Text(
                            text = if (rating > 0f) String.format(Locale.US, "%.1f / 5", rating) else "Unrated",
                            style = MaterialTheme.typography.labelMedium,
                            color = CinemaGold,
                        )
                    }

                    IconButton(
                        onClick = { isFavourite = !isFavourite },
                        modifier = Modifier.testTag("review_favourite_toggle"),
                    ) {
                        Icon(
                            imageVector = if (isFavourite) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = stringResource(R.string.cd_favourite),
                            tint = if (isFavourite) CinemaGold else CinemaTextSecondary,
                        )
                    }
                }

                // Watched Status Chips
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    WatchedStatus.entries.forEach { st ->
                        FilterChip(
                            selected = watchedStatus == st,
                            onClick = { watchedStatus = st },
                            label = { Text(st.label) },
                        )
                    }
                }

                // Rewatch Counter + Viewing Date
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Text("Rewatch Count", style = MaterialTheme.typography.labelLarge, color = CinemaTextSecondary)
                        val viewingDate = review?.viewingDateMillis ?: 0L
                        if (viewingDate > 0L) {
                            Text(
                                text = "Viewed: ${Formatters.formatDateOnly(viewingDate)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = CinemaTextMuted,
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = { if (rewatchCount > 0) rewatchCount-- },
                            modifier = Modifier.size(40.dp),
                        ) {
                            Icon(Icons.Rounded.Remove, contentDescription = "Decrease rewatches")
                        }
                        Text(
                            text = "$rewatchCount",
                            style = MaterialTheme.typography.titleMedium,
                            color = CinemaTextPrimary,
                        )
                        IconButton(
                            onClick = { rewatchCount++ },
                            modifier = Modifier.size(40.dp),
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = "Increase rewatches")
                        }
                    }
                }

                OutlinedTextField(
                    value = tagsCsv,
                    onValueChange = { tagsCsv = it },
                    label = { Text("Personal Tags (comma-separated, e.g. sci-fi, reference-hdr, imax)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )

                OutlinedTextField(
                    value = writtenReview,
                    onValueChange = { writtenReview = it },
                    label = { Text("Written Review") },
                    minLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("review_text_input"),
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Private Notes (calibration, edition, audio mix…)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )

                Button(
                    onClick = {
                        viewModel.saveReview(
                            PersonalReviewEntity(
                                videoId = meta.videoId,
                                rating = rating,
                                writtenReview = writtenReview.trim(),
                                watchedStatus = watchedStatus.name,
                                isFavourite = isFavourite,
                                tagsCsv = tagsCsv.trim(),
                                viewingDateMillis = review?.viewingDateMillis?.takeIf { it > 0L }
                                    ?: if (watchedStatus == WatchedStatus.WATCHED) System.currentTimeMillis() else 0L,
                                rewatchCount = rewatchCount,
                                notes = notes.trim(),
                            )
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_review_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
                ) {
                    Text(stringResource(R.string.detail_save_review))
                }
            }

            // 4. Timestamp Bookmarks for this Video
            SectionCard(
                title = "${stringResource(R.string.detail_bookmarks)} (${bookmarks.size})",
                action = {
                    TextButton(onClick = { showAddBookmarkDialog = true }) {
                        Icon(Icons.Outlined.BookmarkAdd, contentDescription = null, tint = CinemaGold, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Add", color = CinemaGold)
                    }
                },
            ) {
                if (bookmarks.isEmpty()) {
                    Text(
                        text = "No bookmarks saved for this film yet. Add one here or tap the bookmark button during playback.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CinemaTextMuted,
                    )
                } else {
                    bookmarks.forEach { bm ->
                        Surface(
                            color = CinemaSurfaceHigh,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPlay(meta.videoId, bm.timestampMs) },
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Bookmark,
                                    contentDescription = null,
                                    tint = if (bm.isFavouriteScene) CinemaGold else CinemaIce,
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${Formatters.formatDurationMs(bm.timestampMs)} · ${bm.title.ifBlank { "Saved Scene" }}",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = CinemaTextPrimary,
                                    )
                                    if (bm.note.isNotBlank()) {
                                        Text(
                                            text = bm.note,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = CinemaTextSecondary,
                                        )
                                    }
                                }
                                IconButton(onClick = { viewModel.deleteBookmark(bm.bookmarkId) }) {
                                    Icon(Icons.Outlined.Delete, contentDescription = stringResource(R.string.cd_delete), tint = CinemaTextMuted)
                                }
                            }
                        }
                    }
                }
            }

            // 5. Viewing Sessions History for this Video
            SectionCard(title = "${stringResource(R.string.detail_sessions)} (${sessions.size})") {
                if (sessions.isEmpty()) {
                    Text(
                        text = "No playback sessions recorded for this film yet.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CinemaTextMuted,
                    )
                } else {
                    sessions.take(10).forEach { s ->
                        val term = SessionTerminationState.fromStored(s.terminationState)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = Formatters.formatDateTime(s.openedAtMillis),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CinemaTextPrimary,
                                )
                                Text(
                                    text = "${Formatters.formatDurationMs(s.startPositionMs)} → ${Formatters.formatDurationMs(s.endPositionMs)} · ${term.label}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CinemaTextSecondary,
                                )
                            }
                            Text(
                                text = Formatters.formatHumanDuration(s.watchedDurationMs),
                                style = MaterialTheme.typography.labelMedium,
                                color = if (s.isCompleted) CinemaEmerald else CinemaGold,
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }

    if (showAddBookmarkDialog) {
        var bmMinutes by remember { mutableStateOf((meta.lastPositionMs / 60_000L).toString()) }
        var bmSeconds by remember { mutableStateOf(((meta.lastPositionMs / 1000L) % 60L).toString()) }
        var bmTitle by remember { mutableStateOf("") }
        var bmNote by remember { mutableStateOf("") }
        var bmFav by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showAddBookmarkDialog = false },
            containerColor = CinemaCharcoal,
            title = { Text("Add Timestamp Bookmark") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = bmMinutes,
                            onValueChange = { bmMinutes = it.filter(Char::isDigit) },
                            label = { Text("Minutes") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = bmSeconds,
                            onValueChange = { bmSeconds = it.filter(Char::isDigit) },
                            label = { Text("Seconds") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    OutlinedTextField(
                        value = bmTitle,
                        onValueChange = { bmTitle = it },
                        label = { Text("Scene Title (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = bmNote,
                        onValueChange = { bmNote = it },
                        label = { Text("Personal Note (optional)") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Mark as Favourite Scene")
                        Switch(checked = bmFav, onCheckedChange = { bmFav = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ms = ((bmMinutes.toLongOrNull() ?: 0L) * 60L + (bmSeconds.toLongOrNull() ?: 0L)) * 1000L
                        viewModel.addBookmark(meta.videoId, meta.filename, ms, bmTitle, bmNote, bmFav)
                        showAddBookmarkDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaGold, contentColor = CinemaObsidian),
                ) {
                    Text("Save Bookmark")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddBookmarkDialog = false }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun SectionCard(
    title: String,
    action: (@Composable () -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    Surface(
        color = CinemaSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CinemaBorderSubtle),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(text = title, style = MaterialTheme.typography.titleMedium, color = CinemaTextPrimary)
                action?.invoke()
            }
            content()
        }
    }
}

@Composable
private fun TechSpecRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = CinemaTextSecondary,
            modifier = Modifier.weight(0.44f),
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = CinemaTextPrimary,
            modifier = Modifier.weight(0.56f),
        )
    }
}

@Composable
private fun PipelineStageRow(stage: String, detail: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(text = stage, style = MaterialTheme.typography.labelLarge, color = CinemaGold)
        Text(text = detail, style = MaterialTheme.typography.bodySmall, color = CinemaTextPrimary)
    }
}

private fun summarizeTracksJson(jsonStr: String): String {
    val arr = runCatching { JSONArray(jsonStr) }.getOrNull() ?: return "None detected"
    if (arr.length() == 0) return "None detected"
    return (0 until arr.length()).joinToString(" · ") { i ->
        val obj = arr.optJSONObject(i)
        val lang = obj?.optString("language", "und").orEmpty().uppercase(Locale.US)
        val codec = obj?.optString("codec", "").orEmpty()
        val ch = obj?.optInt("channels", 0) ?: 0
        val chStr = if (ch > 0) " ${ch}ch" else ""
        "$lang ($codec$chStr)"
    }
}
