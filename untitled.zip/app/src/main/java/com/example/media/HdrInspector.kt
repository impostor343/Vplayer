package com.example.media

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display
import com.example.domain.DecoderLiveStats
import com.example.domain.DisplayHdrCapabilities
import com.example.domain.HdrFormat
import com.example.domain.HdrPipelineReport
import java.util.Locale

/**
 * Inspects real Android display hardware HDR capabilities and builds an honest
 * 4-layer HDR pipeline report distinguishing source container format, decoder metadata,
 * renderer configuration, and physical display hardware capabilities.
 */
object HdrInspector {

    fun queryDisplayCapabilities(context: Context): DisplayHdrCapabilities {
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
        return inspectDisplay(display)
    }

    fun inspectDisplay(display: Display?): DisplayHdrCapabilities {
        if (display == null) {
            return DisplayHdrCapabilities(
                isDisplayHdrCapable = false,
                supportsDolbyVision = false,
                supportsHdr10Plus = false,
                supportsHdr10 = false,
                supportsHlg = false,
                maxLuminanceNits = null,
                maxAverageLuminanceNits = null,
                minLuminanceNits = null,
                wideColorGamutSupported = false,
                summary = "Display capabilities unavailable",
            )
        }

        val hdrCaps = display.hdrCapabilities
        @Suppress("DEPRECATION")
        val supportedTypes: IntArray = hdrCaps?.supportedHdrTypes ?: IntArray(0)
        val supportsDv = supportedTypes.contains(Display.HdrCapabilities.HDR_TYPE_DOLBY_VISION)
        val supportsHdr10 = supportedTypes.contains(Display.HdrCapabilities.HDR_TYPE_HDR10)
        val supportsHlg = supportedTypes.contains(Display.HdrCapabilities.HDR_TYPE_HLG)
        val supportsHdr10Plus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            supportedTypes.contains(Display.HdrCapabilities.HDR_TYPE_HDR10_PLUS)
        } else {
            false
        }
        val wideGamut = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            display.isWideColorGamut
        } else {
            false
        }
        val isHdrCapable = supportsDv || supportsHdr10Plus || supportsHdr10 || supportsHlg

        val maxNits = hdrCaps?.desiredMaxLuminance?.takeIf { it > 0f && it.isFinite() }
        val maxAvgNits = hdrCaps?.desiredMaxAverageLuminance?.takeIf { it > 0f && it.isFinite() }
        val minNits = hdrCaps?.desiredMinLuminance?.takeIf { it >= 0f && it.isFinite() }

        val supportedNames = buildList {
            if (supportsDv) add("Dolby Vision")
            if (supportsHdr10Plus) add("HDR10+")
            if (supportsHdr10) add("HDR10")
            if (supportsHlg) add("HLG")
        }

        val summary = if (supportedNames.isEmpty()) {
            if (wideGamut) "SDR Display (Wide Color Gamut, No HDR)" else "SDR Display Only"
        } else {
            val nitsPart = maxNits?.let { String.format(Locale.US, " · %.0f nits peak", it) } ?: ""
            "Hardware supports ${supportedNames.joinToString(", ")}$nitsPart"
        }

        return DisplayHdrCapabilities(
            isDisplayHdrCapable = isHdrCapable,
            supportsDolbyVision = supportsDv,
            supportsHdr10Plus = supportsHdr10Plus,
            supportsHdr10 = supportsHdr10,
            supportsHlg = supportsHlg,
            maxLuminanceNits = maxNits,
            maxAverageLuminanceNits = maxAvgNits,
            minLuminanceNits = minNits,
            wideColorGamutSupported = wideGamut,
            summary = summary,
        )
    }

    /**
     * Classifies source HDR format strictly from container/bitstream technical evidence.
     * NEVER upgrades HDR10 to HDR10+ without explicit dynamic metadata or HDR10+ profile proof.
     */
    fun classifySourceFormat(
        mimeType: String?,
        codecProfileName: String?,
        colorPrimaries: String?,
        transferCharacteristics: String?,
        hasHdr10PlusDynamicMetadata: Boolean,
        hasDolbyVisionConfig: Boolean,
    ): Pair<HdrFormat, String> {
        val mime = mimeType.orEmpty().lowercase(Locale.US)
        val profile = codecProfileName.orEmpty().lowercase(Locale.US)
        val primaries = colorPrimaries.orEmpty().lowercase(Locale.US)
        val transfer = transferCharacteristics.orEmpty().lowercase(Locale.US)

        if (hasDolbyVisionConfig || mime.contains("dolby-vision") || profile.contains("dolby")) {
            return HdrFormat.DOLBY_VISION to
                "Dolby Vision configuration record detected (${codecProfileName ?: mimeType ?: "DV"})"
        }

        val isPq = transfer.contains("pq") || transfer.contains("st2084") || transfer.contains("2084")
        val isHlg = transfer.contains("hlg") || transfer.contains("arib") || transfer.contains("b67")
        val isBt2020 = primaries.contains("2020")

        if (hasHdr10PlusDynamicMetadata || profile.contains("hdr10plus") || profile.contains("hdr10+")) {
            return HdrFormat.HDR10_PLUS to
                "Verified HDR10+ dynamic metadata (SMPTE ST 2094-40 / HDR10+ profile)"
        }

        if (isPq) {
            val evidence = if (isBt2020) {
                "Static PQ (SMPTE ST 2084) + BT.2020 primaries (no HDR10+ dynamic metadata detected)"
            } else {
                "PQ transfer (SMPTE ST 2084) detected; static HDR10 signaling"
            }
            return HdrFormat.HDR10 to evidence
        }

        if (isHlg) {
            return HdrFormat.HLG to "Hybrid Log-Gamma (ARIB STD-B67) transfer detected"
        }

        if (primaries.isNotBlank() || transfer.isNotBlank()) {
            return HdrFormat.SDR to
                "Standard Dynamic Range (${colorPrimaries ?: "BT.709"} / ${transferCharacteristics ?: "BT.709"})"
        }

        return HdrFormat.SDR to "No HDR transfer signaling present in container; treated as SDR"
    }

    /**
     * Builds the honest 4-layer HDR pipeline report combining static container scan,
     * live mpv decoder stats (if active), renderer state, and display hardware support.
     */
    fun buildPipelineReport(
        sourceFormat: HdrFormat,
        sourceEvidence: String,
        liveStats: DecoderLiveStats?,
        displayCaps: DisplayHdrCapabilities,
    ): HdrPipelineReport {
        val decoderSummary = if (liveStats != null && liveStats.videoCodec != "—") {
            val peakText = liveStats.sigPeak?.let {
                String.format(Locale.US, " · Peak %.2fx", it)
            } ?: ""
            "Codec: ${liveStats.videoCodec} (${liveStats.hwDecCurrent}) · " +
                "Primaries: ${liveStats.primaries} · Transfer: ${liveStats.gamma} · " +
                "PixFmt: ${liveStats.pixelFormat}$peakText"
        } else {
            "Not actively decoding — open video in player to inspect live mpv decoder parameters"
        }

        val rendererSummary = if (liveStats != null && liveStats.currentVo != "—") {
            val hint = if (liveStats.targetColorspaceHint) {
                "target-colorspace-hint=yes · tone-mapping=${liveStats.toneMappingMode}"
            } else {
                "target-colorspace-hint=no · tone-mapping=${liveStats.toneMappingMode}"
            }
            "VO: ${liveStats.currentVo} · $hint"
        } else {
            "Configured for mpv gpu-next (libplacebo) / mediacodec pipeline (active state reported during playback)"
        }

        val displaySupportsThisFormat = when (sourceFormat) {
            HdrFormat.DOLBY_VISION -> displayCaps.supportsDolbyVision
            HdrFormat.HDR10_PLUS -> displayCaps.supportsHdr10Plus || displayCaps.supportsHdr10
            HdrFormat.HDR10 -> displayCaps.supportsHdr10
            HdrFormat.HLG -> displayCaps.supportsHlg
            HdrFormat.SDR, HdrFormat.UNKNOWN -> false
        }

        val rendererPassesHdr = liveStats?.targetColorspaceHint == true
        val isOutputtingHdrLikely = sourceFormat.isHdr && displaySupportsThisFormat && rendererPassesHdr

        val honestyNote = when {
            !sourceFormat.isHdr ->
                "Source stream is SDR. Standard luminance range presentation."
            !displayCaps.isDisplayHdrCapable ->
                "Source is ${sourceFormat.displayName}, but this display only reports SDR capability. mpv will tone-map HDR to SDR."
            sourceFormat == HdrFormat.HDR10_PLUS && !displayCaps.supportsHdr10Plus && displayCaps.supportsHdr10 ->
                "Source contains HDR10+ metadata, but display hardware only advertises HDR10 (static HDR10 / tone-map fallback)."
            sourceFormat == HdrFormat.DOLBY_VISION && !displayCaps.supportsDolbyVision ->
                "Source is Dolby Vision, which this display does not natively advertise; mpv libplacebo tone-mapping or HDR10 fallback applies."
            liveStats == null ->
                "Display hardware supports ${sourceFormat.displayName}, but actual HDR surface output can only be verified during active playback."
            !rendererPassesHdr ->
                "Display supports ${sourceFormat.displayName}, but mpv target-colorspace-hint is disabled (rendering via tone-mapping)."
            else ->
                "Source (${sourceFormat.displayName}), mpv ${liveStats.currentVo} colorspace hint, window COLOR_MODE_HDR, and display hardware align. Actual hardware HDR passthrough vs tone-mapping still depends on this device's GPU/Display HAL."
        }

        return HdrPipelineReport(
            sourceFormat = sourceFormat,
            sourceEvidence = sourceEvidence,
            decoderMetadataSummary = decoderSummary,
            rendererCapabilitySummary = rendererSummary,
            displayHardwareSummary = displayCaps.summary,
            isDisplayOutputtingHdrLikely = isOutputtingHdrLikely,
            honestyNote = honestyNote,
        )
    }
}
