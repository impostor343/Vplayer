package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.PersonalCinemaApplication
import com.example.data.db.MpvConfigBackupEntity
import com.example.data.db.MpvProfileEntity
import com.example.data.db.PersonalReviewEntity
import com.example.data.db.PlaybackSessionEntity
import com.example.data.db.TimestampBookmarkEntity
import com.example.data.db.VideoMetadataEntity
import com.example.data.db.WatchedFolderEntity
import com.example.domain.CinemaStatsSummary
import com.example.domain.ConfigValidationResult
import com.example.domain.DisplayHdrCapabilities
import com.example.domain.HdrFormat
import com.example.domain.LibraryFilterState
import com.example.domain.LibrarySortOption
import com.example.domain.WatchedStatus
import com.example.media.HdrInspector
import com.example.media.MpvConfigManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LibraryVideoItem(
    val metadata: VideoMetadataEntity,
    val review: PersonalReviewEntity?,
) {
    val hdrFormat: HdrFormat get() = HdrFormat.fromStored(metadata.hdrFormat)
    val watchedStatus: WatchedStatus get() = WatchedStatus.fromStored(review?.watchedStatus)
    val rating: Float get() = review?.rating ?: 0f
    val isFavourite: Boolean get() = review?.isFavourite ?: false
    val tags: List<String>
        get() = review?.tagsCsv
            ?.split(",")
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?: emptyList()
}

data class ConfigEditorUiState(
    val mpvConfText: String = "",
    val inputConfText: String = "",
    val mpvValidation: ConfigValidationResult? = null,
    val inputValidation: ConfigValidationResult? = null,
    val hasUnsavedChanges: Boolean = false,
)

class CinemaAppViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PersonalCinemaApplication
    val repository = app.repository

    val displayHdrCapabilities: DisplayHdrCapabilities = HdrInspector.queryDisplayCapabilities(application)

    private val _filterState = MutableStateFlow(LibraryFilterState())
    val filterState: StateFlow<LibraryFilterState> = _filterState.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _configEditorState = MutableStateFlow(
        ConfigEditorUiState(
            mpvConfText = repository.mpvConfigManager.readMpvConf(),
            inputConfText = repository.mpvConfigManager.readInputConf(),
        )
    )
    val configEditorState: StateFlow<ConfigEditorUiState> = _configEditorState.asStateFlow()

    val folders: StateFlow<List<WatchedFolderEntity>> = repository.foldersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val allVideos: StateFlow<List<VideoMetadataEntity>> = repository.videosFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val allReviews: StateFlow<List<PersonalReviewEntity>> = repository.reviewsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val allSessions: StateFlow<List<PlaybackSessionEntity>> = repository.sessionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val allBookmarks: StateFlow<List<TimestampBookmarkEntity>> = repository.bookmarksFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val mpvProfiles: StateFlow<List<MpvProfileEntity>> = repository.mpvProfilesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val mpvBackups: StateFlow<List<MpvConfigBackupEntity>> = repository.mpvBackupsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val availableTags: StateFlow<List<String>> = allReviews
        .combine(_filterState) { reviews, _ ->
            reviews.flatMap { r ->
                r.tagsCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            }.distinct().sorted()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val availableSubfolders: StateFlow<List<String>> = combine(allVideos, _filterState) { videos, filter ->
        val scoped = if (filter.selectedFolderUri != null) {
            videos.filter { it.folderUri == filter.selectedFolderUri }
        } else {
            videos
        }
        scoped.map { it.relativeSubfolder }
            .filter { it.isNotBlank() }
            .distinct()
            .sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val filteredLibraryItems: StateFlow<List<LibraryVideoItem>> = combine(
        allVideos,
        allReviews,
        _filterState,
    ) { videos, reviews, filter ->
        val reviewMap = reviews.associateBy { it.videoId }
        val q = filter.query.trim().lowercase()

        videos.map { LibraryVideoItem(it, reviewMap[it.videoId]) }
            .filter { item ->
                val folderOk = filter.selectedFolderUri == null ||
                    item.metadata.folderUri == filter.selectedFolderUri
                val subOk = filter.selectedSubfolder == null ||
                    item.metadata.relativeSubfolder == filter.selectedSubfolder ||
                    item.metadata.relativeSubfolder.startsWith("${filter.selectedSubfolder}/")
                val hdrOk = filter.hdrFilter == null || item.hdrFormat == filter.hdrFilter
                val watchedOk = filter.watchedFilter == null || item.watchedStatus == filter.watchedFilter
                val favOk = !filter.favouritesOnly || item.isFavourite
                val ratingOk = filter.minRating <= 0f || item.rating >= filter.minRating
                val tagOk = filter.selectedTag == null ||
                    item.tags.any { it.equals(filter.selectedTag, ignoreCase = true) }
                val darOk = filter.aspectRatioFilter == null ||
                    item.metadata.displayAspectRatioLabel == filter.aspectRatioFilter
                val queryOk = q.isEmpty() ||
                    item.metadata.filename.lowercase().contains(q) ||
                    item.metadata.videoCodec.lowercase().contains(q) ||
                    item.metadata.displayAspectRatioLabel.lowercase().contains(q) ||
                    item.hdrFormat.displayName.lowercase().contains(q) ||
                    item.metadata.relativeSubfolder.lowercase().contains(q) ||
                    item.tags.any { it.lowercase().contains(q) } ||
                    (item.review?.writtenReview?.lowercase()?.contains(q) == true)

                folderOk && subOk && hdrOk && watchedOk && favOk && ratingOk && tagOk && darOk && queryOk
            }
            .let { list ->
                when (filter.sortOption) {
                    LibrarySortOption.TITLE_ASC -> list.sortedBy { it.metadata.filename.lowercase() }
                    LibrarySortOption.DATE_MODIFIED_DESC -> list.sortedByDescending { it.metadata.lastModifiedMillis }
                    LibrarySortOption.LAST_WATCHED_DESC -> list.sortedByDescending { it.metadata.lastWatchedAtMillis }
                    LibrarySortOption.RATING_DESC -> list.sortedByDescending { it.rating }
                    LibrarySortOption.DURATION_DESC -> list.sortedByDescending { it.metadata.durationMs }
                    LibrarySortOption.FILE_SIZE_DESC -> list.sortedByDescending { it.metadata.fileSizeBytes }
                }
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val statsSummary: StateFlow<CinemaStatsSummary> = combine(
        allSessions,
        allReviews,
        allVideos,
    ) { sessions, reviews, videos ->
        repository.computeStats(sessions, reviews, videos)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CinemaStatsSummary())

    // ---- Library Actions ----

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun updateFilter(transform: (LibraryFilterState) -> LibraryFilterState) {
        _filterState.update(transform)
    }

    fun resetFilters() {
        _filterState.update {
            LibraryFilterState(
                selectedFolderUri = it.selectedFolderUri,
                isGridLayout = it.isGridLayout,
                sortOption = it.sortOption,
            )
        }
    }

    fun addWatchedFolder(treeUri: Uri) {
        viewModelScope.launch {
            _isScanning.value = true
            repository.addWatchedFolder(treeUri)
                .onSuccess { folder ->
                    _statusBanner.value = "Indexed ${folder.videoCount} video(s) from ${folder.displayName}"
                }
                .onFailure { err ->
                    _statusBanner.value = "Could not index folder: ${err.message}"
                }
            _isScanning.value = false
        }
    }

    fun removeFolder(folderUri: String) {
        viewModelScope.launch {
            repository.removeWatchedFolder(folderUri)
            _filterState.update {
                if (it.selectedFolderUri == folderUri) it.copy(selectedFolderUri = null, selectedSubfolder = null)
                else it
            }
            _statusBanner.value = "Folder removed from local index"
        }
    }

    fun rescanLibrary() {
        viewModelScope.launch {
            _isScanning.value = true
            val count = repository.rescanAllFolders()
            _statusBanner.value = "Library scan complete ($count local video(s) verified)"
            _isScanning.value = false
        }
    }

    fun openSingleVideo(uri: Uri, onReadyToPlay: (String) -> Unit) {
        viewModelScope.launch {
            _isScanning.value = true
            val entity = repository.registerSingleVideoUri(uri)
            _isScanning.value = false
            onReadyToPlay(entity.videoId)
        }
    }

    // ---- Reviews & Bookmarks Actions ----

    fun saveReview(review: PersonalReviewEntity) {
        viewModelScope.launch {
            repository.savePersonalReview(review)
            _statusBanner.value = "Personal review saved locally"
        }
    }

    fun addBookmark(
        videoId: String,
        videoFilename: String,
        timestampMs: Long,
        title: String,
        note: String,
        isFavouriteScene: Boolean,
    ) {
        viewModelScope.launch {
            repository.addBookmark(videoId, videoFilename, timestampMs, title, note, isFavouriteScene)
            _statusBanner.value = "Scene bookmarked at ${com.example.media.Formatters.formatDurationMs(timestampMs)}"
        }
    }

    fun toggleBookmarkFavourite(bookmark: TimestampBookmarkEntity) {
        viewModelScope.launch {
            repository.toggleBookmarkFavourite(bookmark)
        }
    }

    fun deleteBookmark(bookmarkId: Long) {
        viewModelScope.launch {
            repository.deleteBookmark(bookmarkId)
            _statusBanner.value = "Bookmark deleted"
        }
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            _statusBanner.value = "Session record removed"
        }
    }

    // ---- mpv Configuration Actions ----

    fun reloadConfigFromDisk() {
        _configEditorState.value = ConfigEditorUiState(
            mpvConfText = repository.mpvConfigManager.readMpvConf(),
            inputConfText = repository.mpvConfigManager.readInputConf(),
            hasUnsavedChanges = false,
        )
    }

    fun updateMpvConfText(text: String) {
        _configEditorState.update {
            it.copy(
                mpvConfText = text,
                hasUnsavedChanges = true,
                mpvValidation = MpvConfigManager.validateMpvConf(text),
            )
        }
    }

    fun updateInputConfText(text: String) {
        _configEditorState.update {
            it.copy(
                inputConfText = text,
                hasUnsavedChanges = true,
                inputValidation = MpvConfigManager.validateInputConf(text),
            )
        }
    }

    fun validateConfigs(): Boolean {
        val cur = _configEditorState.value
        val mpvRes = MpvConfigManager.validateMpvConf(cur.mpvConfText)
        val inputRes = MpvConfigManager.validateInputConf(cur.inputConfText)
        _configEditorState.update { it.copy(mpvValidation = mpvRes, inputValidation = inputRes) }
        return mpvRes.isValid && inputRes.isValid
    }

    fun applyConfigsWithBackup(reason: String = "Manual mpv configuration update") {
        if (!validateConfigs()) {
            _statusBanner.value = "Fix configuration syntax errors before applying"
            return
        }
        viewModelScope.launch {
            val cur = _configEditorState.value
            repository.applyMpvConfigWithBackup(cur.mpvConfText, cur.inputConfText, reason)
            _configEditorState.update { it.copy(hasUnsavedChanges = false) }
            _statusBanner.value = "Configuration applied (previous version backed up)"
        }
    }

    fun activateProfile(profile: MpvProfileEntity) {
        viewModelScope.launch {
            repository.activateProfile(profile)
            reloadConfigFromDisk()
            _statusBanner.value = "Activated profile: ${profile.name}"
        }
    }

    fun saveCurrentAsProfile(name: String, description: String) {
        viewModelScope.launch {
            val cur = _configEditorState.value
            repository.saveCustomProfile(name, description, cur.mpvConfText, cur.inputConfText)
            _statusBanner.value = "Saved custom profile '$name'"
        }
    }

    fun deleteCustomProfile(profileId: String) {
        viewModelScope.launch {
            repository.deleteCustomProfile(profileId)
            _statusBanner.value = "Custom profile deleted"
        }
    }

    fun restoreConfigBackup(backup: MpvConfigBackupEntity) {
        viewModelScope.launch {
            repository.restoreBackup(backup)
            reloadConfigFromDisk()
            _statusBanner.value = "Restored configuration backup"
        }
    }

    fun restoreFactoryDefaults() {
        viewModelScope.launch {
            repository.restoreDefaultConfigs()
            reloadConfigFromDisk()
            _statusBanner.value = "Restored default HDR mpv.conf & input.conf (prior config backed up)"
        }
    }

    fun importConfigFile(uri: Uri, isInputConf: Boolean) {
        viewModelScope.launch {
            repository.mpvConfigManager.readTextFromUri(uri)
                .onSuccess { text ->
                    if (isInputConf) updateInputConfText(text) else updateMpvConfText(text)
                    _statusBanner.value = "Loaded file into editor — tap Apply & Backup to activate"
                }
                .onFailure { err ->
                    _statusBanner.value = "Import failed: ${err.message}"
                }
        }
    }

    fun exportConfigFile(uri: Uri, isInputConf: Boolean) {
        viewModelScope.launch {
            val text = if (isInputConf) _configEditorState.value.inputConfText else _configEditorState.value.mpvConfText
            repository.mpvConfigManager.writeTextToUri(uri, text)
                .onSuccess { _statusBanner.value = "Configuration exported locally" }
                .onFailure { _statusBanner.value = "Export failed: ${it.message}" }
        }
    }

    // ---- Vault Backup & Restore ----

    fun exportPersonalVault(uri: Uri) {
        viewModelScope.launch {
            repository.backupManager.exportToUri(uri)
                .onSuccess { _statusBanner.value = "Personal vault exported locally (JSON)" }
                .onFailure { _statusBanner.value = "Vault export failed: ${it.message}" }
        }
    }

    fun importPersonalVault(uri: Uri) {
        viewModelScope.launch {
            repository.backupManager.importFromUri(uri)
                .onSuccess { summary ->
                    reloadConfigFromDisk()
                    _statusBanner.value =
                        "Restored ${summary.reviewsImported} reviews, ${summary.sessionsImported} sessions, ${summary.bookmarksImported} bookmarks"
                }
                .onFailure { _statusBanner.value = "Vault import failed: ${it.message}" }
        }
    }
}
