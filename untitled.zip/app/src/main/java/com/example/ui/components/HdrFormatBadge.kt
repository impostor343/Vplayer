package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.HdrFormat
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaSurfaceHigh
import com.example.ui.theme.CinemaTextPrimary
import com.example.ui.theme.CinemaTextSecondary
import com.example.ui.theme.FormatDolbyVisionBg
import com.example.ui.theme.FormatDolbyVisionViolet
import com.example.ui.theme.FormatHdr10Amber
import com.example.ui.theme.FormatHdr10Bg
import com.example.ui.theme.FormatHdr10PlusBg
import com.example.ui.theme.FormatHdr10PlusGold
import com.example.ui.theme.FormatHlgBg
import com.example.ui.theme.FormatHlgCyan
import com.example.ui.theme.FormatSdrBg
import com.example.ui.theme.FormatSdrSlate
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SpaceGroteskFontFamily

/**
 * Distinctive visual format identification badge for SDR, HDR10, HDR10+, HLG, and Dolby Vision.
 * Each format has its own unmistakable typographic treatment, accent palette, and geometric mark
 * without counterfeiting third-party trademarked bitmap artwork.
 */
@Composable
fun HdrFormatBadge(
    format: HdrFormat,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
) {
    val hPad = if (compact) 6.dp else 8.dp
    val vPad = if (compact) 2.dp else 4.dp
    val fontSize = if (compact) 10.sp else 11.sp

    when (format) {
        HdrFormat.HDR10_PLUS -> {
            // Distinctive HDR10+ dynamic-metadata gold styling with prominent '+' superscript emblem
            Box(
                modifier = modifier
                    .semantics { contentDescription = "Video format: HDR10 Plus" }
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(FormatHdr10PlusBg, Color(0xFF382807), FormatHdr10PlusBg)
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.horizontalGradient(
                            listOf(FormatHdr10PlusGold, Color(0xFFFFE082), FormatHdr10PlusGold)
                        ),
                        shape = RoundedCornerShape(6.dp),
                    )
                    .padding(horizontal = hPad, vertical = vPad),
                contentAlignment = Alignment.Center,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Text(
                        text = "HDR",
                        fontFamily = SpaceGroteskFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = fontSize,
                        letterSpacing = 0.6.sp,
                        color = FormatHdr10PlusGold,
                    )
                    Text(
                        text = "10",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = fontSize,
                        color = Color(0xFFFFF3C4),
                    )
                    // Dynamic '+' emblem
                    Canvas(modifier = Modifier.size(if (compact) 7.dp else 9.dp)) {
                        val c = size.width / 2f
                        val stroke = size.width * 0.24f
                        drawLine(
                            color = FormatHdr10PlusGold,
                            start = Offset(c, 0f),
                            end = Offset(c, size.height),
                            strokeWidth = stroke,
                            cap = StrokeCap.Round,
                        )
                        drawLine(
                            color = FormatHdr10PlusGold,
                            start = Offset(0f, c),
                            end = Offset(size.width, c),
                            strokeWidth = stroke,
                            cap = StrokeCap.Round,
                        )
                    }
                }
            }
        }

        HdrFormat.DOLBY_VISION -> {
            Surface(
                modifier = modifier.semantics { contentDescription = "Video format: Dolby Vision" },
                color = FormatDolbyVisionBg,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, FormatDolbyVisionViolet.copy(alpha = 0.7f)),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = hPad, vertical = vPad),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "DV",
                        fontFamily = SpaceGroteskFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = fontSize,
                        color = FormatDolbyVisionViolet,
                    )
                    if (!compact) {
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "VISION",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 9.sp,
                            letterSpacing = 0.8.sp,
                            color = CinemaTextPrimary,
                        )
                    }
                }
            }
        }

        HdrFormat.HDR10 -> {
            Surface(
                modifier = modifier.semantics { contentDescription = "Video format: HDR10" },
                color = FormatHdr10Bg,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, FormatHdr10Amber.copy(alpha = 0.65f)),
            ) {
                Text(
                    text = "HDR10",
                    modifier = Modifier.padding(horizontal = hPad, vertical = vPad),
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = fontSize,
                    letterSpacing = 0.4.sp,
                    color = FormatHdr10Amber,
                )
            }
        }

        HdrFormat.HLG -> {
            Surface(
                modifier = modifier.semantics { contentDescription = "Video format: HLG" },
                color = FormatHlgBg,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, FormatHlgCyan.copy(alpha = 0.65f)),
            ) {
                Text(
                    text = "HLG",
                    modifier = Modifier.padding(horizontal = hPad, vertical = vPad),
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = fontSize,
                    letterSpacing = 0.6.sp,
                    color = FormatHlgCyan,
                )
            }
        }

        HdrFormat.SDR, HdrFormat.UNKNOWN -> {
            Surface(
                modifier = modifier.semantics {
                    contentDescription = "Video format: ${format.displayName}"
                },
                color = FormatSdrBg,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, CinemaBorder),
            ) {
                Text(
                    text = if (format == HdrFormat.SDR) "SDR" else "N/A",
                    modifier = Modifier.padding(horizontal = hPad, vertical = vPad),
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = fontSize,
                    color = FormatSdrSlate,
                )
            }
        }
    }
}

@Composable
fun AspectRatioBadge(
    darLabel: String,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
) {
    Surface(
        modifier = modifier.semantics { contentDescription = "Aspect ratio: $darLabel" },
        color = CinemaSurfaceHigh.copy(alpha = 0.92f),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, CinemaBorder),
    ) {
        Text(
            text = darLabel,
            modifier = Modifier.padding(
                horizontal = if (compact) 6.dp else 8.dp,
                vertical = if (compact) 2.dp else 4.dp,
            ),
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = if (compact) 10.sp else 11.sp,
            ),
            color = CinemaTextPrimary,
        )
    }
}

@Composable
fun TechnicalSpecPill(
    label: String,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = CinemaSurfaceHigh,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, CinemaBorder.copy(alpha = 0.6f)),
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelSmall,
            color = CinemaTextSecondary,
        )
    }
}
