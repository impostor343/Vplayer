package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.PersonalCinemaApplication
import com.example.data.db.TimestampBookmarkEntity
import com.example.data.db.VideoMetadataEntity
import com.example.domain.AspectRatioPreset
import com.example.domain.DisplayHdrCapabilities
import com.example.domain.HdrFormat
import com.example.domain.HdrPipelineReport
import com.example.domain.SessionTerminationState
import com.example.media.AspectRatioCalculator
import com.example.media.HdrInspector
import com.example.player.MpvEngineController
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PlayerUiState(
    val currentVideo: VideoMetadataEntity? = null,
    val playlist: List<VideoMetadataEntity> = emptyList(),
    val playlistIndex: Int = -1,
    val bookmarksForCurrentVideo: List<TimestampBookmarkEntity> = emptyList(),
    val activeAspectPreset: AspectRatioPreset = AspectRatioPreset.NATIVE,
    val liveDarLabel: String = "—",
    val hdrReport: HdrPipelineReport? = null,
    val displayCaps: DisplayHdrCapabilities? = null,
    val showTechOverlay: Boolean = false,
    val statusNotice: String? = null,
) {
    val hasPrevious: Boolean get() = playlistIndex > 0
    val hasNext: Boolean get() = playlistIndex in 0 until (playlist.size - 1)
}

class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PersonalCinemaApplication
    private val repository = app.repository

    val engineController = MpvEngineController(application, app.mpvConfigManager)
    val playbackState: StateFlow<MpvEngineController.LivePlaybackState> = engineController.state

    private val displayCaps = HdrInspector.queryDisplayCapabilities(application)

    private val _uiState = MutableStateFlow(PlayerUiState(displayCaps = displayCaps))
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private var activeSessionId: Long? = null
    private var accumulatedWatchMs: Long = 0L
    private var lastTickMillis: Long = 0L
    private var checkpointJob: Job? = null
    private var bookmarksJob: Job? = null
    private var telemetryEnrichedForVideoId: String? = null

    init {
        viewModelScope.launch {
            combine(playbackState, _uiState) { live, ui -> live to ui.currentVideo }
                .collect { (live, video) ->
                    if (video != null) {
                        val stats = live.decoderStats
                        val darLabel = when {
                            stats.aspect > 0.0 -> AspectRatioCalculator.fromDarValue(stats.aspect).formattedLabel
                            stats.width > 0 && stats.height > 0 ->
                                AspectRatioCalculator.calculateFromPar(stats.width, stats.height, stats.par).formattedLabel
                            else -> video.displayAspectRatioLabel
                        }
                        val report = HdrInspector.buildPipelineReport(
                            sourceFormat = HdrFormat.fromStored(video.hdrFormat),
                            sourceEvidence = video.hdrEvidence,
                            liveStats = stats.takeIf { it.videoCodec != "—" },
                            displayCaps = displayCaps,
                        )
                        _uiState.update { it.copy(liveDarLabel = darLabel, hdrReport = report) }

                        if (stats.videoCodec != "—" && telemetryEnrichedForVideoId != video.videoId) {
                            telemetryEnrichedForVideoId = video.videoId
                            repository.enrichVideoFromMpvDecoder(video.videoId, stats)
                        }
                    }
                }
        }
    }

    fun openVideo(videoId: String, explicitStartMs: Long? = null) {
        viewModelScope.launch {
            finalizeCurrentSession(SessionTerminationState.NORMAL)

            val allVideos = repository.getAllVideos()
            val target = allVideos.firstOrNull { it.videoId == videoId }
                ?: repository.getVideoById(videoId)
                ?: return@launch

            val sameFolderList = allVideos.filter {
                it.folderUri == target.folderUri && it.relativeSubfolder == target.relativeSubfolder
            }.ifEmpty { listOf(target) }
            val index = sameFolderList.indexOfFirst { it.videoId == target.videoId }.coerceAtLeast(0)

            val startPos = when {
                explicitStartMs != null && explicitStartMs >= 0L -> explicitStartMs
                target.lastPositionMs > 2_000L -> target.lastPositionMs
                else -> 0L
            }

            telemetryEnrichedForVideoId = null
            _uiState.update {
                it.copy(
                    currentVideo = target,
                    playlist = sameFolderList,
                    playlistIndex = index,
                    activeAspectPreset = AspectRatioPreset.NATIVE,
                    liveDarLabel = target.displayAspectRatioLabel,
                    hdrReport = HdrInspector.buildPipelineReport(
                        sourceFormat = HdrFormat.fromStored(target.hdrFormat),
                        sourceEvidence = target.hdrEvidence,
                        liveStats = null,
                        displayCaps = displayCaps,
                    ),
                )
            }

            // Observe bookmarks for this video
            bookmarksJob?.cancel()
            bookmarksJob = viewModelScope.launch {
                repository.observeBookmarksForVideo(target.videoId).collect { list ->
                    _uiState.update { it.copy(bookmarksForCurrentVideo = list) }
                }
            }

            // Create a fresh session record every time a video is opened
            activeSessionId = repository.startPlaybackSession(target, startPos)
            accumulatedWatchMs = 0L
            lastTickMillis = System.currentTimeMillis()

            engineController.loadMedia(Uri.parse(target.videoId), startPos)
            startPeriodicCheckpointing()
        }
    }

    fun playNextInPlaylist() {
        val ui = _uiState.value
        if (ui.hasNext) {
            openVideo(ui.playlist[ui.playlistIndex + 1].videoId, explicitStartMs = 0L)
        }
    }

    fun playPreviousInPlaylist() {
        val ui = _uiState.value
        if (ui.hasPrevious) {
            openVideo(ui.playlist[ui.playlistIndex - 1].videoId, explicitStartMs = 0L)
        }
    }

    fun setAspectRatioPreset(preset: AspectRatioPreset) {
        engineController.applyAspectRatioPreset(preset)
        _uiState.update { it.copy(activeAspectPreset = preset) }
    }

    fun toggleTechOverlay() {
        val next = !_uiState.value.showTechOverlay
        if (next) engineController.refreshLiveTelemetry()
        _uiState.update { it.copy(showTechOverlay = next) }
    }

    fun loadExternalSubtitle(uri: Uri) {
        val ok = engineController.addExternalSubtitle(uri)
        _uiState.update {
            it.copy(
                statusNotice = if (ok) "External subtitle track loaded" else "Could not load external subtitle"
            )
        }
    }

    fun bookmarkCurrentTimestamp(title: String, note: String, isFavourite: Boolean) {
        val video = _uiState.value.currentVideo ?: return
        val pos = playbackState.value.positionMs
        viewModelScope.launch {
            repository.addBookmark(
                videoId = video.videoId,
                videoFilename = video.filename,
                timestampMs = pos,
                title = title,
                note = note,
                isFavouriteScene = isFavourite,
            )
            _uiState.update { it.copy(statusNotice = "Bookmarked at ${com.example.media.Formatters.formatDurationMs(pos)}") }
        }
    }

    fun clearNotice() {
        _uiState.update { it.copy(statusNotice = null) }
    }

    fun onAppBackgrounded() {
        engineController.setPaused(true)
        viewModelScope.launch {
            checkpointNow()
        }
    }

    fun onLeavePlayer(interrupted: Boolean = false) {
        engineController.setPaused(true)
        viewModelScope.launch {
            finalizeCurrentSession(
                if (interrupted) SessionTerminationState.INTERRUPTED else SessionTerminationState.NORMAL
            )
        }
    }

    private fun startPeriodicCheckpointing() {
        checkpointJob?.cancel()
        checkpointJob = viewModelScope.launch {
            var tickCounter = 0
            while (isActive) {
                delay(1_000L)
                val now = System.currentTimeMillis()
                val live = playbackState.value
                if (!live.isPaused && live.status is MpvEngineController.EngineStatus.Ready) {
                    val delta = (now - lastTickMillis).coerceIn(0L, 5_000L)
                    accumulatedWatchMs += delta
                }
                lastTickMillis = now
                tickCounter++

                // Save checkpoint every 10 seconds to survive unexpected process kill
                if (tickCounter % 10 == 0) {
                    checkpointNow()
                    if (_uiState.value.showTechOverlay) {
                        engineController.refreshLiveTelemetry()
                    }
                }
            }
        }
    }

    private suspend fun checkpointNow() {
        val sid = activeSessionId ?: return
        val live = playbackState.value
        val dur = live.durationMs.takeIf { it > 0L } ?: (_uiState.value.currentVideo?.durationMs ?: 0L)
        repository.checkpointPlaybackSession(
            sessionId = sid,
            currentPositionMs = live.positionMs,
            watchedDurationMs = accumulatedWatchMs,
            videoDurationMs = dur,
        )
    }

    private suspend fun finalizeCurrentSession(terminationState: SessionTerminationState) {
        val sid = activeSessionId ?: return
        activeSessionId = null
        checkpointJob?.cancel()
        val live = playbackState.value
        val dur = live.durationMs.takeIf { it > 0L } ?: (_uiState.value.currentVideo?.durationMs ?: 0L)
        withContext(NonCancellable) {
            repository.finalizePlaybackSession(
                sessionId = sid,
                endPositionMs = live.positionMs,
                watchedDurationMs = accumulatedWatchMs,
                videoDurationMs = dur,
                terminationState = terminationState,
            )
        }
    }

    override fun onCleared() {
        val sid = activeSessionId
        if (sid != null) {
            activeSessionId = null
            val live = playbackState.value
            val endPos = live.positionMs
            val watched = accumulatedWatchMs
            val dur = live.durationMs.takeIf { it > 0L } ?: (_uiState.value.currentVideo?.durationMs ?: 0L)
            app.appScope.launch {
                repository.finalizePlaybackSession(
                    sessionId = sid,
                    endPositionMs = endPos,
                    watchedDurationMs = watched,
                    videoDurationMs = dur,
                    terminationState = SessionTerminationState.NORMAL,
                )
            }
        }
        checkpointJob?.cancel()
        bookmarksJob?.cancel()
        engineController.release()
        super.onCleared()
    }
}
