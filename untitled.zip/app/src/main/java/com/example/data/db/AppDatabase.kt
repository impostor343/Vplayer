package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration

@Database(
    entities = [
        WatchedFolderEntity::class,
        VideoMetadataEntity::class,
        PlaybackSessionEntity::class,
        PersonalReviewEntity::class,
        TimestampBookmarkEntity::class,
        MpvProfileEntity::class,
        MpvConfigBackupEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun folderDao(): FolderDao
    abstract fun videoMetadataDao(): VideoMetadataDao
    abstract fun playbackSessionDao(): PlaybackSessionDao
    abstract fun personalReviewDao(): PersonalReviewDao
    abstract fun timestampBookmarkDao(): TimestampBookmarkDao
    abstract fun mpvConfigDao(): MpvConfigDao

    companion object {
        const val DATABASE_NAME = "personal_cinema_vault.db"

        /**
         * Explicit forward-only schema migration registry.
         * Destructive fallback is intentionally forbidden to protect personal reviews,
         * session history, and timestamp bookmarks against accidental data loss.
         */
        val MIGRATIONS: Array<Migration> = emptyArray()

        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME,
                )
                    .addMigrations(*MIGRATIONS)
                    .build()
                    .also { instance = it }
            }
        }
    }
}
