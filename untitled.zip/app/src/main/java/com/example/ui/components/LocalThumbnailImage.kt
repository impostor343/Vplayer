package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CinemaCharcoal
import com.example.ui.theme.CinemaSurfaceHigh
import com.example.ui.theme.CinemaTextMuted
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun LocalThumbnailImage(
    thumbnailPath: String?,
    modifier: Modifier = Modifier,
) {
    var bitmap by remember(thumbnailPath) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(thumbnailPath) {
        bitmap = if (!thumbnailPath.isNullOrBlank()) {
            withContext(Dispatchers.IO) {
                val file = File(thumbnailPath)
                if (file.exists() && file.length() > 0L) {
                    runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()
                } else {
                    null
                }
            }
        } else {
            null
        }
    }

    Box(
        modifier = modifier.background(
            Brush.linearGradient(listOf(CinemaSurfaceHigh, CinemaCharcoal))
        ),
        contentAlignment = Alignment.Center,
    ) {
        val bmp = bitmap
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = stringResource(R.string.cd_video_thumbnail),
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Icon(
                imageVector = Icons.Rounded.Movie,
                contentDescription = stringResource(R.string.cd_video_thumbnail),
                tint = CinemaTextMuted.copy(alpha = 0.65f),
                modifier = Modifier.size(32.dp),
            )
        }
    }
}
