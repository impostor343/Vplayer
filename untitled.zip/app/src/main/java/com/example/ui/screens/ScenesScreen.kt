package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.db.TimestampBookmarkEntity
import com.example.media.Formatters
import com.example.ui.theme.CinemaBorderSubtle
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.CinemaIce
import com.example.ui.theme.CinemaObsidian
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceHigh
import com.example.ui.theme.CinemaTextMuted
import com.example.ui.theme.CinemaTextPrimary
import com.example.ui.theme.CinemaTextSecondary
import com.example.viewmodel.CinemaAppViewModel

@Composable
fun ScenesScreen(
    viewModel: CinemaAppViewModel,
    onPlayAtTimestamp: (String, Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    val allBookmarks by viewModel.allBookmarks.collectAsStateWithLifecycle()
    var favouritesOnly by remember { mutableStateOf(false) }

    val displayed = remember(allBookmarks, favouritesOnly) {
        if (favouritesOnly) allBookmarks.filter { it.isFavouriteScene } else allBookmarks
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CinemaObsidian)
            .padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.scenes_title),
            style = MaterialTheme.typography.headlineMedium,
            color = CinemaTextPrimary,
        )
        Text(
            text = "Jump directly into any bookmarked moment in your local library",
            style = MaterialTheme.typography.bodySmall,
            color = CinemaTextSecondary,
        )

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !favouritesOnly,
                onClick = { favouritesOnly = false },
                label = { Text("${stringResource(R.string.scenes_all_bookmarks)} (${allBookmarks.size})") },
            )
            FilterChip(
                selected = favouritesOnly,
                onClick = { favouritesOnly = true },
                leadingIcon = {
                    Icon(Icons.Rounded.Favorite, contentDescription = null, modifier = Modifier.size(16.dp))
                },
                label = {
                    Text(
                        "${stringResource(R.string.scenes_favourites_only)} (${allBookmarks.count { it.isFavouriteScene }})"
                    )
                },
            )
        }

        Spacer(Modifier.height(12.dp))

        if (displayed.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Surface(
                    color = CinemaSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CinemaBorderSubtle),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Bookmarks,
                            contentDescription = null,
                            tint = CinemaGold,
                            modifier = Modifier.size(40.dp),
                        )
                        Text(stringResource(R.string.scenes_empty_title), style = MaterialTheme.typography.titleLarge)
                        Text(
                            stringResource(R.string.scenes_empty_body),
                            style = MaterialTheme.typography.bodyMedium,
                            color = CinemaTextSecondary,
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("scenes_bookmarks_list"),
            ) {
                items(displayed, key = { it.bookmarkId }) { bm ->
                    BookmarkSceneCard(
                        bookmark = bm,
                        onPlay = { onPlayAtTimestamp(bm.videoId, bm.timestampMs) },
                        onToggleFavourite = { viewModel.toggleBookmarkFavourite(bm) },
                        onDelete = { viewModel.deleteBookmark(bm.bookmarkId) },
                    )
                }
            }
        }
    }
}

@Composable
private fun BookmarkSceneCard(
    bookmark: TimestampBookmarkEntity,
    onPlay: () -> Unit,
    onToggleFavourite: () -> Unit,
    onDelete: () -> Unit,
) {
    Surface(
        color = CinemaSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CinemaBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onPlay),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Surface(
                color = CinemaSurfaceHigh,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.padding(2.dp),
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Bookmark,
                        contentDescription = null,
                        tint = if (bookmark.isFavouriteScene) CinemaGold else CinemaIce,
                        modifier = Modifier.size(20.dp),
                    )
                    Text(
                        text = Formatters.formatDurationMs(bookmark.timestampMs),
                        style = MaterialTheme.typography.labelMedium,
                        color = CinemaTextPrimary,
                    )
                }
            }

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = bookmark.title.ifBlank { "Bookmarked Scene" },
                    style = MaterialTheme.typography.titleMedium,
                    color = CinemaTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = bookmark.videoFilename.substringBeforeLast('.'),
                    style = MaterialTheme.typography.bodySmall,
                    color = CinemaGold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (bookmark.note.isNotBlank()) {
                    Text(
                        text = bookmark.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = CinemaTextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text(
                    text = "Saved ${Formatters.formatDateOnly(bookmark.createdAtMillis)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = CinemaTextMuted,
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(onClick = onPlay) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = "Jump to scene", tint = CinemaGold)
                }
                Row {
                    IconButton(onClick = onToggleFavourite, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = if (bookmark.isFavouriteScene) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = stringResource(R.string.cd_favourite),
                            tint = if (bookmark.isFavouriteScene) CinemaGold else CinemaTextMuted,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.Outlined.Delete,
                            contentDescription = stringResource(R.string.cd_delete),
                            tint = CinemaTextMuted,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }
            }
        }
    }
}
