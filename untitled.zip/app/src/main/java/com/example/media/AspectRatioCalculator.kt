package com.example.media

import java.util.Locale
import kotlin.math.abs

/**
 * Computes true Display Aspect Ratio (DAR) from coded video dimensions,
 * Sample/Pixel Aspect Ratio (SAR/PAR), and container rotation metadata.
 * Maps cinematic and broadcast standards accurately instead of defaulting to 16:9.
 */
object AspectRatioCalculator {

    data class AspectRatioResult(
        val displayWidth: Int,
        val displayHeight: Int,
        val darValue: Double,
        val formattedLabel: String,
        val standardName: String,
    )

    private data class KnownRatio(
        val value: Double,
        val label: String,
        val name: String,
        val tolerance: Double,
    )

    private val knownRatios = listOf(
        KnownRatio(2.76, "2.76:1", "Ultra Panavision 70", 0.03),
        KnownRatio(2.55, "2.55:1", "CinemaScope Original", 0.025),
        KnownRatio(2.40, "2.40:1", "Anamorphic Widescreen", 0.008),
        KnownRatio(2.39, "2.39:1", "Scope / DCI Scope", 0.015),
        KnownRatio(2.35, "2.35:1", "Classic Scope", 0.018),
        KnownRatio(2.20, "2.20:1", "70mm Todd-AO", 0.025),
        KnownRatio(2.00, "2.00:1", "Univisium", 0.025),
        KnownRatio(1.90, "1.90:1", "DCI / Digital IMAX", 0.022),
        KnownRatio(1.85, "1.85:1", "American Flat", 0.022),
        KnownRatio(1.7778, "1.78:1", "16:9 Widescreen", 0.022),
        KnownRatio(1.6667, "1.66:1", "European Flat", 0.022),
        KnownRatio(1.50, "1.50:1", "3:2 VistaVision", 0.02),
        KnownRatio(1.43, "1.43:1", "IMAX 70mm", 0.02),
        KnownRatio(1.375, "1.37:1", "Academy Ratio", 0.018),
        KnownRatio(1.3333, "1.33:1", "4:3 Standard", 0.022),
        KnownRatio(1.00, "1.00:1", "1:1 Square", 0.02),
        KnownRatio(0.5625, "0.56:1", "9:16 Vertical", 0.02),
    )

    fun calculate(
        codedWidth: Int,
        codedHeight: Int,
        sarNum: Int = 1,
        sarDen: Int = 1,
        rotationDegrees: Int = 0,
    ): AspectRatioResult {
        if (codedWidth <= 0 || codedHeight <= 0) {
            return AspectRatioResult(0, 0, 0.0, "Unknown", "Unknown")
        }
        val safeSar = if (sarNum > 0 && sarDen > 0) sarNum.toDouble() / sarDen.toDouble() else 1.0
        val normalizedRotation = ((rotationDegrees % 360) + 360) % 360
        val swapped = normalizedRotation == 90 || normalizedRotation == 270

        val rawDisplayW = codedWidth * safeSar
        val rawDisplayH = codedHeight.toDouble()

        val finalW = if (swapped) rawDisplayH else rawDisplayW
        val finalH = if (swapped) rawDisplayW else rawDisplayH
        val dar = finalW / finalH

        return fromDarValue(
            dar = dar,
            displayWidth = finalW.toInt(),
            displayHeight = finalH.toInt(),
        )
    }

    fun calculateFromPar(
        codedWidth: Int,
        codedHeight: Int,
        par: Double,
        rotationDegrees: Int = 0,
    ): AspectRatioResult {
        if (codedWidth <= 0 || codedHeight <= 0) {
            return AspectRatioResult(0, 0, 0.0, "Unknown", "Unknown")
        }
        val safePar = if (par.isFinite() && par > 0.05 && par < 10.0) par else 1.0
        val normalizedRotation = ((rotationDegrees % 360) + 360) % 360
        val swapped = normalizedRotation == 90 || normalizedRotation == 270

        val rawDisplayW = codedWidth * safePar
        val rawDisplayH = codedHeight.toDouble()
        val finalW = if (swapped) rawDisplayH else rawDisplayW
        val finalH = if (swapped) rawDisplayW else rawDisplayH
        val dar = finalW / finalH

        return fromDarValue(dar, finalW.toInt(), finalH.toInt())
    }

    fun fromDarValue(
        dar: Double,
        displayWidth: Int = 0,
        displayHeight: Int = 0,
    ): AspectRatioResult {
        if (!dar.isFinite() || dar <= 0.0) {
            return AspectRatioResult(displayWidth, displayHeight, 0.0, "Unknown", "Unknown")
        }

        // Check exact 2.40:1 vs 2.39:1 distinction carefully:
        // 3840x1600 = 2.400 -> 2.40:1; 3840x1606 or 1920x804 = 2.391 -> 2.39:1
        val match = knownRatios
            .filter { abs(dar - it.value) <= it.tolerance }
            .minByOrNull { abs(dar - it.value) }

        val label = match?.label ?: String.format(Locale.US, "%.2f:1", dar)
        val standard = match?.name ?: String.format(Locale.US, "Custom (%.2f:1)", dar)
        return AspectRatioResult(
            displayWidth = displayWidth,
            displayHeight = displayHeight,
            darValue = dar,
            formattedLabel = label,
            standardName = standard,
        )
    }
}
